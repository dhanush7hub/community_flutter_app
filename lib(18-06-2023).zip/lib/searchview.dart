import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class SearchPage extends StatefulWidget {
  @override
  _SearchPageState createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  TextEditingController _searchController = TextEditingController();

  QuerySnapshot? searchSnapshot;

  void _searchUsers(String query) {
    FirebaseFirestore.instance
        .collection('users')
        .where('username', isGreaterThanOrEqualTo: query)
        .where('username', isLessThanOrEqualTo: '$query\uf8ff')
        .get()
        .then((snapshot) {
      setState(() {
        searchSnapshot = snapshot;
      });
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: TextField(
          controller: _searchController,
          decoration: InputDecoration(
            hintText: 'Search',
          ),
          onChanged: (value) {
            _searchUsers(value);
          },
        ),
      ),
      body: searchSnapshot == null
          ? Center(
              child: Text('Search for a username'),
            )
          : searchSnapshot!.docs.isEmpty
              ? Center(
                  child: Text('No users found'),
                )
              : ListView.builder(
                  itemCount: searchSnapshot!.docs.length,
                  itemBuilder: (context, index) {
                    DocumentSnapshot user = searchSnapshot!.docs[index];
                    return ListTile(
                      title: Text(user['username']),
                      subtitle: Text(user['name']),
                      leading: CircleAvatar(
                        backgroundImage: NetworkImage(user['profileImageUrl']),
                      ),
                      onTap: () {
                        // Do something when user is tapped
                      },
                    );
                  },
                ),
    );
  }
}
