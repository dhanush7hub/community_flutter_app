import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:specialchat/screens/downloadimagevideo.dart';
import 'package:specialchat/screens/intractionpage.dart';
import 'package:specialchat/screens/temp.dart';
import 'package:specialchat/widgets/usersearch.dart';
import 'package:specialchat/widgets/widgets.dart';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:video_player/video_player.dart';
import 'package:path/path.dart' as path;
import 'package:flutter_svg/flutter_svg.dart';
import 'package:specialchat/services/database_service.dart';

class postCard extends StatefulWidget {
  String content;
  String name;
  String imageurl;
  String profileurl;
  String rocket;
  bool isvideo;
  final VideoPlayerController _controllers;
  String roomid;
  // late Future<void> _initializeVideoPlayerFuture;

  postCard(this.content, this.imageurl, this.name, this.profileurl, this.rocket,
      this.isvideo, this._controllers, this.roomid);

  @override
  State<postCard> createState() => _postCardState();
}

class _postCardState extends State<postCard> {
  late bool _downloading;
  late double _progress;
  late String _message;
  late IconData _icon;
  late String _path;
  bool isExpanded = false;
  // late VideoPlayerController _controllers;
  // late Future<void> _initializeVideoPlayerFuture;

  @override
  void initState() {
    super.initState();
    _downloading = false;
    _progress = 0;
    _message = 'Download';
    _icon = Icons.download_rounded;
    print(widget._controllers);
    // _controllers = VideoPlayerController.network(widget.imageurl);
    // _initializeVideoPlayerFuture = _controllers.initialize();
    widget._controllers.setLooping(true);
    widget._controllers.setVolume(1.0);
    widget._controllers.play();
  }

  // Future<String> getUserprofile() async {
  //   final snap = FirebaseFirestore.instance
  //       .collection("users")
  //       .doc(FirebaseAuth.instance.currentUser!.uid);
  //   final snapdoc = await snap.get();
  //   if (snapdoc.exists && snapdoc.data() != null) {
  //     return snapdoc.data()!['profilepic'];
  //   } else {
  //     return "";
  //   }
  // }

  Future<void> _downloadFile() async {
    final appDirectory = await getExternalStorageDirectory();
    final directoryPath = '${appDirectory!.path}/Downloads';
    await Directory(directoryPath).create(recursive: true);
    final dio = Dio();
    final extension = widget.isvideo ? 'mp4' : 'jpg';
    final uniqueFileName =
        '${DateTime.now().millisecondsSinceEpoch}_file.$extension';
    final _path = path.join(directoryPath, uniqueFileName);
    try {
      setState(() {
        _downloading = true;
        _progress = 0;
        _message = 'Downloading...';
        _icon = Icons.close;
      });

      await dio.download(
        widget.imageurl,
        _path,
        onReceiveProgress: (rec, total) {
          setState(() {
            _progress = (rec / total);
          });
        },
      );
    } catch (e) {
      print(e);
      setState(() {
        _message = 'Failed';
        _icon = Icons.error_rounded;
      });
    }

    setState(() {
      _downloading = false;
      _progress = 0;
      _message = 'Download';
      _icon = Icons.download_rounded;
    });
  }

  @override
  Widget build(BuildContext context) {
    bool change = true;

    return Container(
      decoration: const BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: Color.fromARGB(96, 141, 136, 206),
            width: 1.5,
          ),
        ),
      ),
      margin: const EdgeInsets.all(10),
      child: IntrinsicHeight(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Container(
                child: Row(
                  children: [
                    Expanded(
                      child: Container(
                        padding: const EdgeInsets.only(right: 10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                CircleAvatar(
                                  radius: 30,
                                  backgroundImage:
                                      NetworkImage(widget.profileurl),
                                  backgroundColor: Colors.red,
                                ),
                                const SizedBox(
                                  width: 10,
                                ),
                                Expanded(
                                  child: Text(
                                    widget.name,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            RichText(
                              overflow: isExpanded
                                  ? TextOverflow.visible
                                  : TextOverflow.ellipsis,
                              maxLines: isExpanded ? null : 2,
                              text: TextSpan(
                                text: widget.content,
                                style: DefaultTextStyle.of(context).style,
                              ),
                            ),
                            InkWell(
                              onTap: () {
                                setState(() {
                                  isExpanded = !isExpanded;
                                });
                              },
                              child: Padding(
                                padding: const EdgeInsets.only(top: 4.0),
                                child: Text(
                                  isExpanded ? 'See less' : 'See more',
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontWeight: FontWeight.w700,
                                      fontSize: 12),
                                ),
                              ),
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(25),
                                ),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(
                                      10.0), // Adjust the radius as desired
                                  child: widget.isvideo
                                      ? AspectRatio(
                                          aspectRatio: widget
                                              ._controllers.value.aspectRatio,
                                          child:
                                              VideoPlayer(widget._controllers),
                                        )
                                      : Image.network(
                                          widget.imageurl,
                                        ),
                                )),
                            const SizedBox(
                              height: 10,
                            ),
                          ],
                        ),
                      ),
                    ),
                    Container(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Expanded(
                            child: Visibility(
                              maintainSize: change,
                              maintainAnimation: change,
                              maintainState: change,
                              visible: change,
                              child: Container(
                                alignment: Alignment.topCenter,
                                child: Column(
                                  children: [
                                    const SizedBox(
                                      height: 15,
                                    ),
                                    SvgPicture.string(
                                      '<svg width="16" height="4" viewBox="0 0 16 4" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="2" cy="2" r="1.5" transform="rotate(-90 2 2)" fill="black"/><circle cx="8" cy="2" r="1.5" transform="rotate(-90 8 2)" fill="black"/><circle cx="14" cy="2" r="1.5" transform="rotate(-90 14 2)" fill="black"/></svg>',
                                      width: 5,
                                      height: 5,
                                      allowDrawingOutsideViewBox: true,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(
                            height: 25,
                          ),
                          Visibility(
                            maintainSize: change,
                            maintainAnimation: change,
                            maintainState: change,
                            visible: change,
                            child: Stack(
                              alignment: Alignment.center,
                              children: [
                                InkWell(
                                  onTap: _downloading ? null : _downloadFile,
                                  child: Container(
                                    width: 18,
                                    height: 16,
                                    child: Center(
                                      child: SvgPicture.string(
                                        '<svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9.00098 13V1" stroke="#555555" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M13 9L9 13L5 9" stroke="#555555" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M0.75 10C0.335786 10 0 10.3358 0 10.75V16C0 17.1046 0.89543 18 2 18H16C17.1046 18 18 17.1046 18 16V10.75C18 10.3358 17.6642 10 17.25 10V10C16.8358 10 16.5 10.3358 16.5 10.75V16C16.5 16.2761 16.2761 16.5 16 16.5H2C1.72386 16.5 1.5 16.2761 1.5 16V10.75C1.5 10.3358 1.16421 10 0.75 10V10Z" fill="#555555"/></svg>',
                                        width: 20,
                                        height: 20,
                                        allowDrawingOutsideViewBox: true,
                                      ),
                                    ),
                                  ),
                                ),
                                if (_downloading)
                                  CircularProgressIndicator(
                                    value: _progress,
                                    strokeWidth: 4,
                                    valueColor: AlwaysStoppedAnimation<Color>(
                                      Colors.green,
                                    ),
                                  ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 25),
                          Visibility(
                            maintainSize: change,
                            maintainAnimation: change,
                            maintainState: change,
                            visible: change,
                            child: IconButton(
                              onPressed: () async {
                                // final u_profile = await getUserprofile();
                                nextpage(
                                    context,
                                    InteractionPage(
                                        widget.imageurl,
                                        widget.content,
                                        widget.roomid,));
                              },
                              icon: SvgPicture.string(
                                '<svg width="22" height="18" viewBox="0 0 22 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M0.25 8.75C0.25 9.16421 0.585786 9.5 1 9.5C1.41421 9.5 1.75 9.16421 1.75 8.75H0.25ZM1.75 3C1.75 2.58579 1.41421 2.25 1 2.25C0.585786 2.25 0.25 2.58579 0.25 3H1.75ZM6.05556 11.5C6.46977 11.5 6.80556 11.1642 6.80556 10.75C6.80556 10.3358 6.46977 10 6.05556 10V11.5ZM15.75 3C15.75 2.58579 15.4142 2.25 15 2.25C14.5858 2.25 14.25 2.58579 14.25 3H15.75ZM14.25 3.0625C14.25 3.47671 14.5858 3.8125 15 3.8125C15.4142 3.8125 15.75 3.47671 15.75 3.0625H14.25ZM3 1.75H13V0.25H3V1.75ZM1.75 8.75V3H0.25V8.75H1.75ZM6.05556 10H3V11.5H6.05556V10ZM14.25 3V3.0625H15.75V3H14.25ZM14.25 3.0625V8.125H15.75V3.0625H14.25ZM0.25 8.75C0.25 10.2688 1.48122 11.5 3 11.5V10C2.30964 10 1.75 9.44036 1.75 8.75H0.25ZM13 1.75C13.6904 1.75 14.25 2.30964 14.25 3H15.75C15.75 1.48122 14.5188 0.25 13 0.25V1.75ZM3 0.25C1.48122 0.25 0.25 1.48122 0.25 3H1.75C1.75 2.30964 2.30964 1.75 3 1.75V0.25Z" fill="#555555"/><circle cx="5" cy="5.75" r="0.75" fill="#555555"/><circle cx="8" cy="5.75" r="0.75" fill="#555555"/><circle cx="11" cy="5.75" r="0.75" fill="#555555"/><path d="M11 14.1875V10C11 8.89543 11.8954 8 13 8H19C20.1046 8 21 8.89543 21 10V13.3125C21 14.4171 20.1046 15.3125 19 15.3125H14.1357C13.6541 15.3125 13.1886 15.4863 12.8248 15.802L11.4444 17" stroke="#555555" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M18 11.5H14" stroke="#555555" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
                                width: 20,
                                height: 20,
                                allowDrawingOutsideViewBox: true,
                              ),
                            ),
                          ),
                          const SizedBox(height: 25),
                          Visibility(
                              maintainSize: change,
                              maintainAnimation: change,
                              maintainState: change,
                              visible: change,
                              child: SvgPicture.string(
                                '<svg width="17" height="17" viewBox="0 0 17 17" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7.70432 9.66653C7.62929 9.50145 7.49698 9.36914 7.3319 9.29411L0.899737 6.37039C0.692885 6.27637 0.708574 5.97748 0.924129 5.90563L15.7028 0.979412C15.8982 0.914267 16.0842 1.1002 16.019 1.29564L11.0928 16.0743C11.0209 16.2899 10.7221 16.3055 10.628 16.0987L7.70432 9.66653Z" stroke="#555555" stroke-width="1.5" stroke-linejoin="round"/></svg>',
                                width: 17,
                                height: 17,
                                allowDrawingOutsideViewBox: true,
                              )),
                          const SizedBox(
                            height: 40,
                          ),
                          SvgPicture.string(
                            '<svg width="18" height="25" viewBox="0 0 18 25" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7.99095 3.13059C8.49052 2.45246 9.50416 2.45246 10.0037 3.1306L12.6813 6.76512C12.8657 7.01548 12.9502 7.32559 12.9183 7.63491L13.6643 7.71195L12.9183 7.63491L11.37 22.6284C11.3042 23.2656 10.7673 23.75 10.1266 23.75H7.86804C7.22739 23.75 6.69046 23.2657 6.62465 22.6284L5.07643 7.63491C5.04449 7.3256 5.12899 7.01548 5.31343 6.76512L7.99095 3.13059Z" stroke="#555555" stroke-width="1.5" stroke-linejoin="round"/><path d="M12.3042 15.5L15.7152 20.3494C16.6473 21.6745 15.6994 23.5 14.0793 23.5H11.0645" stroke="#555555" stroke-width="1.5" stroke-linejoin="round"/><path d="M5.69189 15.5L2.28092 20.3494C1.34884 21.6745 2.29667 23.5 3.91678 23.5H6.93164" stroke="#555555" stroke-width="1.5" stroke-linejoin="round"/><circle cx="8.99805" cy="9.5" r="1.5" stroke="#555555"/></svg>',
                            width: 28,
                            height: 28,
                            allowDrawingOutsideViewBox: true,
                          ),
                          const SizedBox(
                            height: 15,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Text("Rocket by ${widget.rocket} users"),
            SizedBox(
              height: 10,
            ),
          ],
        ),
      ),
    );
  }
}
