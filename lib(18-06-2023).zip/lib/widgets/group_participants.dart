import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:specialchat/widgets/usersearch.dart';
import 'package:specialchat/widgets/widgets.dart';
import 'package:specialchat/widgets/participants.dart';

import 'package:flutter/gestures.dart';

class group_participants extends StatefulWidget {
  List<QueryDocumentSnapshot<Object?>>? docs;
  String groupid;
  bool alreadyjoined;
  bool private;

  group_participants(this.docs, this.groupid, this.alreadyjoined, this.private);

  @override
  State<group_participants> createState() => _group_participantsState();
}

class _group_participantsState extends State<group_participants> {
  var count = 3;
  bool sm = false;

  bool? isadmin;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    // isadmin = true;
    getvalue();
  }

  Future getvalue() async {
    print("objectaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
    print(widget.alreadyjoined);
    print(widget.private);

    if (widget.private) {
      final snapshot = await FirebaseFirestore.instance
          .collection("privategroups")
          .doc(widget.groupid)
          .get();

      if (snapshot.exists) {
        final data = snapshot.data() as Map<String, dynamic>?;

        if (data != null && data.containsKey('created_byuid')) {
          var createdByUID = data['created_byuid'];
          print('created_byuid: $createdByUID' + "jjjjjjjjjjjjjjjjjjjjjjjjjjj");
          setState(() {
            isadmin = (createdByUID == FirebaseAuth.instance.currentUser!.uid)
                ? true
                : false;
          });
        } else {
          // 'created_byuid' field does not exist or is null
          // Handle accordingly
        }
      }
    } else {
      final snapshot = await FirebaseFirestore.instance
          .collection("publicgroups")
          .doc(widget.groupid)
          .get();

      if (snapshot.exists) {
        final data = snapshot.data() as Map<String, dynamic>?;

        if (data != null && data.containsKey('created_byuid')) {
          var createdByUID = data['created_byuid'];
          print('created_byuid: $createdByUID' + "jjjjjjjjjjjjjjjjjjjjjjjjjjj");
          setState(() {
            isadmin = (createdByUID == FirebaseAuth.instance.currentUser!.uid)
                ? true
                : false;
          });
        } else {
          // 'created_byuid' field does not exist or is null
          // Handle accordingly
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return isadmin == null
        ? CircularProgressIndicator()
        : Column(
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      widget.docs!.length.toString() + ' Participants',
                      style: medium.copyWith(
                        color: Color(0Xff777777),
                        fontSize: 12,
                      ),
                    ),
                  ),
                  IconButton(
                    onPressed: () {},
                    icon: Icon(
                      Icons.search,
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 5,
              ),
              ListView.builder(
                physics: NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                itemCount:
                    widget.docs!.length > 3 ? count : widget.docs!.length,
                itemBuilder: (context, index) {
                  final doc = widget.docs![index] as QueryDocumentSnapshot;
                  return participants(doc,);
                },
              ),
              if (widget.docs!.length > 3)
                RichText(
                  text: TextSpan(
                    children: <TextSpan>[
                      TextSpan(
                        text: sm
                            ? "Show less"
                            : (widget.docs!.length - 3).toString() + ' more',
                        style: medium.copyWith(
                          fontSize: 11,
                          color: Color(0xff7DB1FD),
                        ),
                        recognizer: TapGestureRecognizer()
                          ..onTap = () {
                            setState(() {
                              count = sm ? 3 : widget.docs!.length;
                              sm = !sm;
                            });
                          },
                      ),
                    ],
                  ),
                ),
              SizedBox(
                height: 30,
              ),
              // Container(
              //   alignment: Alignment.topLeft,
              //   child: RichText(
              //     text: TextSpan(
              //       children: <TextSpan>[
              //         TextSpan(
              //           text: 'Report',
              //           style:
              //               light.copyWith(fontSize: 14, color: Colors.amber),
              //           recognizer: TapGestureRecognizer()..onTap = () {},
              //         ),
              //       ],
              //     ),
              //   ),
              // ),
              SizedBox(
                height: 15,
              ),
              joined_group(widget.alreadyjoined, widget.groupid, widget.private,
                  isadmin!),
            ],
          );
  }
}

class joined_group extends StatefulWidget {
  bool joined;
  String groupid;
  bool private;
  bool isadmin;
  joined_group(this.joined, this.groupid, this.private, this.isadmin);

  @override
  State<joined_group> createState() => _joined_groupState();
}

class _joined_groupState extends State<joined_group> {
  @override
  Widget build(BuildContext context) {
    return
        // widget.isadmin == null
        //     ? CircularProgressIndicator()
        //     :
        widget.joined
            ? widget.isadmin
                ? Column(
                    children: [
                      Container(
                        alignment: Alignment.topLeft,
                        child: RichText(
                          text: TextSpan(
                            children: <TextSpan>[
                              TextSpan(
                                text: 'Report',
                                style: light.copyWith(
                                  color: Colors.black,
                                  fontSize: 14,
                                ),
                                recognizer: TapGestureRecognizer()
                                  ..onTap = () {},
                              ),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 15,
                      ),
                      Container(
                        alignment: Alignment.topLeft,
                        child: RichText(
                          text: TextSpan(
                            children: <TextSpan>[
                              TextSpan(
                                text: 'Leave Group',
                                style: light.copyWith(
                                  color: Color(0xffA70000),
                                  fontSize: 14,
                                ),
                                recognizer: TapGestureRecognizer()
                                  ..onTap = () {},
                              ),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 15,
                      ),
                      Container(
                        alignment: Alignment.topLeft,
                        child: RichText(
                          text: TextSpan(
                            children: <TextSpan>[
                              TextSpan(
                                text: 'Delete Group',
                                style: light.copyWith(
                                  color: Color(0xffA70000),
                                  fontSize: 14,
                                ),
                                recognizer: TapGestureRecognizer()
                                  ..onTap = () {},
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  )
                : Column(
                    children: [
                      Container(
                        alignment: Alignment.topLeft,
                        child: RichText(
                          text: TextSpan(
                            children: <TextSpan>[
                              TextSpan(
                                text: 'Report',
                                style: light.copyWith(
                                  color: Colors.black,
                                  fontSize: 14,
                                ),
                                recognizer: TapGestureRecognizer()
                                  ..onTap = () {},
                              ),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 15,
                      ),
                      Container(
                        alignment: Alignment.topLeft,
                        child: RichText(
                          text: TextSpan(
                            children: <TextSpan>[
                              TextSpan(
                                text: 'Leave Group',
                                style: light.copyWith(
                                  color: Color(0xffA70000),
                                  fontSize: 14,
                                ),
                                recognizer: TapGestureRecognizer()
                                  ..onTap = () {},
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  )
            : ElevatedButton(
                onPressed: () async {
                  print(widget.joined);
                  print("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
                  final name = await FirebaseFirestore.instance
                      .collection("users")
                      .doc(FirebaseAuth.instance.currentUser!.uid)
                      .get();

                  final addinguser = widget.private
                      ? FirebaseFirestore.instance
                          .collection("privategroups/${widget.groupid}/users")
                          .doc(FirebaseAuth.instance.currentUser!.uid)
                          .set({
                          "bio": name.data()!["about"],
                          "isadmin": false,
                          "profile_url": name.data()!["profilepic"],
                          "username": name.data()!["name"]
                        })
                      : FirebaseFirestore.instance
                          .collection("publicgroups/${widget.groupid}/users")
                          .doc(FirebaseAuth.instance.currentUser!.uid)
                          .set({
                          "bio": name.data()!["about"],
                          "isadmin": false,
                          "profile_url": name.data()!["profilepic"],
                          "username": name.data()!["name"]
                        });

                  // Query the documents in the source collection
                  final doc = await FirebaseFirestore.instance
                      .collection('publicgroups')
                      .doc(widget.groupid)
                      .get();

                  final data = doc.data() as Map<String, dynamic>;

                  final snap = FirebaseFirestore.instance
                      .collection(
                          "multipleconversationlist/${FirebaseAuth.instance.currentUser!.uid}/conversationwith")
                      .doc(widget.groupid);
                  final snapdocs = snap.set({
                    "groupid": data["roomid"],
                    "groupname": data["groupname"],
                    "group_des": data["group_des"],
                    "lastmessage": "dubuku",
                    "profile_url": data["profile_url"],
                    "myprofile_url": name.data()!["profilepic"],
                    "privategroup": false,
                    "created_at":
                        Timestamp.fromMillisecondsSinceEpoch(1620676800000),
                    "created_by": data["created_by"],
                    "group_link": "http://mylink.com"
                  });
                  Navigator.pop(context);
                },
                child: Text("Join Group"));
  }
}
