// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:flutter/gestures.dart';
// import 'package:flutter/material.dart';
// import 'package:specialchat/widgets/widgets.dart';

// class joined_group extends StatefulWidget {
//   bool joined;
//   String groupid;
//   bool private;
//   bool isadmin;
//   joined_group(this.joined, this.groupid, this.private, this.isadmin);

//   @override
//   State<joined_group> createState() => _joined_groupState();
// }

// class _joined_groupState extends State<joined_group> {
//   @override
//   void initState() {
//     // TODO: implement initState
//     super.initState();
//     print("YYYYYFFFFFFFFFGGGGGGGGGGGGG");
//     print(widget.isadmin);
//   }
//   // bool isadmin = false;
//   // @override
//   // void initState() {
//   //   // TODO: implement initState
//   //   super.initState();
//   //   getvalue();
//   // }

//   // getvalue() async {
//   //   print("objectaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
//   //   print(widget.private);

//   //   if (widget.private) {
//   //     final snapshot = await FirebaseFirestore.instance
//   //         .collection("privategroup")
//   //         .doc(widget.groupid)
//   //         .get();

//   //     if (snapshot.exists) {
//   //       final data = snapshot.data() as Map<String, dynamic>?;

//   //       if (data != null && data.containsKey('created_byuid')) {
//   //         var createdByUID = data['created_byuid'];
//   //         print('created_byuid: $createdByUID' + "jjjjjjjjjjjjjjjjjjjjjjjjjjj");
//   //         setState(() {
//   //           isadmin = (createdByUID == FirebaseAuth.instance.currentUser!.uid)
//   //               ? true
//   //               : false;
//   //         });
//   //       } else {
//   //         // 'created_byuid' field does not exist or is null
//   //         // Handle accordingly
//   //       }
//   //     }
//   //   } else {
//   //     final snapshot = await FirebaseFirestore.instance
//   //         .collection("publicgroup")
//   //         .doc(widget.groupid)
//   //         .get();

//   //     if (snapshot.exists) {
//   //       final data = snapshot.data() as Map<String, dynamic>?;

//   //       if (data != null && data.containsKey('created_byuid')) {
//   //         var createdByUID = data['created_byuid'];
//   //         print('created_byuid: $createdByUID' + "jjjjjjjjjjjjjjjjjjjjjjjjjjj");
//   //         setState(() {
//   //           isadmin = (createdByUID == FirebaseAuth.instance.currentUser!.uid)
//   //               ? true
//   //               : false;
//   //         });
//   //       } else {
//   //         // 'created_byuid' field does not exist or is null
//   //         // Handle accordingly
//   //       }
//   //     }
//   //   }
//   // }

//   @override
//   Widget build(BuildContext context) {
//     return widget.joined
//         ? true
//             ? Column(
//                 children: [
//                   Container(
//                     alignment: Alignment.topLeft,
//                     child: RichText(
//                       text: TextSpan(
//                         children: <TextSpan>[
//                           TextSpan(
//                             text: 'Report',
//                             style: light.copyWith(
//                               color: Colors.black,
//                               fontSize: 14,
//                             ),
//                             recognizer: TapGestureRecognizer()..onTap = () {},
//                           ),
//                         ],
//                       ),
//                     ),
//                   ),
//                   SizedBox(
//                     height: 15,
//                   ),
//                   Container(
//                     alignment: Alignment.topLeft,
//                     child: RichText(
//                       text: TextSpan(
//                         children: <TextSpan>[
//                           TextSpan(
//                             text: 'Leave Group',
//                             style: light.copyWith(
//                               color: Color(0xffA70000),
//                               fontSize: 14,
//                             ),
//                             recognizer: TapGestureRecognizer()..onTap = () {},
//                           ),
//                         ],
//                       ),
//                     ),
//                   ),
//                   SizedBox(
//                     height: 15,
//                   ),
//                   Container(
//                     alignment: Alignment.topLeft,
//                     child: RichText(
//                       text: TextSpan(
//                         children: <TextSpan>[
//                           TextSpan(
//                             text: 'Delete Group',
//                             style: light.copyWith(
//                               color: Color(0xffA70000),
//                               fontSize: 14,
//                             ),
//                             recognizer: TapGestureRecognizer()..onTap = () {},
//                           ),
//                         ],
//                       ),
//                     ),
//                   ),
//                 ],
//               )
//             : Column(
//                 children: [
//                   Container(
//                     alignment: Alignment.topLeft,
//                     child: RichText(
//                       text: TextSpan(
//                         children: <TextSpan>[
//                           TextSpan(
//                             text: 'Report',
//                             style: light.copyWith(
//                               color: Colors.black,
//                               fontSize: 14,
//                             ),
//                             recognizer: TapGestureRecognizer()..onTap = () {},
//                           ),
//                         ],
//                       ),
//                     ),
//                   ),
//                   SizedBox(
//                     height: 15,
//                   ),
//                   Container(
//                     alignment: Alignment.topLeft,
//                     child: RichText(
//                       text: TextSpan(
//                         children: <TextSpan>[
//                           TextSpan(
//                             text: 'Leave Group',
//                             style: light.copyWith(
//                               color: Color(0xffA70000),
//                               fontSize: 14,
//                             ),
//                             recognizer: TapGestureRecognizer()..onTap = () {},
//                           ),
//                         ],
//                       ),
//                     ),
//                   ),
//                 ],
//               )
//         : ElevatedButton(
//             onPressed: () async {
//               print(widget.joined);
//               print("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
//               final name = await FirebaseFirestore.instance
//                   .collection("users")
//                   .doc(FirebaseAuth.instance.currentUser!.uid)
//                   .get();

//               // Query the documents in the source collection
//               final doc = await FirebaseFirestore.instance
//                   .collection('publicgroups')
//                   .doc(widget.groupid)
//                   .get();

//               final data = doc.data() as Map<String, dynamic>;

//               final snap = FirebaseFirestore.instance
//                   .collection(
//                       "multipleconversationlist/${FirebaseAuth.instance.currentUser!.uid}/conversationwith")
//                   .doc(widget.groupid);
//               final snapdocs = snap.set({
//                 "groupid": data["roomid"],
//                 "groupname": data["groupname"],
//                 "group_des": data["group_des"],
//                 "lastmessage": "dubuku",
//                 "profile_url": data["profile_url"],
//                 "myprofile_url": name.data()!["profilepic"],
//                 "privategroup": false,
//                 "created_at":
//                     Timestamp.fromMillisecondsSinceEpoch(1620676800000),
//                 "created_by": data["created_by"],
//                 "group_link": "http://mylink.com"
//               });
//               Navigator.pop(context);
//             },
//             child: Text("Join Group"));
//   }
// }
