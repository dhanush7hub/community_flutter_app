import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_switch/flutter_switch.dart';
import 'package:specialchat/screens/groupinfopage.dart';
import 'package:specialchat/screens/otheruser_profile.dart';
import 'package:specialchat/widgets/containermessage.dart';
import 'package:specialchat/widgets/widgets.dart';

class Messages extends StatefulWidget {
  bool issearch;
  List groupname = [];
  List groupimg = [];
  List groupabout = [];

  List groupid = [];
  List searchroomid;

  Messages(
    this.issearch,
    this.groupname,
    this.groupimg,
    this.searchroomid,
    this.groupabout,
    this.groupid,
  );

  @override
  State<Messages> createState() => _MessagesState();
}

class _MessagesState extends State<Messages> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  bool isToggled = false;

  @override
  Widget build(BuildContext context) {
    return widget.issearch
        ? GestureDetector(
            onTap: () {
              // Unfocus any active text fields or text editing widgets
              FocusScope.of(context).unfocus();
            },
            child: ListView.builder(
              itemCount: widget.groupname.length,
              itemBuilder: (BuildContext context, int index) {
                return InkWell(
                  onTap: () async {
                    nextpage(
                        context,
                        UserProfilePage(
                          widget.groupname[index],
                          widget.groupimg[index],
                          widget.groupabout[index],
                          widget.groupid[index],
                        ));
                  },
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundImage: NetworkImage(widget.groupimg[index]),
                    ),
                    title: Text(
                      widget.groupname[index],
                      style: medium.copyWith(fontSize: 14),
                    ),
                  ),
                );
              },
            ),
          )
        : FutureBuilder(
            future: Future.value(FirebaseAuth.instance.currentUser),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(
                  child: CircularProgressIndicator(),
                );
              }
              return StreamBuilder(
                  stream: FirebaseFirestore.instance
                      .collection(
                          "dualconversationlist/${_auth.currentUser!.uid}/conversationwith")
                      .snapshots(),
                  builder: (context, snap) {
                    if (snap.connectionState == ConnectionState.waiting) {
                      return const Center(
                        child: CircularProgressIndicator(),
                      );
                    }
                    final chatdocs = snap.data!.docs;
                    return ListView.builder(
                      itemCount: chatdocs.length,
                      itemBuilder: (context, index) {
                        return containermessage(
                            true,
                            chatdocs[index]["profile_url"],
                            chatdocs[index]["username"],
                            chatdocs[index]["lastmessage"],
                            chatdocs[index]["roomid"],
                            chatdocs[index]["myprofile_url"],
                            true,
                            Timestamp.fromMillisecondsSinceEpoch(1620676800000),
                            "sowhat",
                            "https://sowhat.com",
                            "grouped disscusition description");
                      },
                    );
                  });
            });
  }
}
