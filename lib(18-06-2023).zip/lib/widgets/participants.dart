import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import 'widgets.dart';

class participants extends StatefulWidget {
  QueryDocumentSnapshot<Object?> doc;

  participants(this.doc, );

  @override
  State<participants> createState() => _participantsState();
}

class _participantsState extends State<participants> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onLongPressStart: (details) async {
        final offset = details.globalPosition;

        showMenu(
          context: context,
          position: RelativeRect.fromLTRB(
            offset.dx,
            offset.dy,
            MediaQuery.of(context).size.width - offset.dx,
            MediaQuery.of(context).size.height - offset.dy,
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(5),
          ),
          items: [
            PopupMenuItem(
              child: Text(
                'Make Admin',
                style: light.copyWith(
                  fontWeight: FontWeight.w400,
                  fontSize: 16,
                ),
              ),
            ),
            PopupMenuItem(
              child: Text(
                'Remove',
                style: light.copyWith(
                  color: Color(0xffFF0000),
                  fontWeight: FontWeight.w400,
                  fontSize: 16,
                ),
              ),
            ),
          ],
        );
      },
      child: InkWell(
        child: Container(
          margin: EdgeInsets.only(top: 5, bottom: 5),
          child: Row(
            children: [
              CircleAvatar(
                radius: 25,
                backgroundImage: NetworkImage(
                  widget.doc["profile_url"],
                ),
              ),
              SizedBox(
                width: 5,
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.doc["username"],
                      style: medium.copyWith(
                        fontSize: 15,
                      ),
                    ),
                    SizedBox(
                      height: 2,
                    ),
                    Text(
                      widget.doc["bio"],
                      style: medium.copyWith(
                        color: Color(0Xff777777),
                        fontSize: 10,
                      ),
                    ),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                    if (widget.doc["isadmin"])
                    Container(
                      alignment: Alignment.center,
                      height: 16.0,
                      width: 65.0,
                      decoration: BoxDecoration(
                        color: Color(0xff8D88CE),
                        borderRadius: BorderRadius.all(
                          Radius.circular(2),
                        ),
                      ),
                      child: Text(
                        'Group Admin',
                        style: medium.copyWith(
                          color: Colors.white,
                          fontSize: 9,
                        ),
                      ),
                    ),
                  SizedBox(
                    height: 3,
                  ),
                  // Text(
                  //   '@Dhanush007',
                  //   style: light.copyWith(
                  //     color: Color(0xff000000),
                  //     fontSize: 12,
                  //   ),
                  // ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
