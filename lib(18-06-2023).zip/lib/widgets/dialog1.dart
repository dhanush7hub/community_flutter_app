import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_switch/flutter_switch.dart';
import 'package:specialchat/services/database_service.dart';
import 'package:specialchat/widgets/dialog2.dart';
import 'package:specialchat/widgets/widgets.dart';

class dialog1 extends StatefulWidget {
  String gname;
  String gdescription;

  File img_loc;

  dialog1(this.gname, this.gdescription, this.img_loc);

  @override
  State<dialog1> createState() => _dialog1State();
}

class _dialog1State extends State<dialog1> {
  bool isToggled = false;

  @override
  Widget build(BuildContext context) {
    return Dialog(
      child: SizedBox(
        height: 360,
        width: 300,
        child: Container(
          padding: EdgeInsets.all(20),
          child: Column(
            children: [
              Text(
                'Group Privacy',
                style: semibold.copyWith(
                  fontSize: 19,
                  letterSpacing: -0.2,
                  fontWeight: FontWeight.w600,
                ),
              ),
              SizedBox(
                height: 10,
              ),
              CircleAvatar(
                radius: 30,
                //  backgroundImage: AssetImage(
                //   'assets/images/group_pic.png',
                //  ),
              ),
              SizedBox(
                height: 5,
              ),
              Text(
                'Tamil Rockstars',
                style: light.copyWith(
                  letterSpacing: -0.2,
                  fontSize: 13,
                  fontWeight: FontWeight.w400,
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Column(
                children: [
                  Row(
                    // mainAxisAlignment:
                    //     MainAxisAlignment.center,
                    children: [
                      Text(
                        'Private Group',
                        style: light.copyWith(
                          fontSize: 17,
                          fontWeight: FontWeight.w400,
                          letterSpacing: -0.4,
                        ),
                      ),
                      SizedBox(
                        width: 110,
                      ),
                      FlutterSwitch(
                        height: 20.0,
                        width: 35.0,
                        padding: 4.0,
                        toggleSize: 10.0,
                        borderRadius: 20.0,
                        activeColor: maincolor,
                        value: isToggled,
                        onToggle: (value) {
                          setState(
                            () {
                              isToggled = value;
                            },
                          );
                        },
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Text(
                    'Public groups can be searched and joined by people. Private groups cannot be searched and people can join only through your link',
                    style: light.copyWith(
                      fontSize: 15,
                    ),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                ],
              ),
              ElevatedButton(
                  onPressed: () async {
                    await DatabaseService().addgroup(widget.gname,
                        widget.gdescription, widget.img_loc, isToggled);
                    showDialog(
                        context: context, builder: (context) => dialog2());
                  },
                  child: Text("Done"))
            ],
          ),
        ),
      ),
    );
  }
}
