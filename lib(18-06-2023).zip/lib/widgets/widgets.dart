import 'package:flutter/material.dart';

var textfeilddec = const InputDecoration(
  labelStyle: TextStyle(color: Colors.black, fontWeight: FontWeight.w300),
  enabledBorder:
      OutlineInputBorder(borderSide: BorderSide(color: boxback, width: 2)),
  focusedBorder:
      OutlineInputBorder(borderSide: BorderSide(color: boxback, width: 2)),
  errorBorder:
      OutlineInputBorder(borderSide: BorderSide(color: boxback, width: 2)),
  errorStyle: TextStyle(color: Colors.red, fontSize: 10.0),
);

var textfeilddecchat = const InputDecoration(
  labelStyle: TextStyle(color: Colors.black, fontWeight: FontWeight.w300),
  enabledBorder:
      OutlineInputBorder(borderSide: BorderSide(color: subcolor, width: 1)),
  focusedBorder:
      OutlineInputBorder(borderSide: BorderSide(color: subcolor, width: 1)),
);

const boxback = Color(0xFFEFF1F5);

const maincolor = Color(0XFF7DB1FD);

const subcolor = Color(0XFF8D88CE);

const check = Color(0XFF059C49);

const close = Color(0XFFF49080);

// const buttonback = Color(0XFF8D88CE);

const regular = TextStyle(fontFamily: "Lexend");

const light = TextStyle(
  fontFamily: "Lexend",
  fontWeight: FontWeight.w300,
);
const medium = TextStyle(
  fontFamily: "Lexend",
  fontWeight: FontWeight.w500,
);
const semibold = TextStyle(
  fontFamily: "Lexend",
  fontWeight: FontWeight.w600,
);
const extrabold = TextStyle(
  fontFamily: "Lexend",
  fontWeight: FontWeight.w800,
);

nextpage(context, pagename) {
  Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => pagename,
      ));
}

nextpagereplace(context, pagename) {
  Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => pagename,
      ));
}

void showsnackbar(context, color, message) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(
        message,
        style: TextStyle(fontSize: 14),
      ),
      backgroundColor: color,
      duration: const Duration(seconds: 2),
      action: SnackBarAction(
        label: "ok",
        onPressed: () {},
        textColor: Colors.white,
      )));
}
