import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

import 'package:specialchat/screens/comradechatpage.dart';
import 'package:specialchat/widgets/widgets.dart';

class comradeofweek extends StatefulWidget {
  String profileurl;
  String username;
  String lastmessage;
  String roomid;
  String myprofile;

  comradeofweek(this.profileurl, this.username, this.lastmessage, this.roomid,
      this.myprofile);

  @override
  State<comradeofweek> createState() => _comradeofweekState();
}

class _comradeofweekState extends State<comradeofweek> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        print("object000000000000000000000000000000000");
        nextpage(
            context,
            comradechatPage(widget.profileurl, widget.username, widget.roomid,
                widget.myprofile));
      },
      child: ListTile(
        leading: CircleAvatar(
          backgroundImage: NetworkImage(widget.profileurl),
        ),
        title: Text(
          widget.username,
          style: medium.copyWith(fontSize: 14),
        ),
        subtitle: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Text(
                  widget.lastmessage,
                  style: regular.copyWith(
                      fontSize: 14, color: const Color(0XFF222222)),
                ),
                const SizedBox(
                  width: 3,
                ),
              ],
            ),
          ],
        ),
        trailing: Column(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            Text(
              "Comrade",
              style: medium.copyWith(fontSize: 12, color: Color(0XFFCCCCCC)),
            ),
            Text(
              "3h ago",
              style: medium.copyWith(fontSize: 12, color: Color(0XFFCCCCCC)),
            ),
          ],
        ),
      ),
    );
  }
}
