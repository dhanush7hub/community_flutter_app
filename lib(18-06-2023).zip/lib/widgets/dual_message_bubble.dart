import 'package:flutter/material.dart';

class dual_message_bubble extends StatelessWidget {
  final bool isme;
  final String message;

  const dual_message_bubble(this.isme, this.message);

  @override
  Widget build(BuildContext context) {
    final double maxWidth = MediaQuery.of(context).size.width * 0.8;

    return isme
        ? Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Container(
                constraints: BoxConstraints(maxWidth: maxWidth),
                padding: const EdgeInsets.symmetric(
                  vertical: 14,
                  horizontal: 16,
                ),
                margin: EdgeInsets.only(
                  top: 5,
                  bottom: 5,
                  left: isme ? 0 : 15,
                  right: isme ? 15 : 0,
                ),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5),
                  color:
                      isme ? const Color(0XFF8D88CE) : const Color(0XFF7DB0FD),
                ),
                child: Text(
                  message,
                  style: TextStyle(
                    color: Colors.white,
                  ),
                ),
              ),
            ],
          )
        : Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                constraints: BoxConstraints(maxWidth: maxWidth),
                padding: const EdgeInsets.symmetric(
                  vertical: 14,
                  horizontal: 16,
                ),
                margin: EdgeInsets.only(
                  top: 5,
                  bottom: 5,
                  left: isme ? 0 : 15,
                  right: isme ? 15 : 0,
                ),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5),
                  color:
                      isme ? const Color(0XFF8D88CE) : const Color(0XFF7DB0FD),
                ),
                child: Text(
                  message,
                  style: TextStyle(
                    color: Colors.white,
                  ),
                ),
              ),
            ],
          );
  }
}
