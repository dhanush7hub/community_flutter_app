import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:specialchat/screens/groupinfopage.dart';
import 'package:specialchat/screens/mainpage.dart';
import 'package:specialchat/widgets/containermessage.dart';
import 'package:specialchat/widgets/widgets.dart';

class GroupScreen extends StatelessWidget {
  bool issearch;
  List groupname = [];
  List groupimg = [];
  List<dynamic> _roomids;

  GroupScreen(
    this.issearch,
    this.groupname,
    this.groupimg,
    this._roomids,
  );

  @override
  Widget build(BuildContext context) {
    return issearch
        ? ListView.builder(
            itemCount: groupname.length,
            itemBuilder: (BuildContext context, int index) {
              return InkWell(
                onTap: () async {
                  final doc = await FirebaseFirestore.instance
                      .collection('publicgroups')
                      .doc(_roomids[index].toString())
                      .get();
                  final data = doc.data() as Map<String, dynamic>;
                  nextpage(
                      context,
                      GroupinfoPage(
                        groupId: data["roomid"],
                        private: false,
                        sourceurl: data["profile_url"],
                        groupname: data["groupname"],
                        description: data["group_des"],
                        createdBy: data["created_by"],
                        groupLink: data["group_link"],
                        createdAt: data["created_at"].toDate(),
                      ));
                },
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundImage: NetworkImage(groupimg[index]),
                  ),
                  title: Text(
                    groupname[index],
                    style: medium.copyWith(fontSize: 14),
                  ),
                ),
              );
            },
          )
        : FutureBuilder(
            future: Future.value(FirebaseAuth.instance.currentUser),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(
                  child: CircularProgressIndicator(),
                );
              }
              return StreamBuilder(
                  stream: FirebaseFirestore.instance
                      .collection(
                          "multipleconversationlist/${FirebaseAuth.instance.currentUser!.uid}/conversationwith")
                      .snapshots(),
                  builder: (context, snap) {
                    if (snap.connectionState == ConnectionState.waiting) {
                      return const Center(
                        child: CircularProgressIndicator(),
                      );
                    }
                    final chatdocs = snap.data!.docs;
                    print("############################");
                    print(chatdocs.length);
                    return ListView.builder(
                      itemCount: chatdocs.length,
                      itemBuilder: (context, index) {
                        return containermessage(
                          false,
                          chatdocs[index]["profile_url"],
                          chatdocs[index]["groupname"],
                          chatdocs[index]["lastmessage"],
                          chatdocs[index]["groupid"],
                          chatdocs[index]["myprofile_url"],
                          chatdocs[index]["privategroup"],
                          chatdocs[index]["created_at"],
                          chatdocs[index]["created_by"],
                          chatdocs[index]["group_link"],
                          chatdocs[index]["group_des"],
                        );
                      },
                    );
                  });
            });
  }
}
