import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:specialchat/screens/groupchatpage.dart';
import 'package:specialchat/screens/personalchatpage.dart';
import 'package:specialchat/widgets/widgets.dart';

class containermessage extends StatefulWidget {
  String sourceurl;
  String containername;
  String recentmessage;
  bool ismessagepage;
  String roomid;
  String myprofile_url;
  bool _private;
  Timestamp createdAt;
  String createdBy;
  String groupLink;
  String description;

  containermessage(
      this.ismessagepage,
      this.sourceurl,
      this.containername,
      this.recentmessage,
      this.roomid,
      this.myprofile_url,
      this._private,
      this.createdAt,
      this.createdBy,
      this.groupLink,
      this.description);

  @override
  State<containermessage> createState() => _containermessageState();
}

class _containermessageState extends State<containermessage> {
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        print(widget.roomid +
            "ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ");
        widget.ismessagepage
            ? nextpage(
                context,
                PersonalchatPage(widget.sourceurl, widget.containername,
                    widget.roomid, widget.myprofile_url))
            : nextpage(
                context,
                groupchatpage(
                    widget.sourceurl,
                    widget.containername,
                    widget.roomid,
                    widget.myprofile_url,
                    widget._private,
                    widget.createdAt.toDate(),
                    widget.createdBy,
                    widget.groupLink,
                    widget.description));
      },
      child: ListTile(
        leading: CircleAvatar(
          backgroundImage: NetworkImage(widget.sourceurl),
        ),
        title: Text(
          widget.containername,
          style: medium.copyWith(fontSize: 14),
        ),
        subtitle: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Text(
                  widget.recentmessage,
                  style: regular.copyWith(
                      fontSize: 14, color: const Color(0XFF222222)),
                ),
                const SizedBox(
                  width: 3,
                ),
              ],
            ),
          ],
        ),
        trailing: Column(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            Text(
              "3h ago",
              style: medium.copyWith(fontSize: 12, color: Color(0XFFCCCCCC)),
            ),
            CircleAvatar(
              radius: 8.5,
              backgroundColor: const Color(0XFF7DB1FD),
              child: Text(
                "2",
                textAlign: TextAlign.center,
                style: regular.copyWith(fontSize: 12, color: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
