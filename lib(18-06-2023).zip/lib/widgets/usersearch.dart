import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:specialchat/services/database_service.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class SearchPage extends StatefulWidget {
  @override
  _SearchPageState createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  final TextEditingController _searchController = TextEditingController();
  final DatabaseService _databaseService = DatabaseService();
  List<DocumentSnapshot> _usernames = [];

  void _onSearchTextChanged(String query) async {
    if (query.isEmpty) {
      setState(() {
        _usernames = [];
      });
      return;
    }

    final snapshot = await _databaseService.getUsernames();
    final filteredUsernames = snapshot.docs
        .where((doc) =>
            doc.get('username').toLowerCase().contains(query.toLowerCase()))
        .toList();

    setState(() {
      _usernames = filteredUsernames;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: TextField(
          controller: _searchController,
          onChanged: _onSearchTextChanged,
          decoration: InputDecoration(
            hintText: 'Search...',
          ),
        ),
      ),
      body: ListView.builder(
        itemCount: _usernames.length,
        itemBuilder: (context, index) {
          final username = _usernames[index].get('username');
          final uid = _usernames[index].get('uid');

          return ListTile(
            title: Text(username),
            subtitle: Text(uid),
          );
        },
      ),
    );
  }
}

class DatabaseService {
  final CollectionReference usernamesCollection =
      FirebaseFirestore.instance.collection('usernames');

  Future<QuerySnapshot> getUsernames() async {
    return await usernamesCollection.get();
  }
}
