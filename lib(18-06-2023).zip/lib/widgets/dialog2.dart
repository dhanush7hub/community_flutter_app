import 'package:flutter/material.dart';
import 'package:specialchat/widgets/widgets.dart';

class dialog2 extends StatelessWidget {
  const dialog2({super.key});

  @override
  Widget build(BuildContext context) {
    return Dialog(
      child: SizedBox(
        height: 360,
        width: 300,
        child: Container(
          padding: EdgeInsets.all(20),
          child: Column(
            children: [
              Text(
                'Group Privacy',
                style: semibold.copyWith(
                  fontSize: 19,
                  letterSpacing: -0.2,
                  fontWeight: FontWeight.w600,
                ),
              ),
              SizedBox(
                height: 10,
              ),
              CircleAvatar(
                radius: 30,
                //  backgroundImage: AssetImage(
                //   'assets/images/group_pic.png',
                //  ),
              ),
              SizedBox(
                height: 5,
              ),
              Text(
                'Tamil Rockstars',
                style: light.copyWith(
                  letterSpacing: -0.2,
                  fontSize: 13,
                  fontWeight: FontWeight.w400,
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Column(
                children: [
                  Text(
                    'Invite people via Group link',
                    style: light.copyWith(
                      fontSize: 18,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Text(
                    'Soora.app/group/Tamil%20Boys',
                    style: light.copyWith(
                      fontSize: 16,
                      color: Color(0XFF3E84EA),
                    ),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  SizedBox(
                    height: 45,
                    width: double.infinity,
                    child: OutlinedButton(
                      style: OutlinedButton.styleFrom(
                        side: BorderSide(
                          color: Color(0XFF3E84EA),
                        ),
                      ),
                      onPressed: () {},
                      child: Text(
                        'Copy Link',
                        style: light.copyWith(
                          color: Color(0XFF3E84EA),
                          fontWeight: FontWeight.w400,
                          fontSize: 20,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                ],
              ),
              ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: Text("Done"))
            ],
          ),
        ),
      ),
    );
  }
}
