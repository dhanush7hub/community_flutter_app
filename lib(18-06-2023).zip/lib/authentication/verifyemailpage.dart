import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:specialchat/authentication/confirmagepage.dart';
import 'package:specialchat/services/database_service.dart';
import 'package:specialchat/widgets/widgets.dart';

class Verifyemailpage extends StatefulWidget {
  const Verifyemailpage({super.key});

  @override
  State<Verifyemailpage> createState() => _VerifyemailpageState();
}

class _VerifyemailpageState extends State<Verifyemailpage> {
  bool isemailverified = false;
  Timer? timer;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    isemailverified = FirebaseAuth.instance.currentUser!.emailVerified;

    if (FirebaseAuth.instance.currentUser == null) {
      return;
    }
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    timer?.cancel();
  }

  Future checkemailverified() async {
    await FirebaseAuth.instance.currentUser!.reload();

    setState(() {
      isemailverified = FirebaseAuth.instance.currentUser!.emailVerified;
    });

    if (isemailverified) {
      timer?.cancel();
      await DatabaseService().modifiyingverified(isemailverified);
    }
  }

  Future sendverificationemail() async {
    try {
      final user = FirebaseAuth.instance.currentUser!;
      await user.sendEmailVerification();
    } catch (e) {}
  }

  @override
  Widget build(BuildContext context) => isemailverified
      ? Confirmagepage()
      : Scaffold(
          body: Center(
            child: ElevatedButton(
              onPressed: () {
                if (!isemailverified) {
                  sendverificationemail();
                  showsnackbar(context, Colors.black,
                      "Verification Link sent Check your email!");
                  timer = Timer.periodic(
                    Duration(seconds: 3),
                    (timer) => checkemailverified(),
                  );
                }
              },
              child: Text("Send Verification Link to Email"),
            ),
          ),
        );
}
