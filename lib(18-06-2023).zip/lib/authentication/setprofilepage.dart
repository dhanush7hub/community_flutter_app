import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:specialchat/screens/mainpage.dart';
import 'package:specialchat/services/database_service.dart';
import 'package:specialchat/widgets/widgets.dart';
import 'dart:io';
import 'dart:typed_data';

class Setprofilepage extends StatefulWidget {
  bool editprofile;

  Setprofilepage(this.editprofile);

  @override
  State<Setprofilepage> createState() => _SetprofilepageState();
}

class _SetprofilepageState extends State<Setprofilepage> {
  TextEditingController _namecontroller = TextEditingController();
  TextEditingController _aboutcontroller = TextEditingController();
  FocusNode focusnode = FocusNode();

  bool check1 = false;
  bool check2 = false;
  bool check3 = false;
  // String? imageUrl;
  File? _image;
  // var saveimage;
  PickedFile? image;
  final _imagePicker = ImagePicker();

  String? username;
  String? profileurl;

  Future<File?> uploadimage() async {
    final click = await ImagePicker().pickImage(
      source: ImageSource.camera,
      imageQuality: 50,
      maxWidth: 150,
    );
    setState(() {
      _image = File(click!.path);
    });
    return _image;
  }

  Future<File?> uploadimagegallery() async {
    final click = await ImagePicker().pickImage(
      source: ImageSource.gallery,
      imageQuality: 50,
      maxWidth: 150,
    );
    setState(() {
      _image = File(click!.path);
    });
    return _image;
  }

  Future<String?> uploadImageToFirebase(File image) async {
    final FirebaseAuth _auth = FirebaseAuth.instance;
    final User? user = _auth.currentUser;
    if (user != null) {
      final String uid = user.uid;
      String fileName = DateTime.now().millisecondsSinceEpoch.toString();
      FirebaseStorage storage = FirebaseStorage.instance;
      Reference reference = storage.ref().child("images/$uid/$fileName");
      UploadTask uploadTask = reference.putFile(image);
      TaskSnapshot storageTaskSnapshot = await uploadTask;
      String downloadUrl = await storageTaskSnapshot.ref.getDownloadURL();
      return downloadUrl;
    }
  }

  void showimageuploadoption(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (_) {
        return Container(
          margin: EdgeInsets.all(20),
          width: double.infinity,
          height: 100,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Theme(
                data: ThemeData(splashColor: maincolor),
                child: InkWell(
                  onTap: () {
                    Navigator.pop(context);
                    uploadimage();
                  },
                  child: Row(
                    children: [
                      const Icon(Icons.camera_alt_outlined),
                      const SizedBox(
                        width: 3,
                      ),
                      Text(
                        "Camera",
                        style: light.copyWith(fontSize: 14),
                      )
                    ],
                  ),
                ),
              ),
              const SizedBox(
                height: 5,
              ),
              Theme(
                data: ThemeData(splashColor: maincolor),
                child: InkWell(
                  onTap: () {
                    Navigator.pop(context);
                    uploadimagegallery(); // give change option
                  },
                  child: Row(
                    children: [
                      const Icon(Icons.image_outlined),
                      const SizedBox(
                        width: 3,
                      ),
                      Text(
                        "gallery",
                        style: light.copyWith(fontSize: 14),
                      )
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    widget.editprofile ? getdata() : null;
  }

  getdata() async {
    final snap = FirebaseFirestore.instance
        .collection("users")
        .doc(FirebaseAuth.instance.currentUser!.uid);
    final snapdoc = await snap.get();
    if (snapdoc.exists && snapdoc.data() != null) {
      setState(() {
        username = snapdoc.data()!['name'];
        profileurl = snapdoc.data()!['profilepic'];
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Form(
            child: Container(
          padding: const EdgeInsets.all(15),
          child: Column(
            children: [
              const SizedBox(
                height: 24,
              ),
              SizedBox(
                width: double.infinity,
                child: Text(
                  "StuFee",
                  style: extrabold.copyWith(
                    fontSize: 24,
                    letterSpacing: -2.5,
                  ),
                  textAlign: TextAlign.left,
                ),
              ),
              SizedBox(
                width: double.infinity,
                child: Text(
                  "We are comrades",
                  style: regular.copyWith(
                    color: subcolor,
                    fontSize: 10,
                  ),
                ),
              ),
              const SizedBox(
                height: 30,
              ),
              SizedBox(
                width: double.infinity,
                child: widget.editprofile
                    ? Text(
                        "Edit your profile",
                        style: semibold.copyWith(
                          fontSize: 24,
                          letterSpacing: -1.5,
                        ),
                      )
                    : Text(
                        "Set your profile",
                        style: semibold.copyWith(
                          fontSize: 24,
                          letterSpacing: -1.5,
                        ),
                      ),
              ),
              const SizedBox(
                height: 15,
              ),
              // widget.editprofile
              // profileurl != null
              // ?
              Center(
                child: GestureDetector(
                  onTap: () {
                    uploadimage();
                  },
                  // uploadimage,
                  child: widget.editprofile
                      ? CircleAvatar(
                          backgroundColor: subcolor,
                          radius: 50.0,
                          child: CircleAvatar(
                            backgroundColor: boxback,
                            radius: 48.0,
                            backgroundImage: profileurl != null
                                ? NetworkImage(profileurl!)
                                : null,
                            // _image != null ? FileImage(_image!) : null,
                            child: _image == null
                                ? IconButton(
                                    color: subcolor,
                                    icon: const Icon(Icons.add),
                                    onPressed: () {
                                      showimageuploadoption(context);
                                    })
                                : null,
                          ),
                        )
                      : CircleAvatar(
                          backgroundColor: subcolor,
                          radius: 50.0,
                          child: CircleAvatar(
                            backgroundColor: boxback,
                            radius: 48.0,
                            backgroundImage:
                                _image != null ? FileImage(_image!) : null,
                            child: _image == null
                                ? IconButton(
                                    color: subcolor,
                                    icon: const Icon(Icons.add),
                                    onPressed: () {
                                      showimageuploadoption(context);
                                    })
                                : null,
                          ),
                        ),
                ),
              ),
              // : CircularProgressIndicator(),
              const SizedBox(
                height: 15,
              ),
              Container(
                height: 36,
                decoration: BoxDecoration(
                  color: boxback,
                  borderRadius: BorderRadius.circular(5.0),
                ),
                child: widget.editprofile
                    ? TextFormField(
                        textAlignVertical: TextAlignVertical.center,
                        decoration: textfeilddec.copyWith(
                          contentPadding: const EdgeInsets.only(left: 10),
                          hintText: "User",
                          hintStyle: light.copyWith(
                            fontSize: 14,
                          ),
                        ),
                        onTap: () {},
                        controller: _namecontroller,
                      )
                    : TextFormField(
                        textAlignVertical: TextAlignVertical.center,
                        decoration: textfeilddec.copyWith(
                          contentPadding: const EdgeInsets.only(left: 10),
                          hintText: "Username (as unique as possible)*",
                          hintStyle: light.copyWith(
                            fontSize: 14,
                          ),
                        ),
                        onTap: () {},
                        controller: _namecontroller,
                      ),
              ),
              widget.editprofile
                  ? SizedBox(
                      height: 20,
                    )
                  : Container(
                      child: Column(
                        children: [
                          const SizedBox(
                            height: 15,
                          ),
                          Container(
                            height: 63,
                            decoration: BoxDecoration(
                              color: boxback,
                              borderRadius: BorderRadius.circular(5.0),
                            ),
                            child: TextFormField(
                              textAlignVertical: TextAlignVertical.center,
                              decoration: textfeilddec.copyWith(
                                contentPadding: const EdgeInsets.only(left: 10),
                                hintText: "Tell us about you",
                                hintStyle: light.copyWith(
                                  fontSize: 14,
                                ),
                              ),
                              onTap: () {},
                              controller: _aboutcontroller,
                            ),
                          ),
                          const SizedBox(
                            height: 15,
                          ),
                          SizedBox(
                              // width: MediaQuery.of(context).size.width,
                              child: Row(
                            children: [
                              Flexible(
                                flex: 1,
                                child: Checkbox(
                                  value: check1,
                                  onChanged: (value) {
                                    setState(() {
                                      check1 = value!;
                                      if (check1 == true) {
                                        check2 = false;
                                        check3 = false;
                                      }
                                    });
                                  },
                                ),
                              ),
                              const Flexible(flex: 1, child: Text("male")),
                              const SizedBox(
                                width: 15,
                              ),
                              Flexible(
                                flex: 1,
                                child: Checkbox(
                                  value: check2,
                                  onChanged: (value) {
                                    setState(() {
                                      check2 = value!;
                                      if (check2 == true) {
                                        check1 = false;
                                        check3 = false;
                                      }
                                    });
                                  },
                                ),
                              ),
                              const Flexible(flex: 1, child: Text("Female")),
                              Flexible(
                                flex: 1,
                                child: Checkbox(
                                  value: check3,
                                  onChanged: (value) {
                                    setState(() {
                                      check3 = value!;
                                      if (check3 == true) {
                                        check1 = false;
                                        check2 = false;
                                      }
                                    });
                                  },
                                ),
                              ),
                              const Flexible(flex: 1, child: Text("Other")),
                            ],
                          )),
                          const SizedBox(
                            height: 70,
                          ),
                        ],
                      ),
                    ),
              widget.editprofile
                  ? Row(
                      children: [
                        Container(
                          height: 40,
                          width: 72,
                          child: OutlinedButton(
                              style: OutlinedButton.styleFrom(
                                backgroundColor: Colors.white,
                                primary: maincolor,
                                side: BorderSide(color: maincolor, width: 1),
                              ),
                              onPressed: () {
                                Navigator.pop(context);
                              },
                              child: Text("Back")),
                        ),
                        const SizedBox(
                          width: 16,
                        ),
                        Container(
                          height: 40,
                          width: 240,
                          child: ElevatedButton(
                            onPressed: () {
                              // uploadage(_selectedDate.toIso8601String());
                            },
                            style: ButtonStyle(
                              backgroundColor:
                                  MaterialStateProperty.all<Color>(maincolor),
                            ),
                            child: Text(
                              "Done",
                              style: medium.copyWith(
                                fontSize: 16,
                              ),
                            ),
                          ),
                        ),
                      ],
                    )
                  : SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: () async {
                          print(_namecontroller.text);
                          print(_aboutcontroller.text);

                          if (_namecontroller.text.isNotEmpty &&
                              (_namecontroller.text.length >= 3) &&
                              _aboutcontroller.text.isNotEmpty &&
                              _aboutcontroller.text.length >= 3) {
                            print(
                                "lllllllllllllllllllllllllllllllllllllllllllllllllllllllllll");
                            String? imageUrl =
                                await uploadImageToFirebase(_image!);
                            print(
                                "lllllllllllllllllllllllllllllllllllllllllllllllllllllllllll");
                            print(imageUrl);
                            var val = checkedbox();
                            // making some issue
                            if (imageUrl!.isNotEmpty && val!.isNotEmpty) {
                              print(
                                  "objectttttttttttttttttttttttttttttttttttttttttttttttttttttttt");
                              print(
                                  "objectttttttttttttttttttttttttttttttttttttttttttttttttttttttt");
                              uploaddata(_namecontroller.text,
                                  _aboutcontroller.text, val, imageUrl);
                              nextpagereplace(context, Mainpage());
                            }
                          } else {
                            showsnackbar(context, Colors.red,
                                "please enter all the fieldsss!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                          }
                        },
                        style: ButtonStyle(
                          backgroundColor:
                              MaterialStateProperty.all<Color>(maincolor),
                        ),
                        child: Text(
                          "Create",
                          style: medium.copyWith(
                            fontSize: 16,
                          ),
                        ),
                      ),
                    )
            ],
          ),
        )),
      ),
    );
  }

  String? checkedbox() {
    if (check1 == true) {
      return ("male");
    } else {
      if (check2 == true) {
        print("female");
      } else {
        print("other");
      }
    }
  }

  uploaddata(Name, about, Gender, img) async {
    final FirebaseAuth _auth = FirebaseAuth.instance;
    final User? user = _auth.currentUser;
    if (user != null) {
      print(
          "objeiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii");
      await DatabaseService().savingUserDetails(Name, about, Gender, img);
    } else {
      print('User is not signed in.');
    }
  }
}
