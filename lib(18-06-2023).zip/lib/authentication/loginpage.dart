import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:specialchat/authentication/resetpassword.dart';
import 'package:specialchat/screens/mainpage.dart';
import 'package:specialchat/services/auth_service.dart';
import 'package:specialchat/services/database_service.dart';
import 'package:specialchat/widgets/widgets.dart';
import 'package:google_sign_in/google_sign_in.dart';

class Loginpage extends StatefulWidget {
  const Loginpage({super.key});

  @override
  State<Loginpage> createState() => _LoginpageState();
}

class _LoginpageState extends State<Loginpage> {
  static const decoration = InputDecoration(
    labelStyle: TextStyle(color: Colors.grey, fontWeight: FontWeight.w300),
    enabledBorder: OutlineInputBorder(
        borderSide:
            BorderSide(color: Color.fromARGB(255, 226, 225, 225), width: 2)),
    focusedBorder: OutlineInputBorder(
        borderSide:
            BorderSide(color: Color.fromARGB(255, 226, 225, 225), width: 2)),
    errorBorder:
        OutlineInputBorder(borderSide: BorderSide(color: Colors.red, width: 2)),
  );

  final formkey = GlobalKey<FormState>();
  final emailcontroller = TextEditingController();
  final passwordcontroller = TextEditingController();
  final GoogleSignIn _googleSignIn = GoogleSignIn();
  FocusNode focusnode = FocusNode();
  final FirebaseAuth _auth = FirebaseAuth.instance;
  bool obscuredtext = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Form(
          key: formkey,
          child: Container(
            margin: const EdgeInsets.all(15),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const SizedBox(
                  height: 24,
                ),
                SizedBox(
                  width: double.infinity,
                  child: Text(
                    "StuFee",
                    style: extrabold.copyWith(
                      fontSize: 24,
                    ),
                    textAlign: TextAlign.left,
                  ),
                ),
                SizedBox(
                  width: double.infinity,
                  child: Text(
                    "We are comrades",
                    style: regular.copyWith(
                      color: subcolor,
                      fontSize: 10,
                    ),
                  ),
                ),
                const SizedBox(
                  height: 30,
                ),
                SizedBox(
                  width: double.infinity,
                  child: Text(
                    "Login to your account",
                    style: semibold.copyWith(
                      color: Colors.black,
                      fontSize: 21,
                    ),
                    textAlign: TextAlign.left,
                  ),
                ),
                const SizedBox(
                  height: 30,
                ),
                Container(
                  width: double.infinity,
                  height: 40,
                  decoration: BoxDecoration(
                    color: boxback,
                    borderRadius: BorderRadius.circular(5.0),
                  ),
                  child: SizedBox(
                    width: double.infinity,
                    height: 40,
                    child: TextField(
                      decoration: textfeilddec.copyWith(
                        contentPadding: const EdgeInsets.only(left: 10),
                        hintText: "Email*",
                        hintStyle: light.copyWith(
                          fontSize: 16,
                        ),
                      ),
                      focusNode: focusnode,
                      onTap: () {
                        setState(() {
                          textfeilddec = textfeilddec.copyWith(
                            hintText: "",
                            hintStyle: const TextStyle(
                              fontSize: 14,
                            ),
                          );
                        });
                      },
                      controller: emailcontroller,
                      autofillHints: const [
                        'email',
                        'username',
                        'organization'
                      ],
                    ),
                  ),
                ),
                const SizedBox(
                  height: 15,
                ),
                Container(
                  width: double.infinity,
                  height: 40,
                  decoration: BoxDecoration(
                    color: boxback,
                    borderRadius: BorderRadius.circular(5.0),
                  ),
                  child: TextField(
                    decoration: textfeilddec.copyWith(
                        contentPadding: const EdgeInsets.only(left: 10),
                        hintText: "Create a password*",
                        hintStyle: light.copyWith(
                          fontSize: 16,
                        ),
                        suffixIcon: GestureDetector(
                          child: obscuredtext
                              ? const Icon(
                                  Icons.visibility_off,
                                  size: 18,
                                )
                              : const Icon(
                                  Icons.visibility,
                                  size: 18,
                                ),
                          onTap: () {
                            setState(() {
                              obscuredtext = !obscuredtext;
                            });
                          },
                        )),
                    controller: passwordcontroller,
                    obscureText: obscuredtext,
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                SizedBox(
                  width: double.infinity,
                  child: Text.rich(
                    TextSpan(
                        text: "Forget password?",
                        style:
                            light.copyWith(color: Colors.black, fontSize: 12),
                        children: [
                          TextSpan(
                              text: " Reset",
                              style: medium.copyWith(
                                  fontSize: 12, color: maincolor),
                              recognizer: TapGestureRecognizer()
                                ..onTap = () {
                                  nextpage(context, const resetpassword_page());
                                })
                        ]),
                    textAlign: TextAlign.right,
                  ),
                ),
                const SizedBox(
                  height: 15,
                ),
                SizedBox(
                  height: 40,
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () async {
                      await Authservice()
                          .loginUserWithEmailandPassword(
                              emailcontroller.text, passwordcontroller.text)
                          .then(
                        (value) async {
                          print(
                              "vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv");
                          print(value);
                          await DatabaseService().redirect(context);
                        },
                      );
                      // nextpage(context, Mainpage());
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: maincolor,
                      // primary: const Color.fromARGB(255, 227, 160, 27),
                    ),
                    child: Text(
                      "Login",
                      style: medium.copyWith(
                        color: Colors.white,
                        fontSize: 16,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
                const SizedBox(
                  height: 15,
                ),
                Text.rich(TextSpan(
                    text: "Dont have an account?",
                    style: light.copyWith(color: Colors.black, fontSize: 12),
                    children: [
                      TextSpan(
                          text: " Create",
                          style: medium.copyWith(
                            color: maincolor,
                            fontSize: 12,
                          ),
                          recognizer: TapGestureRecognizer()
                            ..onTap = () {
                              // nextpage(context, const Createaccount());
                            })
                    ])),
                const SizedBox(
                  height: 15,
                ),
                Row(
                  children: [
                    const Expanded(
                      child: Divider(
                        color: Color(0XFFD9D9D9),
                      ),
                    ),
                    Container(
                      margin: const EdgeInsets.all(5),
                      child: Text('Or signup with',
                          style:
                              light.copyWith(color: Colors.black, fontSize: 12)
                          // TextStyle(
                          //   color: Colors.black,
                          // ),
                          ),
                    ),
                    const Expanded(
                      child: Divider(
                        color: Color(0XFFD9D9D9),
                      ),
                    )
                  ],
                ),
                SizedBox(
                  height: 15,
                ),
                Container(
                  height: 36,
                  width: double.infinity,
                  child: OutlinedButton(
                      style: OutlinedButton.styleFrom(
                        backgroundColor: Colors.white,
                        primary: Colors.black,
                        side: BorderSide(color: Colors.black, width: 1),
                      ),
                      onPressed: () {
                        // _signInWithGoogle();
                      },
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.apple_rounded,
                            color: maincolor,
                          ),
                          Text("Sign up with google")
                        ],
                      )),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<User?> _signInWithGoogle() async {
    // Sign in with Google
    final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();

    if (googleUser != null) {
      // Obtain the auth details from the request
      final GoogleSignInAuthentication googleAuth =
          await googleUser.authentication;

      // Create a new credential
      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      // Sign in to Firebase with the Google credential
      final UserCredential userCredential =
          await _auth.signInWithCredential(credential);

      return userCredential.user;
    }
    nextpage(context, Mainpage());
    return null;
  }
}
