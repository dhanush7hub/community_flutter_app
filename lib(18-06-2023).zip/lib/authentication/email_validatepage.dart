// ignore_for_file: use_build_context_synchronously
import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:email_otp/email_otp.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:specialchat/authentication/verifyemailpage.dart';
import 'package:specialchat/authentication/confirmagepage.dart';
import 'package:specialchat/authentication/loginpage.dart';
import 'package:specialchat/services/auth_service.dart';
import 'package:specialchat/services/database_service.dart';
import 'package:specialchat/widgets/widgets.dart';
import 'package:google_sign_in/google_sign_in.dart';

class Email_validatepage extends StatefulWidget {
  const Email_validatepage({super.key});

  @override
  State<Email_validatepage> createState() => _CreateaccountState();
}

class _CreateaccountState extends State<Email_validatepage> {
  final formkey = GlobalKey<FormState>();
  final FocusNode focusnode = FocusNode();
  Authservice authservice = Authservice();
  final GoogleSignIn _googleSignIn = GoogleSignIn();
  final FirebaseAuth _auth = FirebaseAuth.instance;
  EmailOTP myauth = EmailOTP();
  bool obscuredtext1 = true;
  bool obscuredtext2 = true;
  bool checkbox = false;
  bool _isloading = false;
  bool emailerror = true; //false
  bool passworderror1 = true;
  bool passworderror2 = true;
  bool isEmailVerified = false;
  bool agree = false;
  bool reset = false;

  String emailval = "";
  String passwordval1 = "";
  String passwordval2 = "";
  // final String _note =
  //     "Password must be equal to or greater than 8 characters collection of letters numbers and symbols.";

  bool isemailverified = false;
  Timer? timer;

  @override
  void dispose() {
    // TODO: implement dispose

    super.dispose();
    timer?.cancel();
  }

  Future checkemailverified() async {
    await FirebaseAuth.instance.currentUser!.reload();

    setState(() {
      isemailverified = FirebaseAuth.instance.currentUser!.emailVerified;
    });

    if (isemailverified) {
      timer?.cancel();
      await DatabaseService().modifiyingverified(isemailverified);
    }
  }

  Future sendverificationemail() async {
    try {
      final user = FirebaseAuth.instance.currentUser!;
      await user.sendEmailVerification();
    } catch (e) {}
  }

  @override
  Widget build(BuildContext context) => !isemailverified
      ? Scaffold(
          body: _isloading
              ? const Center(
                  child: CircularProgressIndicator(),
                )
              : SingleChildScrollView(
                  child: Form(
                    key: formkey,
                    autovalidateMode: AutovalidateMode.onUserInteraction,
                    child: Container(
                      padding: const EdgeInsets.all(15),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          const SizedBox(
                            height: 24,
                          ),
                          SizedBox(
                            width: double.infinity,
                            child: Text(
                              "StuFee",
                              style: extrabold.copyWith(
                                fontSize: 21,
                                letterSpacing: -2.5,
                              ),
                              textAlign: TextAlign.left,
                            ),
                          ),
                          SizedBox(
                            width: double.infinity,
                            child: Text(
                              "We are comrades",
                              style: regular.copyWith(
                                color: subcolor,
                                fontSize: 9,
                              ),
                            ),
                          ),
                          const SizedBox(
                            height: 30,
                          ),
                          SizedBox(
                            width: double.infinity,
                            child: Text(
                              "Create a new account",
                              style: semibold.copyWith(
                                fontSize: 21,
                                letterSpacing: -1.5,
                              ),
                            ),
                          ),
                          const SizedBox(
                            height: 15,
                          ),
                          Container(
                              height: 36,
                              decoration: BoxDecoration(
                                color: boxback,
                                borderRadius: BorderRadius.circular(5.0),
                              ),
                              child: TextFormField(
                                // enabled: emaillock ? false : true,
                                autocorrect: false,
                                decoration: textfeilddec.copyWith(
                                  contentPadding: const EdgeInsets.only(
                                      left: 10, bottom: 10),
                                  hintText: "Email*",
                                  hintStyle: light.copyWith(
                                    fontSize: 14,
                                  ),
                                  suffixIcon: emailval.isEmpty
                                      ? null
                                      : emailval.toString().isNotEmpty &&
                                              RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
                                                  .hasMatch(emailval.toString())
                                          ? const Icon(
                                              Icons.check,
                                              color: check,
                                            )
                                          : const Icon(
                                              Icons.close,
                                              color: close,
                                            ),
                                ),
                                onChanged: (value) {
                                  setState(() {
                                    emailval = value;
                                  });
                                },
                                validator: (value) {
                                  emailval.toString().isNotEmpty &&
                                          RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
                                              .hasMatch(emailval.toString())
                                      ? emailerror = false
                                      : emailerror = true;
                                  return null;
                                },
                              )),
                          const SizedBox(
                            height: 15,
                          ),
                          Container(
                            height: 36,
                            decoration: BoxDecoration(
                              color: boxback,
                              borderRadius: BorderRadius.circular(5.0),
                            ),
                            child: TextFormField(
                              // enabled: emaillock ? true : false,
                              obscureText: obscuredtext1,
                              autocorrect: false,
                              // rest of config...
                              decoration: textfeilddec.copyWith(
                                contentPadding:
                                    const EdgeInsets.only(left: 10, bottom: 10),
                                hintText: "Create a password*",
                                hintStyle: light.copyWith(
                                  fontSize: 14,
                                ),
                                suffixIcon: GestureDetector(
                                  child: obscuredtext1
                                      ? const Icon(
                                          Icons.visibility_off,
                                          size: 18,
                                        )
                                      : const Icon(
                                          Icons.visibility,
                                          size: 18,
                                        ),
                                  onTap: () {
                                    setState(() {
                                      obscuredtext1 = !obscuredtext1;
                                    });
                                  },
                                ),
                              ),
                              onChanged: (value) {
                                setState(() {
                                  passwordval1 = value;
                                });
                              },
                              validator: (value) {
                                passwordval1.toString().isNotEmpty &&
                                        RegExp(r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,}$')
                                            .hasMatch(passwordval1.toString())
                                    ? passworderror1 = false
                                    : passworderror1 = true;
                                return null;
                              },
                            ),
                          ),
                          if (passworderror1)
                            const Text(
                              "Password must be equal to or greater than 8 characters collection of letters numbers and symbols.",
                              style: TextStyle(
                                  color: Colors.black54, fontSize: 10),
                              textAlign: TextAlign.left,
                            ),
                          const SizedBox(
                            height: 15,
                          ),
                          Container(
                            height: 36,
                            decoration: BoxDecoration(
                              color: boxback,
                              borderRadius: BorderRadius.circular(5.0),
                            ),
                            child: TextFormField(
                                // enabled: emaillock ? true : false,
                                obscureText: obscuredtext2,
                                autocorrect: false,
                                // rest of config...
                                decoration: textfeilddec.copyWith(
                                  contentPadding: const EdgeInsets.only(
                                      left: 10, bottom: 10),
                                  hintText: "Re-enter password",
                                  hintStyle: light.copyWith(
                                    fontSize: 14,
                                  ),
                                  suffixIcon: GestureDetector(
                                    child: obscuredtext2
                                        ? const Icon(
                                            Icons.visibility_off,
                                            size: 18,
                                          )
                                        : const Icon(
                                            Icons.visibility,
                                            size: 18,
                                          ),
                                    onTap: () {
                                      setState(() {
                                        obscuredtext2 = !obscuredtext2;
                                      });

                                      //commented on 15/06/2023 at 19:36 for entering 3rd block
                                      // (value) {
                                      //   setState(() {
                                      //     passwordval2 = value;
                                      //   });
                                      // };
                                    },
                                  ),
                                ),
                                onChanged: (value) {
                                  setState(() {
                                    passwordval2 = value;
                                  });
                                },
                                validator: (value) {
                                  ((passwordval2.toString().isNotEmpty &&
                                              RegExp(r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,}$')
                                                  .hasMatch(passwordval1
                                                      .toString())) &&
                                          (passwordval2 == passwordval1))
                                      ? passworderror2 = false
                                      : passworderror2 = true;
                                  return null;
                                }),
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Transform.scale(
                                scale: 0.8,
                                child: Checkbox(
                                  activeColor: subcolor,
                                  value: checkbox,
                                  onChanged: (value) {
                                    setState(() {
                                      // ((emailerror &&
                                      //             passworderror1 &&
                                      //             passworderror2) ==
                                      //         0)
                                      a
                                      if (!(emailerror &&
                                          passworderror1 &&
                                          passworderror2)) {
                                        setState(() {
                                          checkbox = value!;
                                        });
                                      } else {
                                        setState(() {
                                          checkbox = false;
                                        });
                                      }
                                    });
                                  },
                                ),
                              ),
                              Expanded(
                                child: Text.rich(
                                  TextSpan(
                                    text: " I agree and accept all the",
                                    style: light.copyWith(
                                      fontSize: 10,
                                    ),
                                    recognizer: TapGestureRecognizer()
                                      ..onTap = () {
                                        setState(() {
                                          checkbox = !checkbox;
                                        });
                                      },
                                    children: [
                                      TextSpan(
                                          text: " Terms of service",
                                          recognizer: TapGestureRecognizer()
                                            ..onTap = () {},
                                          style: medium.copyWith(
                                              color: maincolor, fontSize: 10)),
                                      TextSpan(
                                        text: " and",
                                        style: light.copyWith(
                                          fontSize: 10,
                                        ),
                                        recognizer: TapGestureRecognizer()
                                          ..onTap = () {
                                            setState(() {
                                              checkbox = !checkbox;
                                            });
                                          },
                                      ),
                                      TextSpan(
                                        text: " Privacy policy",
                                        style: medium.copyWith(
                                            color: maincolor, fontSize: 10),
                                        recognizer: TapGestureRecognizer()
                                          ..onTap = () {},
                                      )
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(
                            height: 8,
                          ),
                          SizedBox(
                            width: double.infinity,
                            height: 36,
                            child: !checkbox
                                ? ElevatedButton(
                                    onPressed: null,
                                    style: ButtonStyle(
                                      backgroundColor:
                                          MaterialStateProperty.all<Color>(
                                              maincolor),
                                    ),
                                    child: Text(
                                      "Create",
                                      style: medium.copyWith(
                                        fontSize: 15,
                                      ),
                                    ),
                                  )
                                : ElevatedButton(
                                    onPressed: () {
                                      register();
                                    },
                                    style: ButtonStyle(
                                      backgroundColor:
                                          MaterialStateProperty.all<Color>(
                                              maincolor),
                                    ),
                                    child: Text(
                                      "Create",
                                      style: medium.copyWith(
                                        fontSize: 16,
                                      ),
                                    ),
                                  ),
                          ),
                          const SizedBox(
                            height: 15,
                          ),
                          SizedBox(
                            child: Column(
                              children: [
                                Text.rich(TextSpan(
                                  text: "Already have an account?",
                                  style: light.copyWith(
                                    fontSize: 11,
                                  ),
                                  children: [
                                    TextSpan(
                                        text: "  Login",
                                        style: medium.copyWith(
                                            fontSize: 11, color: maincolor),
                                        recognizer: TapGestureRecognizer()
                                          ..onTap = () {
                                            nextpage(
                                                context, const Loginpage());
                                          }),
                                  ],
                                )),
                              ],
                            ),
                          ),
                          const SizedBox(
                            height: 15,
                          ),
                          Row(
                            children: [
                              const Expanded(
                                child: Divider(
                                  color: Color(0XFFD9D9D9),
                                ),
                              ),
                              Container(
                                margin: const EdgeInsets.all(5),
                                child: Text('Or signup with',
                                    style: light.copyWith(
                                        color: Colors.black, fontSize: 12)
                                    // TextStyle(
                                    //   color: Colors.black,
                                    // ),
                                    ),
                              ),
                              const Expanded(
                                child: Divider(
                                  color: Color(0XFFD9D9D9),
                                ),
                              )
                            ],
                          ),
                          const SizedBox(
                            height: 15,
                          ),
                          Container(
                            height: 36,
                            width: double.infinity,
                            child: OutlinedButton(
                                style: OutlinedButton.styleFrom(
                                  backgroundColor: Colors.white,
                                  primary: Colors.black,
                                  side: const BorderSide(
                                      color: Colors.black, width: 1),
                                ),
                                onPressed: () async {
                                  final User? user = await _signInWithGoogle();
                                  if (user != null) {
                                    // User signed in
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                        content: Text('Signed in successfully'),
                                      ),
                                    );
                                    nextpage(context, Confirmagepage());
                                  } else {
                                    // User cancelled sign-in
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                        content: Text('Sign-in cancelled'),
                                      ),
                                    );
                                  }
                                },
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: const [
                                    Icon(
                                      Icons.apple_rounded,
                                      color: maincolor,
                                    ),
                                    Text("Sign up with google")
                                  ],
                                )),
                          )
                        ],
                      ),
                    ),
                  ),
                ),
        )
      : Confirmagepage();

//&& passworderror1 && passworderror2

  void register() async {
    print("helloooooooooooooooooooo");
    if (!(emailerror)) {
      print("entered layer 1");
      if (!(passworderror1)) {
        print("entered layer 2");
        print(passworderror1);
        print(passworderror2);
        print(
            "jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj");
        print(passwordval1);
        print(passwordval2);
        if (!(passworderror2)) {
          print("entered layer 3");
          if (formkey.currentState!.validate()) {
            print("entered layer 4");
            setState(() {
              _isloading = true;
            });
            await authservice
                .registerUserWithEmailandPassword(
              emailval.toString(),
              passwordval1.toString(),
            )
                .then((value) async {
              print("---------------------------------------------");
              if (value == true) {
                await DatabaseService().savingUserData(emailval.toString());
                setState(() {
                  _isloading = false;
                });
                isemailverified =
                    await FirebaseAuth.instance.currentUser!.emailVerified;
                if (!isemailverified) {
                  sendverificationemail();
                  showsnackbar(context, Colors.black,
                      "Verification Link sent Check your email!");
                  setState(() {
                    emailval = "";
                    emailerror = true;
                    checkbox = false;
                  });
                  print(emailval +
                      "jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj");
                  //a
                  timer = Timer.periodic(
                    Duration(seconds: 3),
                    (timer) => checkemailverified(),
                  );
                }
              } else {
                setState(() {
                  emailval = "";
                  emailerror = true;
                  checkbox = false;
                });
                setState(() {
                  _isloading = false;
                });
                showsnackbar(
                    context, Colors.red, "there is an error in signing in");
              }
            });
          }
        } else {}
      } else {}
    } else {
      print("1st error layer////////////////////////////////////////////");
    }
  }

  Future<User?> _signInWithGoogle() async {
    // Sign in with Google
    final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
    if (googleUser != null) {
      // Obtain the auth details from the request
      final GoogleSignInAuthentication googleAuth =
          await googleUser.authentication;
      // Create a new credential
      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );
      // Sign in to Firebase with the Google credential
      final UserCredential userCredential =
          await _auth.signInWithCredential(credential);
      return userCredential.user;
    }
    return null;
  }
}
