import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:specialchat/authentication/loginpage.dart';
import 'package:specialchat/widgets/widgets.dart';

class resetpassword_page extends StatefulWidget {
  const resetpassword_page({super.key});

  @override
  State<resetpassword_page> createState() => _resetpassword_pageState();
}

class _resetpassword_pageState extends State<resetpassword_page> {
  final formkey = GlobalKey<FormState>();
  FocusNode focusnode = FocusNode();
  TextEditingController emailcontroller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Form(
          key: formkey,
          child: Container(
            margin: const EdgeInsets.all(15),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const SizedBox(
                  height: 24,
                ),
                SizedBox(
                  width: double.infinity,
                  child: Text(
                    "StuFee",
                    style: extrabold.copyWith(
                      fontSize: 21,
                      letterSpacing: -2.5,
                    ),
                    textAlign: TextAlign.left,
                  ),
                ),
                SizedBox(
                  width: double.infinity,
                  child: Text(
                    "We are comrades",
                    style: regular.copyWith(
                      color: subcolor,
                      fontSize: 9,
                    ),
                  ),
                ),
                const SizedBox(
                  height: 34,
                ),
                SizedBox(
                  width: double.infinity,
                  child: Text(
                    "Reset password",
                    style: semibold.copyWith(
                      color: Colors.black,
                      fontSize: 21,
                    ),
                    textAlign: TextAlign.left,
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                SizedBox(
                  width: double.infinity,
                  child: Text(
                    "Enter your email to continue",
                    style: light.copyWith(
                      color: Colors.black,
                      fontSize: 14,
                    ),
                    textAlign: TextAlign.left,
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),
                SizedBox(
                  width: double.infinity,
                  height: 40,
                  child: TextField(
                    decoration: textfeilddec.copyWith(
                      contentPadding: const EdgeInsets.only(left: 10),
                      hintText: "Email*",
                      hintStyle: light.copyWith(
                        fontSize: 16,
                      ),
                    ),
                    focusNode: focusnode,
                    onTap: () {
                      setState(() {
                        textfeilddec = textfeilddec.copyWith(
                          hintText: "",
                          hintStyle: const TextStyle(
                            fontSize: 14,
                          ),
                        );
                      });
                    },
                    controller: emailcontroller,
                    autofillHints: const ['email', 'username', 'organization'],
                  ),
                ),
                const SizedBox(
                  height: 35,
                ),
                SizedBox(
                  height: 40,
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () async {
                      await reset(emailcontroller.text);
                      nextpagereplace(context, Loginpage());
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: maincolor,
                      // primary: const Color.fromARGB(255, 227, 160, 27),
                    ),
                    child: Text(
                      "Continue",
                      style: medium.copyWith(
                        color: Colors.white,
                        fontSize: 16,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
                const SizedBox(
                  height: 15,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> reset(String email) async {
    try {
      await FirebaseAuth.instance.sendPasswordResetEmail(email: email);
      showsnackbar(context, Colors.red,
          "Password reset email sent, change the password by clicking on the email and try to login again");
      print('Password reset email sent');
    } catch (e) {
      print('Error sending password reset email: $e');
    }
  }
}
