import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:specialchat/authentication/setprofilepage.dart';
import 'package:specialchat/services/database_service.dart';
import 'package:specialchat/widgets/widgets.dart';

class Confirmagepage extends StatefulWidget {
  const Confirmagepage({super.key});

  @override
  State<Confirmagepage> createState() => _CreateaccountState();
}

class _CreateaccountState extends State<Confirmagepage> {
  final formkey = GlobalKey<FormState>();
  final FocusNode focusnode = FocusNode();
  TextEditingController datecontroller = TextEditingController();
  bool _isloading = false;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  // bool emailerror = false;
  bool passworderror1 = false;
  bool passworderror2 = false;
  bool isEmailVerified = false;
  bool agree = false;

  DateTime _selectedDate = DateTime.now();
  // Timer? timer;
  String emailval = "";
  String passwordval1 = "";
  String _passwordval2 = "";
  final String _note =
      "Password must be equal to or greater than 8 characters collection of letters numbers and symbols.";

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
        context: context,
        initialDate: DateTime.now(),
        firstDate: DateTime(1998),
        lastDate: DateTime.now());

    if (picked != null && picked != _selectedDate) {
      setState(() {
        print(_selectDate.toString());
        _selectedDate = picked;
      });
    }
  }

  TextEditingController Selectingdate() {
    String formattedDate = DateFormat('dd/MM/yyyy').format(_selectedDate);
    setState(() {
      datecontroller.text = formattedDate;
    });
    return datecontroller;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _isloading
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : SingleChildScrollView(
              child: Form(
                key: formkey,
                autovalidateMode: AutovalidateMode.onUserInteraction,
                child: Container(
                  padding: const EdgeInsets.all(15),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      const SizedBox(
                        height: 24,
                      ),
                      SizedBox(
                        width: double.infinity,
                        child: Text(
                          "StuFee",
                          style: extrabold.copyWith(
                            fontSize: 21,
                            letterSpacing: -2.5,
                          ),
                          textAlign: TextAlign.left,
                        ),
                      ),
                      SizedBox(
                        width: double.infinity,
                        child: Text(
                          "We are comrades",
                          style: regular.copyWith(
                            color: subcolor,
                            fontSize: 9,
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 30,
                      ),
                      SizedBox(
                        width: double.infinity,
                        child: Text(
                          "Confirm your aget",
                          style: semibold.copyWith(
                            fontSize: 21,
                            letterSpacing: -1.5,
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 15,
                      ),
                      Container(
                        height: 36,
                        decoration: BoxDecoration(
                          color: boxback,
                          borderRadius: BorderRadius.circular(5.0),
                        ),
                        child: TextFormField(
                          decoration: textfeilddec.copyWith(
                            contentPadding: const EdgeInsets.only(left: 10),
                            hintText:
                                datecontroller.text.isEmpty ? "dd/MM/YYYY" : "",

                            // __selectedDate != null
                            //     ? DateFormat("dd/MM/yyyy").format(__selectedDate!)
                            //     : "DD/MM/YYYY",
                            hintStyle: light.copyWith(
                              fontSize: 12,
                              color: Colors.black,
                            ),
                            suffixIcon: const Icon(
                              Icons.calendar_month_outlined,
                            ),
                          ),
                          onTap: () async {
                            await _selectDate(context);
                            Selectingdate();
                          },
                          controller: datecontroller,
                        ),
                      ),
                      const SizedBox(
                        height: 250,
                      ),
                      Row(
                        children: [
                          Container(
                            height: 40,
                            width: 72,
                            child: OutlinedButton(
                                style: OutlinedButton.styleFrom(
                                  backgroundColor: Colors.white,
                                  primary: maincolor,
                                  side: BorderSide(color: maincolor, width: 1),
                                ),
                                onPressed: () {
                                  Navigator.pop(context);
                                },
                                child: Text("Back")),
                          ),
                          const SizedBox(
                            width: 16,
                          ),
                          Container(
                            height: 40,
                            width: 240,
                            child: ElevatedButton(
                              onPressed: () {
                                uploadage(_selectedDate.toIso8601String());
                              },
                              style: ButtonStyle(
                                backgroundColor:
                                    MaterialStateProperty.all<Color>(maincolor),
                              ),
                              child: Text(
                                "Continue",
                                style: medium.copyWith(
                                  fontSize: 16,
                                ),
                              ),
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              ),
            ),
    );
  }

  uploadage(DOB) async {
    final User? user = _auth.currentUser;
    if (user != null) {
      try {
        await DatabaseService(uid: user.uid).savingbirthdate(DOB);
        nextpagereplace(context, Setprofilepage(false));
      } catch (e) {
        print(e);
      }
    } else {
      print('User is not signed in.');
    }
  }
}
