import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Helperfunctions {
  //keys
  static String userloggedinkey = "LOGGEDINKEY";
  static String useremailkey = "USEREMAILKEY";
  static String userpasswordkey = "USERPASSWORDKEY";
  static String userdobkey = "USERDOBKEY";
  static String usernamekey = "USERNAMEKEY";
  static String useraboutkey = "USERABOUTKEY";
  static String usergenderkey = "USERGENDERKEY";

  //saving the data to sf
  static Future<bool> saveuserloggedinkey(bool isuserloggedin) async {
    SharedPreferences sf = await SharedPreferences.getInstance();
    return await sf.setBool(userloggedinkey, isuserloggedin);
  }

  static Future<bool> saveuseremailkey(String useremail) async {
    SharedPreferences sf = await SharedPreferences.getInstance();
    return await sf.setString(useremailkey, useremail);
  }

  static Future<bool> saveuserpasswordkey(String password) async {
    SharedPreferences sf = await SharedPreferences.getInstance();
    return await sf.setString(userpasswordkey, password);
  }

  // static Future<bool> saveuserdobkey(String dob) async {
  //   SharedPreferences sf = await SharedPreferences.getInstance();
  //   return await sf.setString(userdobkey, dob);
  // }

  // static Future<bool> saveusernamekey(String username) async {
  //   SharedPreferences sf =
  //       await SharedPreferences.getInstance(); // still not entered name
  //   return await sf.setString(usernamekey, username);
  // }

  // static Future<bool> saveuseraboutkey(String about) async {
  //   SharedPreferences sf = await SharedPreferences.getInstance();
  //   return await sf.setString(useraboutkey, about);
  // }

  // static Future<bool> saveusergenderkey(String Gender) async {
  //   SharedPreferences sf = await SharedPreferences.getInstance();
  //   return await sf.setString(usergenderkey, Gender);
  // }

  //
  //
  //getting the data from sf
  //
  //

  static Future<bool?> getuserloggedinstatus() async {
    SharedPreferences sf = await SharedPreferences.getInstance();
    return sf.getBool(userloggedinkey);
  }

  // static Future<String?> getuseremailkey() async {
  //   SharedPreferences sf = await SharedPreferences.getInstance();
  //   return sf.getString(useremailkey);
  // }

  // static Future<String?> getuserpasswordkey() async {
  //   SharedPreferences sf = await SharedPreferences.getInstance();
  //   return sf.getString(userpasswordkey);
  // }

  // static Future<String?> getuserdobkey() async {
  //   SharedPreferences sf = await SharedPreferences.getInstance();
  //   return sf.getString(userdobkey);
  // }

  // static Future<String?> getusernamekey() async {
  //   SharedPreferences sf =
  //       await SharedPreferences.getInstance(); // still not entered name
  //   return sf.getString(usernamekey);
  // }

  // static Future<String?> getuseraboutkey() async {
  //   SharedPreferences sf = await SharedPreferences.getInstance();
  //   return sf.getString(useraboutkey);
  // }

  // static Future<String?> getusergenderkey() async {
  //   SharedPreferences sf = await SharedPreferences.getInstance();
  //   return sf.getString(usergenderkey);
  // }
}
