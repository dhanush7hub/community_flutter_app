import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:specialchat/authentication/email_validatepage.dart';
import 'package:specialchat/screens/vidtemp.dart';
import 'package:specialchat/services/database_service.dart';

//NC5gEFqiF3N5GQRZRe4OIes2tmZ2
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: MyApp(),
  ));
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return FirebaseAuth.instance.currentUser != null
        ? FutureBuilder(
            future: FirebaseFirestore.instance
                .collection("users")
                .doc(FirebaseAuth.instance.currentUser!.uid)
                .get(),
            builder: (context, snapshot) {
              if (snapshot.hasData) {
                DatabaseService().redirect(context);
              }
              return const Scaffold(
                body: Center(child: CircularProgressIndicator()),
              );
            },
          )
        : Email_validatepage();
  }
}
