import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_switch/flutter_switch.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:specialchat/services/database_service.dart';
import 'package:specialchat/widgets/dialog1.dart';
import 'package:specialchat/widgets/widgets.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
//


class Creategroup extends StatefulWidget {
  @override
  State<Creategroup> createState() => _CreategroupState();
}

class _CreategroupState extends State<Creategroup> {
  TextEditingController groupname = TextEditingController();
  TextEditingController description = TextEditingController();

  File? _image;

  // var saveimage;
  PickedFile? image;

  final _imagePicker = ImagePicker();

  Future<File?> uploadimage() async {
    final click = await ImagePicker().pickImage(
      source: ImageSource.camera,
      imageQuality: 50,
      maxWidth: 150,
    );
    // File? take = File(click!.path);
    // take = await _cropImage(imageFile: take);
    // setState(() {
    //   _image = take;
    // });
    // return _image;
    setState(() {
      _image = File(click!.path);
    });
  }

  Future<File?> _cropImage({required File imageFile}) async {
    CroppedFile? croppedImage =
        await ImageCropper().cropImage(sourcePath: imageFile.path);
    if (croppedImage == null) return null;
    return File(croppedImage.path);
  }

  Future<File?> uploadimagegallery() async {
    final click = await ImagePicker().pickImage(
      source: ImageSource.gallery,
      imageQuality: 50,
      maxWidth: 150,
    );
    setState(() {
      _image = File(click!.path);
    });
    return _image;
  }

  void showimageuploadoption(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (_) {
        return Container(
          margin: EdgeInsets.all(20),
          width: double.infinity,
          height: 100,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Theme(
                data: ThemeData(splashColor: maincolor),
                child: InkWell(
                  onTap: () {
                    Navigator.pop(context);
                    uploadimage();
                  },
                  child: Row(
                    children: [
                      const Icon(Icons.camera_alt_outlined),
                      const SizedBox(
                        width: 3,
                      ),
                      Text(
                        "Camera",
                        style: light.copyWith(fontSize: 14),
                      )
                    ],
                  ),
                ),
              ),
              const SizedBox(
                height: 5,
              ),
              Theme(
                data: ThemeData(splashColor: maincolor),
                child: InkWell(
                  onTap: () {
                    Navigator.pop(context);
                    uploadimagegallery(); // give change option
                  },
                  child: Row(
                    children: [
                      const Icon(Icons.image_outlined),
                      const SizedBox(
                        width: 3,
                      ),
                      Text(
                        "gallery",
                        style: light.copyWith(fontSize: 14),
                      )
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'StuFee.',
          style: extrabold.copyWith(
            color: Colors.black,
            letterSpacing: -2.5,
            fontSize: 24,
          ),
        ),
        backgroundColor: Colors.white,
        elevation: 0,
        actions: [
          IconButton(
            onPressed: () {},
            icon: Icon(
              Icons.search,
              color: Colors.black,
            ),
          ),
          IconButton(
            onPressed: () {},
            icon: Icon(
              Icons.menu_rounded,
              color: Colors.black,
            ),
          ),
        ],
      ),
      body: Container(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Text(
                  'Create Group',
                  style: semibold.copyWith(
                    fontSize: 24,
                    letterSpacing: -1.5,
                  ),
                ),
              ],
            ),
            SizedBox(height: 10),
            Center(
              child: GestureDetector(
                onTap: () {
                  uploadimage();
                },
                // uploadimage,
                child: CircleAvatar(
                  backgroundColor: subcolor,
                  radius: 50.0,
                  child: CircleAvatar(
                    backgroundColor: boxback,
                    radius: 48.0,
                    backgroundImage: _image != null ? FileImage(_image!) : null,
                    child: _image == null
                        ? IconButton(
                            color: subcolor,
                            icon: const Icon(Icons.add),
                            onPressed: () {
                              showimageuploadoption(context);
                            })
                        : null,
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Container(
              height: 40,
              decoration: BoxDecoration(
                color: Color(0XFFEFF1F5),
                borderRadius: BorderRadius.circular(5.0),
              ),
              child: TextFormField(
                autocorrect: false,
                decoration: textfeilddec.copyWith(
                  contentPadding: const EdgeInsets.only(left: 10, bottom: 10),
                  hintText: "Group Name",
                  hintStyle: light.copyWith(
                    fontSize: 14,
                  ),
                ),
                controller: groupname,
                // onChanged: (value) {
                //   groupname = value;
                // },
              ),
            ),
            SizedBox(
              height: 15,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Text(
                  'Group Description',
                  style: medium.copyWith(
                    fontSize: 15,
                    letterSpacing: -1,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 5,
            ),
            Container(
              height: 100,
              decoration: BoxDecoration(
                color: Color(0XFFEFF1F5),
                borderRadius: BorderRadius.circular(5.0),
              ),
              child: TextFormField(
                autocorrect: false,
                textInputAction: TextInputAction.newline,
                maxLines: null,
                decoration: textfeilddec.copyWith(
                  contentPadding: const EdgeInsets.only(left: 10, bottom: 10),
                  hintText: "Add a description here",
                  hintStyle: light.copyWith(
                    fontSize: 15,
                  ),
                ),
                controller: description,
                // onChanged: (value) {
                //   description = value;
                // },
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Row(
              children: [
                SizedBox(
                  height: 35,
                  child: OutlinedButton(
                    style: OutlinedButton.styleFrom(
                      side: BorderSide(
                        color: Color(0XFF7DB1FD),
                      ),
                    ),
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    child: Text(
                      'Back',
                      style: light.copyWith(
                          color: Color(0XFF7DB1FD),
                          fontWeight: FontWeight.w400),
                    ),
                  ),
                ),
                SizedBox(
                  width: 15,
                ),
                Expanded(
                    child:
                        //  Popup_box1(
                        //   // "hello",
                        //   // "hi",
                        //   groupname,
                        //   description,
                        //   image_loc.toString(),
                        // ),
                        Container(
                  height: 35,
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () async {
                      // final url = await DatabaseService()
                      //     .uploadImageToFirebase(_image)
                      //     .toString();
                      showDialog(
                          context: context,
                          builder: (context) {
                            return dialog1(
                                groupname.text, description.text, _image!);
                          });
                    },
                    style: ElevatedButton.styleFrom(
                      primary: Color(0XFF7DB1FD),
                    ),
                    child: Text(
                      'Create',
                      style: light,
                    ),
                  ),
                )),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
