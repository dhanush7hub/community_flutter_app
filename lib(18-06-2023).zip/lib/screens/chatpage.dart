import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:specialchat/screens/creategroup.dart';
import 'package:specialchat/screens/profile.dart';
import 'package:specialchat/screens/temp.dart';
import 'package:specialchat/services/dynamiclink_service.dart';
import 'package:specialchat/widgets/comradeofweek.dart';
import 'package:specialchat/widgets/groups.dart';
import 'package:specialchat/widgets/messages.dart';
import 'package:flutter_switch/flutter_switch.dart';
import 'package:specialchat/widgets/usersearch.dart';

import '../widgets/widgets.dart';

class Chat_Page extends StatefulWidget {
  const Chat_Page({Key? key}) : super(key: key);

  @override
  State<Chat_Page> createState() => _Chat_PageState();
}

class _Chat_PageState extends State<Chat_Page> with TickerProviderStateMixin {
  String Search = "";
  bool isSearch = false;
  List<Widget> body = [];
  List<dynamic> _searchResults = [];
  List<dynamic> _searchprofile = [];
  List<dynamic> _searchroomid = [];
  List<dynamic> _searchabout = [];
  List<dynamic> _searchid = [];
  bool ongrouppage = true;
  bool isToggled = true;
  late TabController tabController;
  late String username;
  late String profileurl;
  late String about;

  Future<void> _searchNames(String query) async {
    print("adsfffffasdafdsfdddddddddddddddddddddddddddddddddddddddddddddd");
    print(ongrouppage);
    print(FirebaseAuth.instance.currentUser!.uid);

    final QuerySnapshot<Map<String, dynamic>> snapshot = ongrouppage
        ? await FirebaseFirestore.instance
            .collection('users')
            .where('name', isGreaterThanOrEqualTo: query)
            .where('name', isLessThanOrEqualTo: '$query\uf8ff')
            .get()
        : await FirebaseFirestore.instance
            .collection('publicgroups')
            .where('groupname', isGreaterThanOrEqualTo: query)
            .where('groupname', isLessThanOrEqualTo: '$query\uf8ff')
            .get();
    final List results = ongrouppage
        ? snapshot.docs.map((doc) => doc.data()['name']).toList()
        : snapshot.docs.map((doc) => doc.data()['groupname']).toList();
    final List profiles = ongrouppage
        ? snapshot.docs.map((doc) => doc.data()['profilepic']).toList()
        : snapshot.docs.map((doc) => doc.data()['profile_url']).toList();
    final List roomids = ongrouppage
        ? snapshot.docs.map((doc) => doc.data()['roomid']).toList()
        : snapshot.docs.map((doc) => doc.data()['roomid']).toList();
    final List abouts = ongrouppage
        ? snapshot.docs.map((doc) => doc.data()['about']).toList()
        : snapshot.docs.map((doc) => doc.data()['group_des']).toList();
    final List id = ongrouppage
        ? snapshot.docs.map((doc) => doc.data()['uid']).toList()
        : snapshot.docs.map((doc) => doc.data()['roomid']).toList();
    print("mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm");
    setState(() {
      _searchResults = results;
      _searchprofile = profiles;
      _searchroomid = roomids;
      _searchabout = abouts;
      _searchid = id;
    });
  }

  @override
  void initState() {
    tabController = TabController(length: 2, vsync: this);
// TODO: implement initState
    super.initState();
    getdata();
  }

  @override
  void dispose() {
    tabController.dispose();
    super.dispose();
  }

  getdata() async {
    final snap = FirebaseFirestore.instance
        .collection("users")
        .doc(FirebaseAuth.instance.currentUser!.uid);
    final snapdoc = await snap.get();
    if (snapdoc.exists && snapdoc.data() != null) {
      setState(() {
        username = snapdoc.data()!['name'];
        profileurl = snapdoc.data()!['profilepic'];
        about = snapdoc.data()!['about'];
      });
    }
  }

  Widget _buildSearchBar() {
    return Container(
      // color: Colors.amber,
      child: Row(
        children: [
          // Padding(
          //   padding: EdgeInsets.symmetric(horizontal: 5),
          //   child:
          IconButton(
            onPressed: () {
              setState(() {
                isSearch = false;
                Search = "";
              });
            },
            icon: Icon(Icons.arrow_back, color: Colors.black),
            // ),
          ),

          Expanded(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 2),
              child: SizedBox(
                width: 294,
                height: 38,
                child: TextFormField(
                  onChanged: (value) async {
                    Search = value;
                    await _searchNames(value);
                  },
                  onFieldSubmitted: (value) async {
                    // var usersRef =
                    //     FirebaseFirestore.instance.collection('usernames');

                    // var querySnapshot = await usersRef
                    //     .where('name', isEqualTo: value)
                    //     .limit(1)
                    //     .get();

                    // if (querySnapshot.docs.isNotEmpty) {
                    //   var userId = querySnapshot.docs.first.data()['uid'];
                    //   print('User ID for $value: $userId');
                    // } else {
                    //   print('No document found with name=$value');
                    // }
                  },
                  decoration: textfeilddec.copyWith(
                    contentPadding: const EdgeInsets.only(left: 10, bottom: 10),
                    hintText: 'Search',
                    hintStyle: light.copyWith(
                      fontSize: 14,
                    ),
                    suffixIcon: Icon(
                      Icons.search,
                    ),
                  ),
                ),
              ),
            ),
          ),

          // Expanded(
          //   child: Padding(
          //     padding: EdgeInsets.symmetric(horizontal: 2),
          //     child: TextFormField(
          //         onChanged: (value) async {
          //           Search = value;
          //           await _searchNames(value);
          //         },
          //         onFieldSubmitted: (value) async {
          //           var usersRef =
          //               FirebaseFirestore.instance.collection('usernames');

          //           var querySnapshot = await usersRef
          //               .where('name', isEqualTo: value)
          //               .limit(1)
          //               .get();

          //           if (querySnapshot.docs.isNotEmpty) {
          //             var userId = querySnapshot.docs.first.data()['uid'];
          //             print('User ID for $value: $userId');
          //           } else {
          //             print('No document found with name=$value');
          //           }
          //         },
          //         decoration: textfeilddec.copyWith(
          //           contentPadding: const EdgeInsets.only(left: 10, bottom: 10),
          //           hintText: 'Search',
          //           hintStyle: light.copyWith(
          //             fontSize: 14,
          //           ),
          //           suffixIcon: Icon(
          //             Icons.search,

          //           ),
          //         )

          //         ),
          //   ),
          // ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
          backgroundColor: Colors.white,
          appBar: AppBar(
            automaticallyImplyLeading: false,
            title: !isSearch
                ? Text.rich(TextSpan(
                    text: "Soora",
                    style: extrabold.copyWith(
                      color: Colors.black,
                      fontSize: 24,
                    ),
                    children: [
                        TextSpan(
                          text: " .",
                          style:
                              extrabold.copyWith(color: subcolor, fontSize: 24),
                        )
                      ]))
                : _buildSearchBar(),
            backgroundColor: const Color.fromARGB(255, 255, 255, 255),
            elevation: 0,
            actions: isSearch
                ? []
                : [
                    IconButton(
                      onPressed: () {
                        setState(() {
                          isSearch = true;
                          ongrouppage = tabController.index == 1 ? true : false;
                          tabController.animateTo(ongrouppage ? 1 : 0);
                          print('Selected tab index: ${tabController.index}');
                        });
                      },
                      icon: const Icon(
                        Icons.search_outlined,
                        color: Colors.black,
                        size: 26,
                      ),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    IconButton(
                      onPressed: () {
                        showDialog(
                          context: context,
                          builder: (BuildContext context) {
                            return SimpleDialog(
                              children: <Widget>[
                                SimpleDialogOption(
                                  onPressed: () {
                                    nextpage(context, Creategroup());
                                  },
                                  child: Text('New Group'),
                                ),
                                SimpleDialogOption(
                                  onPressed: () {
                                    print(
                                        "ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZz");
                                    print(username + profileurl + about);
                                    nextpage(context,
                                        profile(username, profileurl, about));
                                  },
                                  child: Text('Profile'),
                                ),
                                SimpleDialogOption(
                                  onPressed: () async {
                                    // final v = await FirebaseDynamicLinkService
                                    //     .createDynamicLink(false);
                                    // print(v);
                                  },
                                  child: Text('Settings aka dynamic link'),
                                ),
                              ],
                            );
                          },
                        );
                      },
                      icon: const Icon(
                        Icons.menu_rounded,
                        color: Colors.black,
                      ),
                    ),
                  ],
          ),
          body: Container(
            child: Column(
              children: [
                Container(
                  margin: EdgeInsets.only(left: 15, top: 10, right: 15),
                  height: 60,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    border: Border.all(width: 0.7, color: Colors.grey),
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(50),
                  ),
                  child: Column(
                    children: [
                      Padding(
                        padding: EdgeInsets.all(5),
                        child: TabBar(
                          controller: tabController,
                          labelColor: Colors.white,
                          unselectedLabelColor: Colors.black,
                          indicatorColor: Colors.purple.withOpacity(0.5),
                          indicatorWeight: 2,
                          indicator: BoxDecoration(
                              color: subcolor,
                              borderRadius: BorderRadius.circular(50)),
                          tabs: const [
                            Tab(
                              child: Text(
                                "Groups",
                                style: TextStyle(
                                    fontWeight: FontWeight.w600, fontSize: 16),
                              ),
                            ),
                            Tab(
                              child: Text(
                                "Messages",
                                style: TextStyle(
                                    fontWeight: FontWeight.w600, fontSize: 16),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: TabBarView(
                    controller: tabController,
                    children: [
                      GroupScreen(Search.isNotEmpty, _searchResults,
                          _searchprofile, _searchroomid),
                      // Column(
                      //   children: [
                      //     Container(
                      //       margin: EdgeInsets.only(
                      //           top: 8, bottom: 8, left: 15, right: 15),
                      //       child: Row(
                      //         mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      //         children: [
                      //           Text(
                      //             "comrade for the week",
                      //             style: light.copyWith(fontSize: 14),
                      //           ),
                      //           FlutterSwitch(
                      //             height: 20.0,
                      //             width: 35.0,
                      //             padding: 4.0,
                      //             toggleSize: 10.0,
                      //             borderRadius: 20.0,
                      //             activeColor: maincolor,
                      //             value: isToggled,
                      //             onToggle: (value) {
                      //               setState(
                      //                 () {
                      //                   isToggled = value;
                      //                 },
                      //               );
                      //             },
                      //           ),
                      //         ],
                      //       ),
                      //     ),
                      //     SizedBox(
                      //       height: 8,
                      //     ),
                      //     true
                      //         ? StreamBuilder(
                      //             stream: FirebaseFirestore.instance
                      //                 .collection(
                      //                     "comradeconversation/${FirebaseAuth.instance.currentUser!.uid}/comrade")
                      //                 .snapshots(),
                      //             builder: (context, snap) {
                      //               if (snap.connectionState ==
                      //                   ConnectionState.waiting) {
                      //                 return const Center(
                      //                   child: CircularProgressIndicator(),
                      //                 );
                      //               }
                      //               final chatdocs = snap.data!.docs;

                      //               return comradeofweek(
                      //                 chatdocs[0]['profile'],
                      //                 chatdocs[0]['comradename'],
                      //                 chatdocs[0]['lastmessage'],
                      //                 chatdocs[0]['roomid'],
                      //                 chatdocs[0]['myprofile'],
                      //               );
                      //             })
                      // : Text("no comrade exists"),
                      Messages(
                        Search.isNotEmpty,
                        _searchResults,
                        _searchprofile,
                        _searchroomid,
                        _searchabout,
                        _searchid,
                      ),
                      //   ],
                      // ),
                    ],
                  ),
                ),
              ],
            ),
          )),
    );
  }
}
