// import 'package:specialchat/screens/chatpage.dart';
// import 'package:specialchat/widgets/widgets.dart';
// import './homepage.dart';
// import 'package:google_nav_bar/google_nav_bar.dart';
// import 'package:flutter/material.dart';

// class Mainpage extends StatefulWidget {
//   @override
//   State<Mainpage> createState() => _MainpageState();
// }

// class _MainpageState extends State<Mainpage> {
//   @override
//   int currentindex = 0;
//   int Toggleindex = 0;

//   List<Widget> body = [
//     Homepage(),
//     // Icon(Icons.home_rounded),
//     Chat_Page(),
//   ];

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       extendBody: true,
//       body: Container(
//         color: Colors.transparent,
//         alignment: Alignment.center,
//         child: body[currentindex],
//       ),
//       bottomNavigationBar: Container(
//         margin: EdgeInsets.symmetric(horizontal: 100, vertical: 25),
//         decoration: BoxDecoration(
//           border: Border.all(color: Colors.grey, width: 0.2),
//           color: Colors.white.withOpacity(0.8),
//           borderRadius: BorderRadius.circular(50),
//         ),
//         padding: EdgeInsets.symmetric(horizontal: 7, vertical: 7),
//         child: GNav(
//           onTabChange: (index) {
//             setState(() {
//               currentindex = index;
//             });
//           },
//           backgroundColor: Colors.transparent,
//           color: Colors.black,
//           activeColor: Colors.white,
//           tabBackgroundColor: subcolor,
//           padding: EdgeInsets.all(17),
//           gap: 8,
//           tabs: [
//             GButton(
//               icon: Icons.home,
//               text: "Home",
//               textSize: 100,
//             ),
//             GButton(
//               icon: Icons.chat,
//               text: "Chat",
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }

import 'package:specialchat/screens/chatpage.dart';
import 'package:specialchat/widgets/widgets.dart';
import '../services/dynamiclink_service.dart';
import './homepage.dart';
import 'package:google_nav_bar/google_nav_bar.dart';
import 'package:flutter/material.dart';

class Mainpage extends StatefulWidget {
  @override
  State<Mainpage> createState() => _MainpageState();
}

class _MainpageState extends State<Mainpage> {
  @override
  void initState() {
    FirebaseDynamicLinkService.initDynamicLink(context);

    // TODO: implement initState
    super.initState();
  }

  int currentIndex = 0;
  final PageController _pageController = PageController();
  List<Widget> pages = [
    Homepage(),
    Chat_Page(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      body: PageView(
        controller: _pageController,
        children: pages,
        onPageChanged: (index) {
          setState(() {
            currentIndex = index;
          });
        },
      ),
      bottomNavigationBar: Container(
        margin: EdgeInsets.symmetric(horizontal: 100, vertical: 25),
        decoration: BoxDecoration(
          border: Border.all(color: Colors.grey, width: 0.2),
          color: Colors.white.withOpacity(0.8),
          borderRadius: BorderRadius.circular(50),
        ),
        padding: EdgeInsets.symmetric(horizontal: 7, vertical: 7),
        child: GNav(
          selectedIndex: currentIndex,
          onTabChange: (index) {
            setState(() {
              currentIndex = index;
              _pageController.jumpToPage(index);
            });
          },
          backgroundColor: Colors.transparent,
          color: Colors.black,
          activeColor: Colors.white,
          tabBackgroundColor: subcolor,
          padding: EdgeInsets.all(17),
          gap: 8,
          tabs: [
            GButton(
              icon: Icons.home,
              text: "Home",
              textSize: 100,
            ),
            GButton(
              icon: Icons.chat,
              text: "Chat",
            ),
          ],
        ),
      ),
    );
  }
}
