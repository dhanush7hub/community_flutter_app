import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:specialchat/services/database_service.dart';
import 'package:specialchat/widgets/dual_message_bubble.dart';
import 'package:specialchat/widgets/multiple_message_bubble.dart';
import 'package:specialchat/widgets/widgets.dart';
import 'package:collection/collection.dart';
import 'package:specialchat/widgets/widgets.dart';

class InteractionPage extends StatelessWidget {
  String _posturl;
  String _content;
  String _roomid;
  // String _myprofile_url;

  InteractionPage(this._posturl, this._content, this._roomid);

  TextEditingController personalcontroller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          const SizedBox(
            height: 25,
          ),
          Container(
            width: double.infinity,
            height: 78,
            padding: const EdgeInsets.all(8),
            decoration: const BoxDecoration(),
            child: Row(
              children: [
                IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: const Icon(
                      Icons.arrow_back,
                    )),
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                        color: Color.fromARGB(255, 249, 251, 255),
                        border: Border.all(color: Color(0XFF7DB1FD))),
                    padding: EdgeInsets.all(10),
                    child: Row(
                      children: [
                        Container(
                          height: 50,
                          width: 50,
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(
                                15.0), // Adjust the radius as desired
                            child: Image.network(_posturl),
                          ),
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Expanded(
                          child: SizedBox(
                            child: Text(
                              _content,
                              overflow: TextOverflow.ellipsis,
                              maxLines: 2,
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(
            height: 10,
          ),
          Expanded(
            child: Container(
                child: FutureBuilder(
                    future: Future.value(FirebaseAuth.instance.currentUser),
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return const Center(
                          child: CircularProgressIndicator(),
                        );
                      }
                      return StreamBuilder(
                        stream: FirebaseFirestore.instance
                            .collection("interaction/$_roomid/message")
                            .orderBy("timestamp", descending: true)
                            .snapshots(),
                        builder: (context, snap) {
                          if (snap.connectionState == ConnectionState.waiting) {
                            return const Center(
                              child: CircularProgressIndicator(),
                            );
                          }
                          final chatdocs = snap.data!.docs;
                          final groups = groupBy(chatdocs, (doc) {
                            final date = DateTime.fromMillisecondsSinceEpoch(
                                doc["timestamp"].millisecondsSinceEpoch);
                            final now = DateTime.now();
                            final yesterday =
                                DateTime(now.year, now.month, now.day - 1);
                            if (date.year == now.year &&
                                date.month == now.month &&
                                date.day == now.day) {
                              return "Today";
                            } else if (date.year == yesterday.year &&
                                date.month == yesterday.month &&
                                date.day == yesterday.day) {
                              return "Yesterday";
                            } else {
                              return "${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}";
                            }
                          });
                          return Expanded(
                            child: ListView.builder(
                              reverse: true,
                              itemCount: groups.length,
                              itemBuilder: (BuildContext context, int index) {
                                final group = groups.entries.elementAt(index);
                                final dateStr = group.key;
                                final dateDivider = Container(
                                  margin: EdgeInsets.only(top: 10, bottom: 10),
                                  child: Row(
                                    children: [
                                      const Expanded(
                                          child: Divider(
                                        color: Color(0XFFDDDBF0),
                                        thickness: 1,
                                      )),
                                      Container(
                                        margin: const EdgeInsets.only(
                                            left: 5, right: 5),
                                        child: Text(
                                          dateStr,
                                          style: light.copyWith(
                                              color: Color(0XFFDDDBF0)),
                                        ),
                                      ),
                                      const Expanded(
                                          child: Divider(
                                        color: Color(0XFFDDDBF0),
                                        thickness: 1,
                                      )),
                                    ],
                                  ),
                                );
                                final messageBubbles = group.value
                                    .map((doc) {
                                      return MultipleMessageBubble(
                                          doc["uid"] ==
                                                  FirebaseAuth
                                                      .instance.currentUser!.uid
                                              ? true
                                              : false,
                                          doc["text"],
                                          doc["myprofile_url"]);
                                    })
                                    .toList()
                                    .reversed;
                                return Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    dateDivider,
                                    ...messageBubbles,
                                  ],
                                );
                              },
                            ),
                          );
                        },
                      );
                    })),
          ),
          Row(
            children: [
              Expanded(
                child: Container(
                  margin: EdgeInsets.only(right: 40),
                  padding: EdgeInsets.all(15),
                  color: Colors.white,
                  child: TextField(
                    decoration: textfeilddecchat.copyWith(
                      contentPadding: EdgeInsets.all(12),
                      hintText: 'Type something...',
                      labelStyle: light.copyWith(fontSize: 10),
                    ),
                    controller: personalcontroller,
                  ),
                ),
              ),
              IconButton(
                onPressed: () {
                  if (personalcontroller.text.isNotEmpty) {
                    DatabaseService().savinginteractionchat(
                      FirebaseAuth.instance.currentUser!.uid,
                      personalcontroller.text,
                      _roomid,
                    );
                    personalcontroller.clear();
                  }
                },
                icon: Icon(Icons.send),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
