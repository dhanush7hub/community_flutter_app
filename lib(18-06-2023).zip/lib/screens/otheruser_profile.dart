import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_switch/flutter_switch.dart';
import 'package:specialchat/screens/personalchatpage.dart';
import 'package:specialchat/widgets/widgets.dart';
import 'package:uuid/uuid.dart';

class UserProfilePage extends StatefulWidget {
  String username, profile_url, about, otheruid;
  UserProfilePage(this.username, this.profile_url, this.about, this.otheruid);

  @override
  State<UserProfilePage> createState() => _UserProfilePageState();
}

class _UserProfilePageState extends State<UserProfilePage> {
  void fun(bool value) {}

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.username,
          style: medium.copyWith(
            color: Colors.black,
            fontSize: 15,
          ),
        ),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: IconThemeData(
          color: Colors.black, // Set the desired color for the back arrow
        ),
      ),
      body: SingleChildScrollView(
        child: Container(
          width: double.infinity,
          margin: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: screenWidth,
                height: screenWidth,
                decoration: BoxDecoration(
                  color: Colors.grey,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Image.network(
                  widget.profile_url,
                  fit: BoxFit.cover,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                widget.about,
                style: TextStyle(fontSize: 16, height: 1.5),
              ),
              const SizedBox(height: 10),
              SizedBox(
                width: double.infinity,
                child: SizedBox(
                  height: 40,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      primary: Color.fromARGB(255, 125, 176, 253),
                    ),
                    onPressed: () async {
                      String _roomid = "";

                      final snap = FirebaseFirestore.instance.collection(
                          "dualconversationlist/${FirebaseAuth.instance.currentUser!.uid}/conversationwith");
                      DocumentReference docRef = snap.doc(widget.otheruid);

                      docRef.get().then((DocumentSnapshot docSnapshot) async {
                        if (docSnapshot.exists) {
                          Map<String, dynamic>? data =
                              docSnapshot.data() as Map<String, dynamic>?;
                          // The document exists
                          nextpage(
                              context,
                              PersonalchatPage(
                                  widget.profile_url,
                                  widget.username,
                                  data!["roomid"],
                                  widget.profile_url));
                          print("Document exists");
                        } else {
                          // The document does not exist
                          final uniquetime = await Uuid().v1();
                          setState(() {
                            _roomid = uniquetime +
                                FirebaseAuth.instance.currentUser!.uid;
                          });
                          final snap = FirebaseFirestore.instance
                              .collection(
                                  "dualconversationlist/${FirebaseAuth.instance.currentUser!.uid}/conversationwith")
                              .doc(widget.otheruid);
                          final snapdocs = snap.set({
                            "profile_url": widget.profile_url,
                            "username": widget.username,
                            "lastmessage": "Say hi",
                            "roomid": _roomid,
                            "myprofile_url":
                                "https://yourname.com", // "uid": uid,
                          });
                          print("Document does not exist");
                          nextpage(
                              context,
                              PersonalchatPage(
                                  widget.profile_url,
                                  widget.username,
                                  _roomid,
                                  widget.profile_url));
                        }
                      });

                      // final snap = FirebaseFirestore.instance
                      //     .collection("messages/$_roomid/message");
                      // final snapdocs = snap.add({
                      //   "uid": uid,
                      //   "text": text,
                      //   "timestamp": DateTime.now(),
                      // });
                    },
                    child: const Text(
                      "Message",
                      style: TextStyle(fontSize: 16),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  const Expanded(child: Text("Mute Notifications")),
                  FlutterSwitch(
                    height: 20.0,
                    width: 35.0,
                    padding: 4.0,
                    toggleSize: 10.0,
                    borderRadius: 20.0,
                    activeColor: Color.fromARGB(255, 141, 136, 206),
                    value: true,
                    onToggle: (value) {},
                  ),
                ],
              ),
              const SizedBox(height: 16),
              const Text("Report"),
              const SizedBox(height: 16),
              const Text(
                "Block user",
                style: TextStyle(color: Colors.red),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
