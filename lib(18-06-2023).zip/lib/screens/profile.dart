import 'package:flutter/material.dart';
import 'package:specialchat/authentication/setprofilepage.dart';
import 'package:specialchat/widgets/widgets.dart';

import '../services/dynamiclink_service.dart';

class profile extends StatefulWidget {
  String username;
  String profileurl;
  String about;

  profile(this.username, this.profileurl, this.about);

  @override
  State<profile> createState() => _profileState();
}

class _profileState extends State<profile> {

  @override
  void initState() {
    FirebaseDynamicLinkService.initDynamicLink(context);
    // TODO: implement initState
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    return Scaffold(
        appBar: AppBar(
          title: Text(
            widget.username,
            style: medium.copyWith(
              color: Colors.black,
              fontSize: 15,
            ),
          ),
          backgroundColor: Colors.white,
          elevation: 0,
          iconTheme: IconThemeData(
            color: Colors.black, // Set the desired color for the back arrow
          ),
        ),
        body: Container(
          width: double.infinity,
          margin: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: screenWidth,
                height: screenWidth,
                decoration: BoxDecoration(
                  color: Colors.grey,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Image.network(
                  widget.profileurl,
                  fit: BoxFit.cover,
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              Text(
                widget.about,
                style: TextStyle(fontSize: 16, height: 1.5),
              ),
              const SizedBox(
                height: 10,
              ),
              SizedBox(
                width: double.infinity,
                child: SizedBox(
                    height: 40,
                    child: OutlinedButton(
                        onPressed: () {
                          nextpage(context, Setprofilepage(true));
                        },
                        style: OutlinedButton.styleFrom(
                          side: BorderSide(
                              width: 1.0,
                              color: Color.fromARGB(255, 125, 176, 253)),
                        ),
                        child: Text(
                          "Edit Profile",
                          style: TextStyle(
                              color: Color.fromARGB(255, 125, 176, 253),
                              fontWeight: FontWeight.bold,
                              fontSize: 16),
                        ))),
              ),
              const SizedBox(
                height: 16,
              ),
              SizedBox(
                width: double.infinity,
                child: SizedBox(
                    height: 40,
                    child: OutlinedButton(
                        onPressed: () {},
                        style: OutlinedButton.styleFrom(
                          side: BorderSide(
                              width: 1.0,
                              color: Color.fromARGB(255, 250, 0, 0)),
                        ),
                        child: Text(
                          "LogOut",
                          style: TextStyle(
                              color: Color.fromARGB(255, 250, 0, 0),
                              fontWeight: FontWeight.bold,
                              fontSize: 16),
                        ))),
              ),
            ],
          ),
        ));
  }
}
