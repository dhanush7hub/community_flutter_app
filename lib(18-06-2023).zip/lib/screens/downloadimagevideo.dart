import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';

class DownloadImageVideo extends StatefulWidget {
  final String url;
  final bool isimg;

  const DownloadImageVideo({Key? key, required this.url, required this.isimg})
      : super(key: key);

  @override
  _DownloadImageVideoState createState() => _DownloadImageVideoState();
}

class _DownloadImageVideoState extends State<DownloadImageVideo> {
  late bool _downloading;
  late double _progress;
  late String _message;
  late IconData _icon;
  late String _path;

  @override
  void initState() {
    super.initState();
    _downloading = false;
    _progress = 0;
    _message = 'Download';
    _icon = Icons.download_rounded;
    _path = '';
  }

  Future<void> _downloadFile() async {
    final appDirectory = await getExternalStorageDirectory();
    final directoryPath = '${appDirectory!.path}/Downloads';
    await Directory(directoryPath).create(recursive: true);

    final dio = Dio();
    try {
      setState(() {
        _downloading = true;
        _progress = 0;
        _message = 'Downloading...';
        _icon = Icons.close;
      });

      _path = widget.isimg
          ? '$directoryPath/${DateTime.now().toString()}.jpg'
          : '$directoryPath/${DateTime.now().toString()}.mp4';

      await dio.download(
        widget.url,
        _path,
        onReceiveProgress: (rec, total) {
          setState(() {
            _progress = (rec / total);
          });
        },
      );
    } catch (e) {
      print(e);
      setState(() {
        _message = 'Failed';
        _icon = Icons.error_rounded;
      });
    }

    setState(() {
      _downloading = false;
      _progress = 0;
      _message = 'Download';
      _icon = Icons.download_rounded;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Download Image/Video'),
      ),
      body: 
      Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Stack(
              children: [
                Container(
                  width: 60,
                  height: 60,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.grey[300]!, width: 2),
                  ),
                  child: Center(
                    child: IconButton(
                      icon: Icon(_icon),
                      onPressed: _downloading ? null : _downloadFile,
                    ),
                  ),
                ),
                if (_downloading)
                  Positioned.fill(
                    child: CircularProgressIndicator(
                      value: _progress,
                      strokeWidth: 4,
                      valueColor: AlwaysStoppedAnimation<Color>(
                        Colors.green,
                      ),
                    ),
                  ),
              ],
            ),
            SizedBox(height: 8),
            Text(
              _message,
              style: TextStyle(
                fontSize: 12,
                color: Colors.grey[600],
              ),
            ),
            if (_path.isNotEmpty) SizedBox(height: 8),
            Text(
              'Downloaded at $_path',
              style: TextStyle(
                fontSize: 12,
                color: Colors.grey[600],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
