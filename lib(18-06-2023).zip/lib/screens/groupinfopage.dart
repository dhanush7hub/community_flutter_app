import 'dart:ui';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:specialchat/screens/groupchatpage.dart';
import 'package:specialchat/services/database_service.dart';
import 'package:specialchat/widgets/group_participants.dart';

import 'package:specialchat/widgets/participants.dart';
import '../../widgets/widgets.dart';

class GroupinfoPage extends StatefulWidget {
  String groupId;
  bool private;
  String sourceurl, groupname, description, createdBy, groupLink;
  DateTime createdAt;

  GroupinfoPage({
    required this.groupId,
    required this.private,
    required this.sourceurl,
    required this.groupname,
    required this.description,
    required this.createdBy,
    required this.groupLink,
    required this.createdAt,
  });
  @override
  State<GroupinfoPage> createState() => _GroupAdminPageState();
}

class _GroupAdminPageState extends State<GroupinfoPage> {
  var count = 3;
  bool sm = false;
  bool _isLoading = false;
  bool contain = false;
  List<QueryDocumentSnapshot<Object?>>? docs;
  late bool alreadyjoined;

  getvalue() async {
            final QuerySnapshot snapshot = await FirebaseFirestore.instance
        .collection('publicgroups/${widget.groupId}/users')
        .get();
    docs = snapshot.docs;

    final collectionRef = FirebaseFirestore.instance.collection(
        'multipleconversationlist/${FirebaseAuth.instance.currentUser!.uid}/conversationwith');

    // Get all documents in the collection
    final snap = await collectionRef.get();
    setState(() {
      // Loop through all documents in the collection
      for (final doc in snap.docs) {
        // Get the data from the document as a map

        final data = doc.data();

        print(data);
        print("tttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt");

        if (data["groupid"] == widget.groupId) {
          print(widget.groupId);
          print(data["groupid"]);
          print(
              "tttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt");
          setState(() {
            alreadyjoined = true;
          });
          break;
        } else {
          print(widget.groupId);

          print(data["groupid"]);
          print(
              "tttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt");
          setState(() {
            alreadyjoined = false;
          });
        }
      }
      contain = true;
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    alreadyjoined = false;
    getvalue();
  }

  // @override
  // void didChangeDependencies() {
  //   super.didChangeDependencies();
  //   getvalue(); // Call the getvalue() function when the dependencies change
  // }

  // @override
  // void initState() {
  //   final DocumentReference groupdoc = widget.private
  //       ? FirebaseFirestore.instance
  //           .collection("privategroups")
  //           .doc(widget.groupId)
  //       : FirebaseFirestore.instance
  //           .collection("publicgroups")
  //           .doc(widget.groupId);
  //   DatabaseService().groupinfodata(groupdoc);
  //   super.initState();
  // }

  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
      ),
      body: alreadyjoined == null
          ? CircularProgressIndicator()
          : _isLoading
              ? CircularProgressIndicator()
              : SingleChildScrollView(
                  child: Container(
                    padding: EdgeInsets.all(15),
                    child: Column(
                      children: [
                        Container(
                          alignment: Alignment.center,
                          child: CircleAvatar(
                            radius: 48,
                            backgroundImage: NetworkImage(
                              widget.sourceurl,
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 5,
                        ),
                        Text(
                          widget.groupname,
                          style: medium.copyWith(
                            fontSize: 22,
                          ),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              'Group',
                              style: light.copyWith(
                                fontSize: 11,
                                color: Color(0Xff555555),
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            SizedBox(
                              width: 5,
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top: 2),
                              child: Container(
                                width: 2,
                                height: 2,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Color(0Xff555555),
                                ),
                              ),
                            ),
                            SizedBox(
                              width: 5,
                            ),
                            Text(
                              '2',
                              style: medium.copyWith(
                                fontSize: 11,
                                color: Color(0Xff555555),
                              ),
                            ),
                            SizedBox(
                              width: 5,
                            ),
                            Text(
                              'Participants',
                              style: medium.copyWith(
                                fontSize: 11,
                                color: Color(0Xff777777),
                              ),
                            )
                          ],
                        ),
                        SizedBox(
                          height: 25,
                        ),
                        Container(
                          alignment: Alignment.topLeft,
                          child: RichText(
                            text: TextSpan(
                              children: <TextSpan>[
                                TextSpan(
                                  text: widget.description,
                                  style: light.copyWith(
                                    fontSize: 15,
                                    color: Colors.black,
                                  ),
                                ),
                                TextSpan(
                                  text: '  Edit',
                                  style: medium.copyWith(
                                    color: Color(0xff7DB1FD),
                                    fontSize: 12,
                                  ),
                                  recognizer: TapGestureRecognizer()
                                    ..onTap = () {},
                                ),
                              ],
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Container(
                          alignment: Alignment.topLeft,
                          child: Text(
                            "Created by " +
                                widget.createdBy +
                                ", " +
                                DateFormat('dd/MM/yyyy')
                                    .format((widget.createdAt)),
                            style: light.copyWith(
                              fontSize: 11,
                              color: Color(0Xff777777),
                              fontWeight: FontWeight.w300,
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 40,
                        ),
                        Text(
                          'Invite people via Group link',
                          style: light.copyWith(
                            fontSize: 15,
                          ),
                        ),
                        SizedBox(
                          height: 8,
                        ),
                        RichText(
                          text: TextSpan(
                            children: <TextSpan>[
                              TextSpan(
                                text: widget.groupLink,
                                style: light.copyWith(
                                  color: Color(0xff3E84EA),
                                  fontSize: 13,
                                ),
                                recognizer: TapGestureRecognizer()
                                  ..onTap = () {},
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 40,
                        ),
                        contain
                            ? group_participants(docs, widget.groupId,
                                alreadyjoined, widget.private)
                            : CircularProgressIndicator(),
                      ],
                    ),
                  ),
                ),
    );
  }
}

// SingleChildScrollView(
//         child: Container(
//           padding: EdgeInsets.all(15),
//           child: Column(
//             children: [
//               Container(
//                 alignment: Alignment.center,
//                 child: CircleAvatar(
//                   radius: 48,
//                   backgroundImage: AssetImage(
//                     'assets/images/group_pic.png',
//                   ),
//                 ),
//               ),
//               SizedBox(
//                 height: 5,
//               ),
//               Text(
//                 'Tamil Boys',
//                 style: medium.copyWith(
//                   fontSize: 22,
//                 ),
//               ),
//               Row(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: [
//                   Text(
//                     'Group',
//                     style: light.copyWith(
//                       fontSize: 11,
//                       color: Color(0Xff555555),
//                       fontWeight: FontWeight.w500,
//                     ),
//                   ),
//                   SizedBox(
//                     width: 5,
//                   ),
//                   Padding(
//                     padding: const EdgeInsets.only(top: 2),
//                     child: Container(
//                       width: 2,
//                       height: 2,
//                       decoration: BoxDecoration(
//                         shape: BoxShape.circle,
//                         color: Color(0Xff555555),
//                       ),
//                     ),
//                   ),
//                   SizedBox(
//                     width: 5,
//                   ),
//                   Text(
//                     '2',
//                     style: medium.copyWith(
//                       fontSize: 11,
//                       color: Color(0Xff555555),
//                     ),
//                   ),
//                   SizedBox(
//                     width: 5,
//                   ),
//                   Text(
//                     'Participants',
//                     style: medium.copyWith(
//                       fontSize: 11,
//                       color: Color(0Xff777777),
//                     ),
//                   )
//                 ],
//               ),
//               SizedBox(
//                 height: 25,
//               ),
//               Container(
//                 alignment: Alignment.topLeft,
//                 child: RichText(
//                   text: TextSpan(
//                     children: <TextSpan>[
//                       TextSpan(
//                         text: 'We welcome every students...',
//                         style: light.copyWith(
//                           fontSize: 15,
//                           color: Colors.black,
//                         ),
//                       ),
//                       TextSpan(
//                         text: 'Edit',
//                         style: medium.copyWith(
//                           color: Color(0xff7DB1FD),
//                           fontSize: 12,
//                         ),
//                         recognizer: TapGestureRecognizer()..onTap = () {},
//                       ),
//                     ],
//                   ),
//                 ),
//               ),
//               SizedBox(
//                 height: 10,
//               ),
//               Container(
//                 alignment: Alignment.topLeft,
//                 child: Text(
//                   'Created by Santhosh, 27/09/2023',
//                   style: light.copyWith(
//                     fontSize: 11,
//                     color: Color(0Xff777777),
//                     fontWeight: FontWeight.w300,
//                   ),
//                 ),
//               ),
//               SizedBox(
//                 height: 40,
//               ),
//               Text(
//                 'Invite people via Group link',
//                 style: light.copyWith(
//                   fontSize: 15,
//                 ),
//               ),
//               SizedBox(
//                 height: 8,
//               ),
//               RichText(
//                 text: TextSpan(
//                   children: <TextSpan>[
//                     TextSpan(
//                       text: 'Soora.app/group/Tamil%20Boys',
//                       style: light.copyWith(
//                         color: Color(0xff3E84EA),
//                         fontSize: 13,
//                       ),
//                       recognizer: TapGestureRecognizer()..onTap = () {},
//                     ),
//                   ],
//                 ),
//               ),
//               SizedBox(
//                 height: 40,
//               ),
//               Row(
//                 children: [
//                   Expanded(
//                     child: Text(
//                       '999 Participants',
//                       style: medium.copyWith(
//                         color: Color(0Xff777777),
//                         fontSize: 12,
//                       ),
//                     ),
//                   ),
//                   IconButton(
//                     onPressed: () {},
//                     icon: Icon(
//                       Icons.search,
//                     ),
//                   ),
//                 ],
//               ),
//               SizedBox(
//                 height: 5,
//               ),
//               ListView.builder(
//                 physics: NeverScrollableScrollPhysics(),
//                 shrinkWrap: true,
//                 itemCount: count,
//                 itemBuilder: (context, index) {
//                   return participants();
//                 },
//               ),
//               RichText(
//                 text: TextSpan(
//                   children: <TextSpan>[
//                     TextSpan(
//                       text: '995 more',
//                       style: medium.copyWith(
//                         fontSize: 11,
//                         color: Color(0xff7DB1FD),
//                       ),
//                       recognizer: TapGestureRecognizer()
//                         ..onTap = () {
//                           setState(() {
//                             count = sm ? 3 : 10;
//                             sm = !sm;
//                           });
//                         },
//                     ),
//                   ],
//                 ),
//               ),
//               SizedBox(
//                 height: 30,
//               ),
//               Container(
//                 alignment: Alignment.topLeft,
//                 child: RichText(
//                   text: TextSpan(
//                     children: <TextSpan>[
//                       TextSpan(
//                         text: 'Report',
//                         style: light.copyWith(
//                           fontSize: 14,
//                         ),
//                         recognizer: TapGestureRecognizer()..onTap = () {},
//                       ),
//                     ],
//                   ),
//                 ),
//               ),
//               SizedBox(
//                 height: 15,
//               ),
//               Container(
//                 alignment: Alignment.topLeft,
//                 child: RichText(
//                   text: TextSpan(
//                     children: <TextSpan>[
//                       TextSpan(
//                         text: 'Leave Group',
//                         style: light.copyWith(
//                           color: Color(0xffA70000),
//                           fontSize: 14,
//                         ),
//                         recognizer: TapGestureRecognizer()..onTap = () {},
//                       ),
//                     ],
//                   ),
//                 ),
//               ),
//               SizedBox(
//                 height: 15,
//               ),
//               Container(
//                 alignment: Alignment.topLeft,
//                 child: RichText(
//                   text: TextSpan(
//                     children: <TextSpan>[
//                       TextSpan(
//                         text: 'Delete Group',
//                         style: light.copyWith(
//                           color: Color(0xffA70000),
//                           fontSize: 14,
//                         ),
//                         recognizer: TapGestureRecognizer()..onTap = () {},
//                       ),
//                     ],
//                   ),
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),

// Row(
//                       children: [
//                         Expanded(
//                           child: Text(
//                             '999 Participants',
//                             style: medium.copyWith(
//                               color: Color(0Xff777777),
//                               fontSize: 12,
//                             ),
//                           ),
//                         ),
//                         IconButton(
//                           onPressed: () {},
//                           icon: Icon(
//                             Icons.search,
//                           ),
//                         ),
//                       ],
//                     ),
//                     SizedBox(
//                       height: 5,
//                     ),
//                     ListView.builder(
//                       physics: NeverScrollableScrollPhysics(),
//                       shrinkWrap: true,
//                       itemCount: count,
//                       itemBuilder: (context, index) {
//                         return participants();
//                       },
//                     ),
//                     RichText(
//                       text: TextSpan(
//                         children: <TextSpan>[
//                           TextSpan(
//                             text: '995 more',
//                             style: medium.copyWith(
//                               fontSize: 11,
//                               color: Color(0xff7DB1FD),
//                             ),
//                             recognizer: TapGestureRecognizer()
//                               ..onTap = () {
//                                 setState(() {
//                                   count = sm ? 3 : 10;
//                                   sm = !sm;
//                                 });
//                               },
//                           ),
//                         ],
//                       ),
//                     ),
//                     SizedBox(
//                       height: 30,
//                     ),
//                     Container(
//                       alignment: Alignment.topLeft,
//                       child: RichText(
//                         text: TextSpan(
//                           children: <TextSpan>[
//                             TextSpan(
//                               text: 'Report',
//                               style: light.copyWith(
//                                 fontSize: 14,
//                               ),
//                               recognizer: TapGestureRecognizer()..onTap = () {},
//                             ),
//                           ],
//                         ),
//                       ),
//                     ),
//                     SizedBox(
//                       height: 15,
//                     ),
//                     Container(
//                       alignment: Alignment.topLeft,
//                       child: RichText(
//                         text: TextSpan(
//                           children: <TextSpan>[
//                             TextSpan(
//                               text: 'Leave Group',
//                               style: light.copyWith(
//                                 color: Color(0xffA70000),
//                                 fontSize: 14,
//                               ),
//                               recognizer: TapGestureRecognizer()..onTap = () {},
//                             ),
//                           ],
//                         ),
//                       ),
//                     ),
//                     SizedBox(
//                       height: 15,
//                     ),
//                     Container(
//                       alignment: Alignment.topLeft,
//                       child: RichText(
//                         text: TextSpan(
//                           children: <TextSpan>[
//                             TextSpan(
//                               text: 'Delete Group',
//                               style: light.copyWith(
//                                 color: Color(0xffA70000),
//                                 fontSize: 14,
//                               ),
//                               recognizer: TapGestureRecognizer()..onTap = () {},
//                             ),
//                           ],
//                         ),
//                       ),
//                     ),













/////////////////////////up la testing.

// import 'dart:ui';

// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:flutter/gestures.dart';
// import 'package:flutter/material.dart';
// import 'package:intl/intl.dart';
// import 'package:specialchat/screens/groupchatpage.dart';
// import 'package:specialchat/services/database_service.dart';
// import 'package:specialchat/widgets/group_participants.dart';

// import 'package:specialchat/widgets/participants.dart';
// import '../../widgets/widgets.dart';

// class GroupinfoPage extends StatefulWidget {
//   String groupId;
//   bool private;
//   String sourceurl, groupname, description, createdBy, groupLink;
//   DateTime createdAt;

//   GroupinfoPage({
//     required this.groupId,
//     required this.private,
//     required this.sourceurl,
//     required this.groupname,
//     required this.description,
//     required this.createdBy,
//     required this.groupLink,
//     required this.createdAt,
//   });
//   @override
//   State<GroupinfoPage> createState() => _GroupAdminPageState();
// }

// class _GroupAdminPageState extends State<GroupinfoPage> {
//   var count = 3;
//   bool sm = false;
//   bool _isLoading = false;
//   bool contain = false;
//   List<QueryDocumentSnapshot<Object?>>? docs;
//   late bool alreadyjoined;

//   getvalue() async {
//     final QuerySnapshot snapshot = await FirebaseFirestore.instance
//         .collection('publicgroups/${widget.groupId}/users')
//         .get();
//     docs = snapshot.docs;

//     final collectionRef = FirebaseFirestore.instance.collection(
//         'multipleconversationlist/${FirebaseAuth.instance.currentUser!.uid}/conversationwith');

//     // Get all documents in the collection
//     final snap = await collectionRef.get();
//     setState(() {
//       // Loop through all documents in the collection
//       for (final doc in snap.docs) {
//         // Get the data from the document as a map

//         final data = doc.data();

//         print(data);
//         print("tttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt");

//         if (data["groupid"] == widget.groupId) {
//           print(widget.groupId);
//           print(data["groupid"]);
//           print(
//               "tttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt");
//           alreadyjoined = true;
//           break;
//         } else {
//           print(widget.groupId);

//           print(data["groupid"]);
//           print(
//               "tttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt");
//           alreadyjoined = false;
//         }
//       }
//       contain = true;
//     });
//   }

//   @override
//   void didChangeDependencies() {
//     super.didChangeDependencies();
//     getvalue(); // Call the getvalue() function when the dependencies change
//   }

//   // @override
//   // void initState() {
//   //   final DocumentReference groupdoc = widget.private
//   //       ? FirebaseFirestore.instance
//   //           .collection("privategroups")
//   //           .doc(widget.groupId)
//   //       : FirebaseFirestore.instance
//   //           .collection("publicgroups")
//   //           .doc(widget.groupId);
//   //   DatabaseService().groupinfodata(groupdoc);
//   //   super.initState();
//   // }

//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         backgroundColor: Colors.white,
//         elevation: 0,
//       ),
//       body: _isLoading
//           ? CircularProgressIndicator()
//           : SingleChildScrollView(
//               child: Container(
//                 padding: EdgeInsets.all(15),
//                 child: Column(
//                   children: [
//                     Container(
//                       alignment: Alignment.center,
//                       child: CircleAvatar(
//                         radius: 48,
//                         backgroundImage: NetworkImage(
//                           widget.sourceurl,
//                         ),
//                       ),
//                     ),
//                     SizedBox(
//                       height: 5,
//                     ),
//                     Text(
//                       widget.groupname,
//                       style: medium.copyWith(
//                         fontSize: 22,
//                       ),
//                     ),
//                     Row(
//                       mainAxisAlignment: MainAxisAlignment.center,
//                       children: [
//                         Text(
//                           'Group',
//                           style: light.copyWith(
//                             fontSize: 11,
//                             color: Color(0Xff555555),
//                             fontWeight: FontWeight.w500,
//                           ),
//                         ),
//                         SizedBox(
//                           width: 5,
//                         ),
//                         Padding(
//                           padding: const EdgeInsets.only(top: 2),
//                           child: Container(
//                             width: 2,
//                             height: 2,
//                             decoration: BoxDecoration(
//                               shape: BoxShape.circle,
//                               color: Color(0Xff555555),
//                             ),
//                           ),
//                         ),
//                         SizedBox(
//                           width: 5,
//                         ),
//                         Text(
//                           '2',
//                           style: medium.copyWith(
//                             fontSize: 11,
//                             color: Color(0Xff555555),
//                           ),
//                         ),
//                         SizedBox(
//                           width: 5,
//                         ),
//                         Text(
//                           'Participants',
//                           style: medium.copyWith(
//                             fontSize: 11,
//                             color: Color(0Xff777777),
//                           ),
//                         )
//                       ],
//                     ),
//                     SizedBox(
//                       height: 25,
//                     ),
//                     Container(
//                       alignment: Alignment.topLeft,
//                       child: RichText(
//                         text: TextSpan(
//                           children: <TextSpan>[
//                             TextSpan(
//                               text: widget.description,
//                               style: light.copyWith(
//                                 fontSize: 15,
//                                 color: Colors.black,
//                               ),
//                             ),
//                             TextSpan(
//                               text: '  Edit',
//                               style: medium.copyWith(
//                                 color: Color(0xff7DB1FD),
//                                 fontSize: 12,
//                               ),
//                               recognizer: TapGestureRecognizer()..onTap = () {},
//                             ),
//                           ],
//                         ),
//                       ),
//                     ),
//                     SizedBox(
//                       height: 10,
//                     ),
//                     Container(
//                       alignment: Alignment.topLeft,
//                       child: Text(
//                         "Created by " +
//                             widget.createdBy +
//                             ", " +
//                             DateFormat('dd/MM/yyyy').format((widget.createdAt)),
//                         style: light.copyWith(
//                           fontSize: 11,
//                           color: Color(0Xff777777),
//                           fontWeight: FontWeight.w300,
//                         ),
//                       ),
//                     ),
//                     SizedBox(
//                       height: 40,
//                     ),
//                     Text(
//                       'Invite people via Group link',
//                       style: light.copyWith(
//                         fontSize: 15,
//                       ),
//                     ),
//                     SizedBox(
//                       height: 8,
//                     ),
//                     RichText(
//                       text: TextSpan(
//                         children: <TextSpan>[
//                           TextSpan(
//                             text: widget.groupLink,
//                             style: light.copyWith(
//                               color: Color(0xff3E84EA),
//                               fontSize: 13,
//                             ),
//                             recognizer: TapGestureRecognizer()..onTap = () {},
//                           ),
//                         ],
//                       ),
//                     ),
//                     SizedBox(
//                       height: 40,
//                     ),
//                     contain
//                         ? group_participants(
//                             docs, widget.groupId, alreadyjoined, widget.private)
//                         : CircularProgressIndicator(),
//                   ],
//                 ),
//               ),
//             ),
//     );
//   }
// }

// // SingleChildScrollView(
// //         child: Container(
// //           padding: EdgeInsets.all(15),
// //           child: Column(
// //             children: [
// //               Container(
// //                 alignment: Alignment.center,
// //                 child: CircleAvatar(
// //                   radius: 48,
// //                   backgroundImage: AssetImage(
// //                     'assets/images/group_pic.png',
// //                   ),
// //                 ),
// //               ),
// //               SizedBox(
// //                 height: 5,
// //               ),
// //               Text(
// //                 'Tamil Boys',
// //                 style: medium.copyWith(
// //                   fontSize: 22,
// //                 ),
// //               ),
// //               Row(
// //                 mainAxisAlignment: MainAxisAlignment.center,
// //                 children: [
// //                   Text(
// //                     'Group',
// //                     style: light.copyWith(
// //                       fontSize: 11,
// //                       color: Color(0Xff555555),
// //                       fontWeight: FontWeight.w500,
// //                     ),
// //                   ),
// //                   SizedBox(
// //                     width: 5,
// //                   ),
// //                   Padding(
// //                     padding: const EdgeInsets.only(top: 2),
// //                     child: Container(
// //                       width: 2,
// //                       height: 2,
// //                       decoration: BoxDecoration(
// //                         shape: BoxShape.circle,
// //                         color: Color(0Xff555555),
// //                       ),
// //                     ),
// //                   ),
// //                   SizedBox(
// //                     width: 5,
// //                   ),
// //                   Text(
// //                     '2',
// //                     style: medium.copyWith(
// //                       fontSize: 11,
// //                       color: Color(0Xff555555),
// //                     ),
// //                   ),
// //                   SizedBox(
// //                     width: 5,
// //                   ),
// //                   Text(
// //                     'Participants',
// //                     style: medium.copyWith(
// //                       fontSize: 11,
// //                       color: Color(0Xff777777),
// //                     ),
// //                   )
// //                 ],
// //               ),
// //               SizedBox(
// //                 height: 25,
// //               ),
// //               Container(
// //                 alignment: Alignment.topLeft,
// //                 child: RichText(
// //                   text: TextSpan(
// //                     children: <TextSpan>[
// //                       TextSpan(
// //                         text: 'We welcome every students...',
// //                         style: light.copyWith(
// //                           fontSize: 15,
// //                           color: Colors.black,
// //                         ),
// //                       ),
// //                       TextSpan(
// //                         text: 'Edit',
// //                         style: medium.copyWith(
// //                           color: Color(0xff7DB1FD),
// //                           fontSize: 12,
// //                         ),
// //                         recognizer: TapGestureRecognizer()..onTap = () {},
// //                       ),
// //                     ],
// //                   ),
// //                 ),
// //               ),
// //               SizedBox(
// //                 height: 10,
// //               ),
// //               Container(
// //                 alignment: Alignment.topLeft,
// //                 child: Text(
// //                   'Created by Santhosh, 27/09/2023',
// //                   style: light.copyWith(
// //                     fontSize: 11,
// //                     color: Color(0Xff777777),
// //                     fontWeight: FontWeight.w300,
// //                   ),
// //                 ),
// //               ),
// //               SizedBox(
// //                 height: 40,
// //               ),
// //               Text(
// //                 'Invite people via Group link',
// //                 style: light.copyWith(
// //                   fontSize: 15,
// //                 ),
// //               ),
// //               SizedBox(
// //                 height: 8,
// //               ),
// //               RichText(
// //                 text: TextSpan(
// //                   children: <TextSpan>[
// //                     TextSpan(
// //                       text: 'Soora.app/group/Tamil%20Boys',
// //                       style: light.copyWith(
// //                         color: Color(0xff3E84EA),
// //                         fontSize: 13,
// //                       ),
// //                       recognizer: TapGestureRecognizer()..onTap = () {},
// //                     ),
// //                   ],
// //                 ),
// //               ),
// //               SizedBox(
// //                 height: 40,
// //               ),
// //               Row(
// //                 children: [
// //                   Expanded(
// //                     child: Text(
// //                       '999 Participants',
// //                       style: medium.copyWith(
// //                         color: Color(0Xff777777),
// //                         fontSize: 12,
// //                       ),
// //                     ),
// //                   ),
// //                   IconButton(
// //                     onPressed: () {},
// //                     icon: Icon(
// //                       Icons.search,
// //                     ),
// //                   ),
// //                 ],
// //               ),
// //               SizedBox(
// //                 height: 5,
// //               ),
// //               ListView.builder(
// //                 physics: NeverScrollableScrollPhysics(),
// //                 shrinkWrap: true,
// //                 itemCount: count,
// //                 itemBuilder: (context, index) {
// //                   return participants();
// //                 },
// //               ),
// //               RichText(
// //                 text: TextSpan(
// //                   children: <TextSpan>[
// //                     TextSpan(
// //                       text: '995 more',
// //                       style: medium.copyWith(
// //                         fontSize: 11,
// //                         color: Color(0xff7DB1FD),
// //                       ),
// //                       recognizer: TapGestureRecognizer()
// //                         ..onTap = () {
// //                           setState(() {
// //                             count = sm ? 3 : 10;
// //                             sm = !sm;
// //                           });
// //                         },
// //                     ),
// //                   ],
// //                 ),
// //               ),
// //               SizedBox(
// //                 height: 30,
// //               ),
// //               Container(
// //                 alignment: Alignment.topLeft,
// //                 child: RichText(
// //                   text: TextSpan(
// //                     children: <TextSpan>[
// //                       TextSpan(
// //                         text: 'Report',
// //                         style: light.copyWith(
// //                           fontSize: 14,
// //                         ),
// //                         recognizer: TapGestureRecognizer()..onTap = () {},
// //                       ),
// //                     ],
// //                   ),
// //                 ),
// //               ),
// //               SizedBox(
// //                 height: 15,
// //               ),
// //               Container(
// //                 alignment: Alignment.topLeft,
// //                 child: RichText(
// //                   text: TextSpan(
// //                     children: <TextSpan>[
// //                       TextSpan(
// //                         text: 'Leave Group',
// //                         style: light.copyWith(
// //                           color: Color(0xffA70000),
// //                           fontSize: 14,
// //                         ),
// //                         recognizer: TapGestureRecognizer()..onTap = () {},
// //                       ),
// //                     ],
// //                   ),
// //                 ),
// //               ),
// //               SizedBox(
// //                 height: 15,
// //               ),
// //               Container(
// //                 alignment: Alignment.topLeft,
// //                 child: RichText(
// //                   text: TextSpan(
// //                     children: <TextSpan>[
// //                       TextSpan(
// //                         text: 'Delete Group',
// //                         style: light.copyWith(
// //                           color: Color(0xffA70000),
// //                           fontSize: 14,
// //                         ),
// //                         recognizer: TapGestureRecognizer()..onTap = () {},
// //                       ),
// //                     ],
// //                   ),
// //                 ),
// //               ),
// //             ],
// //           ),
// //         ),
// //       ),

// // Row(
// //                       children: [
// //                         Expanded(
// //                           child: Text(
// //                             '999 Participants',
// //                             style: medium.copyWith(
// //                               color: Color(0Xff777777),
// //                               fontSize: 12,
// //                             ),
// //                           ),
// //                         ),
// //                         IconButton(
// //                           onPressed: () {},
// //                           icon: Icon(
// //                             Icons.search,
// //                           ),
// //                         ),
// //                       ],
// //                     ),
// //                     SizedBox(
// //                       height: 5,
// //                     ),
// //                     ListView.builder(
// //                       physics: NeverScrollableScrollPhysics(),
// //                       shrinkWrap: true,
// //                       itemCount: count,
// //                       itemBuilder: (context, index) {
// //                         return participants();
// //                       },
// //                     ),
// //                     RichText(
// //                       text: TextSpan(
// //                         children: <TextSpan>[
// //                           TextSpan(
// //                             text: '995 more',
// //                             style: medium.copyWith(
// //                               fontSize: 11,
// //                               color: Color(0xff7DB1FD),
// //                             ),
// //                             recognizer: TapGestureRecognizer()
// //                               ..onTap = () {
// //                                 setState(() {
// //                                   count = sm ? 3 : 10;
// //                                   sm = !sm;
// //                                 });
// //                               },
// //                           ),
// //                         ],
// //                       ),
// //                     ),
// //                     SizedBox(
// //                       height: 30,
// //                     ),
// //                     Container(
// //                       alignment: Alignment.topLeft,
// //                       child: RichText(
// //                         text: TextSpan(
// //                           children: <TextSpan>[
// //                             TextSpan(
// //                               text: 'Report',
// //                               style: light.copyWith(
// //                                 fontSize: 14,
// //                               ),
// //                               recognizer: TapGestureRecognizer()..onTap = () {},
// //                             ),
// //                           ],
// //                         ),
// //                       ),
// //                     ),
// //                     SizedBox(
// //                       height: 15,
// //                     ),
// //                     Container(
// //                       alignment: Alignment.topLeft,
// //                       child: RichText(
// //                         text: TextSpan(
// //                           children: <TextSpan>[
// //                             TextSpan(
// //                               text: 'Leave Group',
// //                               style: light.copyWith(
// //                                 color: Color(0xffA70000),
// //                                 fontSize: 14,
// //                               ),
// //                               recognizer: TapGestureRecognizer()..onTap = () {},
// //                             ),
// //                           ],
// //                         ),
// //                       ),
// //                     ),
// //                     SizedBox(
// //                       height: 15,
// //                     ),
// //                     Container(
// //                       alignment: Alignment.topLeft,
// //                       child: RichText(
// //                         text: TextSpan(
// //                           children: <TextSpan>[
// //                             TextSpan(
// //                               text: 'Delete Group',
// //                               style: light.copyWith(
// //                                 color: Color(0xffA70000),
// //                                 fontSize: 14,
// //                               ),
// //                               recognizer: TapGestureRecognizer()..onTap = () {},
// //                             ),
// //                           ],
// //                         ),
// //                       ),
// //                     ),
