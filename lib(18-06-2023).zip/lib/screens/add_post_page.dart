import 'dart:io';
import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:specialchat/services/database_service.dart';
import "package:flutter/material.dart";
import 'package:image_picker/image_picker.dart';
import '../utils/utils.dart';

class AddPostScreen extends StatefulWidget {
  const AddPostScreen({Key? key}) : super(key: key);

  @override
  State<AddPostScreen> createState() => _AddPostScreenState();
}

class _AddPostScreenState extends State<AddPostScreen> {
  bool isvideo=false;
  String? userProfile;
  String? username;
  Uint8List? _file;
  File? _file2;
  final TextEditingController _descriptionController = TextEditingController();
  bool isLoading = false;
  late MemoryImage memoryImage;

  selectfile() async {
    final result = await FilePicker.platform.pickFiles(allowMultiple: false);

    if (result == null) return;
    final path = result.files.single.path!;
    setState(() {
      _file2 = File(path);
    });
  }

  void postImage(
    String uid,
    String? username,
    String? profImage,
    bool isvideo
  ) async {
    setState(() {
      isLoading = true;
    });
    try {
      String res = isvideo ?
       await FirestoreMethods().uploadPosts(
              _descriptionController.text,
              _file2!,
              uid,
              username,
              profImage,
              isvideo
            ):
          await FirestoreMethods().uploadPost(
              _descriptionController.text,
              _file!,
              uid,
              username,
              profImage,
              isvideo
            );
          
      if (res == "success") {
        setState(() {
          isLoading = false;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("Posted!"),
          ),
        );
        Navigator.of(context).pop();
        clearImage();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(res),
          ),
        );
      }
    } catch (e) {}
  }

  selectImage(BuildContext context) async {
    return showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return Container(
          height: 225,
          child: Column(
            children: <Widget>[
              ListTile(
                leading: Icon(Icons.camera_alt),
                title: Text('Take a Photo'),
                onTap: () async {
                  isvideo = false;
                  Navigator.of(context).pop();
                  Uint8List file = await pickImage(ImageSource.camera);
                  setState(() {
                    _file = file;
                  });
                },
              ),
              ListTile(
                leading: Icon(Icons.video_call),
                title: Text('Take a Video'),
                onTap: () async{
                  isvideo = true;
                                    selectfile();

                  // Navigator.of(context).pop();
                  // XFile? file = await ImagePicker().pickVideo(source: ImageSource.gallery);
                  // setState(() {
                  //   _file2 = file as File?;
                  // });
                },
              ),
              ListTile(
                leading: Icon(Icons.photo_library),
                title: Text('Choose from Gallery'),
                onTap: () async {
                  isvideo = false;
                  Navigator.of(context).pop();
                  Uint8List file = await pickImage(ImageSource.gallery);
                  setState(() {
                    _file = file;
                  });
                },
              ),
              ListTile(
                leading: Icon(Icons.cancel),
                title: Text('Cancel'),
                onTap: () async {
                  // Navigator.of(context).pop();
                  // nextpage(
                  //   context,
                  // );
                },
              ),
            ],
          ),
        );
      },
    );
  }

  void clearImage() {
    setState(() {
      _file = null;
    });
  }

  Future<String?> getuserprofile() async {
    final img = await DatabaseService().getUserprofile();
    return img;
  }

  @override
  void dispose() {
    super.dispose();
    _descriptionController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        padding: EdgeInsets.only(top: 50, right: 15),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                IconButton(
                  onPressed: () {
                    clearImage();
                    Navigator.of(context).pop();
                  },
                  icon: Icon(Icons.arrow_back),
                ),
                Expanded(child: Container()),
                ElevatedButton(
                  onPressed: () async {
                    _descriptionController.text.isNotEmpty
                        ? postImage(
                            FirebaseAuth.instance.currentUser!.uid,
                            await DatabaseService().getUsername(),
                            await DatabaseService().getUserprofile(),
                            isvideo
                          )
                        : null;
                  },
                  child: Text("Post"),
                ),
              ],
            ),
            isLoading
                ? LinearProgressIndicator()
                : const Padding(padding: EdgeInsets.only(top: 0)),
            SizedBox(
              height: 20,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                FutureBuilder<String?>(
                  future: DatabaseService().getUserprofile(),
                  builder: (context, snapshot) {
                    return CircleAvatar(
                      backgroundImage: NetworkImage(snapshot.data!),
                      radius: 25,
                    );
                  },
                ),
                SizedBox(width: 10),
                Expanded(
                  // child: Text(DatabaseService().getUsername().toString())
                  child: FutureBuilder<String?>(
                    future: DatabaseService().getUsername(),
                    builder: (context, snapshot) {
                      return Text(snapshot.data!);
                    },
                  ),
                ),
                Divider(),
              ],
            ),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 20),
              width: MediaQuery.of(context).size.width,
              // height: 100,
              child: TextField(
                controller: _descriptionController,
                decoration: const InputDecoration(
                  hintText: "Share your thoughts here !",
                ),
                maxLength: 160,
              ),
            ),
            Expanded(child: Container()),
            Container(margin: EdgeInsets.only(left: 20), child: Text("Media")),
            Container(
              margin: EdgeInsets.only(left: 20, bottom: 30),
              child: SizedBox(
                height: 50,
                width: 50,
                child: AspectRatio(
                  aspectRatio: 457 / 481,
                  child: _file == null
                      ? InkWell(
                          onTap: () {
                            selectImage(context);
                          },
                          child: Container(
                            decoration: BoxDecoration(
                              border: Border.all(width: 1, color: Colors.blue),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Center(
                              child: Icon(
                                Icons.add,
                                color: Colors.blue,
                              ),
                            ),
                          ),
                        )
                      : Container(
                          decoration: BoxDecoration(
                            image: DecorationImage(
                                image:
                                    MemoryImage(_file!),
                                fit: BoxFit.fill,
                                alignment: FractionalOffset.topCenter),
                          ),
                        ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
