import 'package:flutter/material.dart';
import 'package:specialchat/widgets/widgets.dart';

class Messagepage extends StatelessWidget {
  bool _isme;
  String _name;
  String _message;
  String _profileurl;
  String _date;

  Messagepage(
      this._isme, this._name, this._message, this._profileurl, this._date);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          const SizedBox(
            height: 25,
          ),
          Container(
            height: 78,
            padding: const EdgeInsets.all(8),
            decoration: const BoxDecoration(
              border: Border(
                bottom: BorderSide(
                  color: subcolor,
                  width: 1.0,
                ),
              ),
            ),
            child: Row(
              children: [
                IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: const Icon(
                      Icons.arrow_back,
                    )),
                CircleAvatar(
                  radius: 25,
                  backgroundImage: NetworkImage(_profileurl),
                ),
                Expanded(
                  child: Padding(
                    padding: EdgeInsets.all(8),
                    child: Text(
                      _name,
                      style: medium.copyWith(
                          fontSize: 14,
                          color: Colors.black,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                const SizedBox(
                  width: 20,
                ),
                IconButton(
                  onPressed: () {},
                  icon: const Icon(Icons.phone),
                  color: Colors.black,
                ),
                IconButton(
                  onPressed: () {},
                  icon: const Icon(Icons.more_vert),
                  color: Colors.black,
                ),
              ],
            ),
          ),
          Expanded(
            child: Container(),
          ),
          _isme
              ? Row(
                  children: [
                    Container(
                      width: 170,
                      padding: const EdgeInsets.symmetric(
                        vertical: 14,
                        horizontal: 16,
                      ),
                      margin: const EdgeInsets.symmetric(
                        vertical: 5,
                        horizontal: 15,
                      ),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          color: const Color(0XFF8D88CE)),
                      child: Text(
                        _message,
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  ],
                )
              : Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Container(
                      width: 170,
                      padding: const EdgeInsets.symmetric(
                        vertical: 14,
                        horizontal: 16,
                      ),
                      margin: const EdgeInsets.symmetric(
                        vertical: 5,
                        horizontal: 15,
                      ),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          color: Color.fromARGB(255, 125, 176, 253)),
                      child: Text(
                        _message,
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  ],
                ),
          Container(
            margin: EdgeInsets.only(right: 40),
            padding: EdgeInsets.all(15),
            color: Colors.white,
            child: TextField(
                decoration: textfeilddecchat.copyWith(
                    contentPadding: EdgeInsets.all(12),
                    hintText: 'Type something...',
                    labelStyle: light.copyWith(fontSize: 10))),
          ),
        ],
      ),
    );
  }
}
