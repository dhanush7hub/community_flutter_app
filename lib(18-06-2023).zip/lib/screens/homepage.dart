import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:specialchat/screens/add_post_page.dart';
import 'package:specialchat/screens/chatpage.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:specialchat/screens/temp.dart';
import 'package:specialchat/widgets/Loading.dart';
import 'package:specialchat/widgets/widgets.dart';
import 'package:video_player/video_player.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../services/dynamiclink_service.dart';
import '../widgets/post_card.dart';

class Homepage extends StatefulWidget {
  @override
  State<Homepage> createState() => _HomepageState();
}

class _HomepageState extends State<Homepage> {
  late VideoPlayerController _controller;
  late Future<void> _initializeVideoPlayerFuture;
  List<String> videoUrls = [];
  List<String> imageUrls = [];
  List<VideoPlayerController> videoControllers = [];

  @override
  void initState() {
    // TODO: implement initState

    initializeVideoControllers();

    super.initState();
  }

  void initializeVideoControllers() async {
    await Firebase.initializeApp();
    CollectionReference videoRef =
        FirebaseFirestore.instance.collection('currentposts');

    QuerySnapshot snapshot = await videoRef.get();
    List<DocumentSnapshot> documents = snapshot.docs;

    for (var document in documents) {
      Map<String, dynamic> data = document.data() as Map<String, dynamic>;
      if (data != null && data['isvideo'] == true) {
        String url = data['postUrl'].toString();
        videoUrls.add(url);
        VideoPlayerController controller = VideoPlayerController.network(url)
          ..initialize().then((_) {
            setState(() {});
          });
        videoControllers.add(controller);
        controller.setLooping(true);
        controller.setVolume(1.0);
        controller.play();
      } else if (data != null && data['isvideo'] == false) {
        String url = data['postUrl'].toString();
        imageUrls.add(url);
        VideoPlayerController controller = VideoPlayerController.network(url)
          ..initialize().then((_) {
            setState(() {});
          });
        videoControllers.add(controller);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: Text.rich(
          TextSpan(
            text: "Soora",
            style: extrabold.copyWith(
              color: Colors.black,
              fontSize: 24,
            ),
            children: [
              TextSpan(
                text: " .",
                style: extrabold.copyWith(color: subcolor, fontSize: 24),
              )
            ],
          ),
        ),
        backgroundColor: const Color.fromARGB(255, 255, 255, 255),
        elevation: 0,
        actions: [
          SvgPicture.string(
            '<svg width="19" height="19" viewBox="0 0 19 19" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="7.44842" cy="7.44842" r="6.69842" stroke="black" stroke-width="1.5"/><path d="M12.4135 12.4141L17.9998 18.0004" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
            width: 17,
            height: 17,
            allowDrawingOutsideViewBox: true,
          ),
          const SizedBox(
            width: 20,
          ),
          InkWell(
            child: SvgPicture.string(
              '<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 10H19" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M10 19L10 1" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
              width: 17,
              height: 17,
              allowDrawingOutsideViewBox: true,
            ),
            onTap: () {
              nextpage(context, AddPostScreen());
            },
          ),
          // IconButton(
          //   onPressed: () {
          //     nextpage(context, AddPostScreen());
          //   },
          //   icon: const Icon(
          //     Icons.add,
          //     color: Colors.black,
          //     size: 26,
          //   ),
          // ),
          const SizedBox(
            width: 20,
          ),
          SvgPicture.string(
            '<svg width="20" height="12" viewBox="0 0 20 12" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 1H19" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M1 11H19" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M1 6H13" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
            width: 12,
            height: 12,
            allowDrawingOutsideViewBox: true,
          ),
          const SizedBox(
            width: 24,
          ),
          // IconButton(
          //   onPressed: () {
          //     nextpage(context, VideoPlayerPage());
          //   },
          //   icon: const Icon(
          //     Icons.menu_rounded,
          //     color: Colors.black,
          //   ),
          // ),
        ],
      ),
      body: FutureBuilder(
          future: Future.value(FirebaseAuth.instance.currentUser),
          builder: (context, snapshot) {
            return StreamBuilder(
                stream: FirebaseFirestore.instance
                    .collection('currentposts')
                    .snapshots(),
                builder: (context, snap) {
                  final chatdocs = snap.data!.docs;
                  return ListView.builder(
                    itemCount: chatdocs.length,
                    itemBuilder: (context, index) {
                      final data = chatdocs[index].data();
                      if (data["isvideo"]) {
                        // VideoPlayerController controller =
                        //     VideoPlayerController.network(data["postUrl"]);
                        //       ..initialize().then((_) {
                        //         setState(() {});
                        //       });
                        // controller.setLooping(true);
                        // controller.setVolume(1.0);
                        // controller.play();
                        return postCard(
                            data["description"],
                            data["postUrl"],
                            data["username"],
                            data["profImage"],
                            data["rockets"],
                            data["isvideo"],
                            videoControllers[index],
                            data["postId"]);
                      } else {
                        return postCard(
                            data["description"],
                            data["postUrl"],
                            data["username"],
                            data["profImage"],
                            data["rockets"],
                            data["isvideo"],
                            VideoPlayerController.network(data["postUrl"]),
                            data["postId"]);
                      }
                    },
                  );
                });
          }),
    );
  }
}
