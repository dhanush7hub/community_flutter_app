import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:specialchat/services/database_service.dart';
import 'package:specialchat/widgets/dual_message_bubble.dart';
import 'package:specialchat/widgets/widgets.dart';
import 'package:collection/collection.dart';
import 'package:uuid/uuid.dart';

class PersonalchatPage extends StatelessWidget {
  String _profileurl;
  String _username;
  String _roomid;
  String _myprofile_url;

  PersonalchatPage(
      this._profileurl, this._username, this._roomid, this._myprofile_url);

  TextEditingController personalcontroller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          const SizedBox(
            height: 25,
          ),
          Container(
            height: 78,
            padding: const EdgeInsets.all(8),
            decoration: const BoxDecoration(
              border: Border(
                bottom: BorderSide(
                  color: subcolor,
                  width: 1.0,
                ),
              ),
            ),
            child: Row(
              children: [
                IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: const Icon(
                      Icons.arrow_back,
                    )),
                CircleAvatar(
                  radius: 25,
                  backgroundImage: NetworkImage(_profileurl),
                ),
                Expanded(
                  child: Padding(
                    padding: EdgeInsets.all(8),
                    child: Text(
                      _username,
                      style: medium.copyWith(
                          fontSize: 14,
                          color: Colors.black,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                const SizedBox(
                  width: 20,
                ),
                IconButton(
                  onPressed: () {},
                  icon: const Icon(Icons.phone),
                  color: Colors.black,
                ),
                IconButton(
                  onPressed: () {},
                  icon: const Icon(Icons.more_vert),
                  color: Colors.black,
                ),
              ],
            ),
          ),
          Expanded(
            child: Container(
                child: FutureBuilder(
                    future: Future.value(FirebaseAuth.instance.currentUser),
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return const Center(
                          child: CircularProgressIndicator(),
                        );
                      }
                      return StreamBuilder(
                        stream: FirebaseFirestore.instance
                            .collection("messages/$_roomid/message")
                            .orderBy("timestamp", descending: true)
                            .snapshots(),
                        builder: (context, snap) {
                          // if (_roomid == "")
                          //   return Expanded(child: Center(child: Text("Send a new Message")));
                          if (snap.connectionState == ConnectionState.waiting) {
                            return const Center(
                              child: CircularProgressIndicator(),
                            );
                          }

                          final chatdocs = snap.data!.docs;
                          final groups = groupBy(chatdocs, (doc) {
                            final date = DateTime.fromMillisecondsSinceEpoch(
                                doc["timestamp"].millisecondsSinceEpoch);
                            final now = DateTime.now();
                            final yesterday =
                                DateTime(now.year, now.month, now.day - 1);
                            if (date.year == now.year &&
                                date.month == now.month &&
                                date.day == now.day) {
                              return "Today";
                            } else if (date.year == yesterday.year &&
                                date.month == yesterday.month &&
                                date.day == yesterday.day) {
                              return "Yesterday";
                            } else {
                              return "${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}";
                            }
                          });
                          return Expanded(
                            child: ListView.builder(
                              reverse: true,
                              itemCount: groups.length,
                              itemBuilder: (BuildContext context, int index) {
                                final group = groups.entries.elementAt(index);
                                final dateStr = group.key;
                                final dateDivider = Container(
                                  margin: EdgeInsets.only(top: 10, bottom: 10),
                                  child: Row(
                                    children: [
                                      const Expanded(
                                          child: Divider(
                                        color: Color(0XFFDDDBF0),
                                        thickness: 1,
                                      )),
                                      Container(
                                        margin: const EdgeInsets.only(
                                            left: 5, right: 5),
                                        child: Text(
                                          dateStr,
                                          style: light.copyWith(
                                              color: Color(0XFFDDDBF0)),
                                        ),
                                      ),
                                      const Expanded(
                                          child: Divider(
                                        color: Color(0XFFDDDBF0),
                                        thickness: 1,
                                      )),
                                    ],
                                  ),
                                );
                                final messageBubbles = group.value
                                    .map((doc) {
                                      print("NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNn");
                                      print(doc["uid"]);
                                      print(doc["uid"]);
                                      return dual_message_bubble(
                                        doc["uid"] ==
                                                FirebaseAuth
                                                    .instance.currentUser!.uid
                                            ? true
                                            : false,
                                        doc["text"],
                                      );
                                    })
                                    .toList()
                                    .reversed;
                                return Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    dateDivider,
                                    ...messageBubbles,
                                  ],
                                );
                              },
                            ),
                          );
                        },
                      );
                    })),
          ),
          Row(
            children: [
              Expanded(
                child: Container(
                  margin: EdgeInsets.only(right: 40),
                  padding: EdgeInsets.all(15),
                  color: Colors.white,
                  child: TextField(
                    decoration: textfeilddecchat.copyWith(
                      contentPadding: EdgeInsets.all(12),
                      hintText: 'Type something...',
                      labelStyle: light.copyWith(fontSize: 10),
                    ),
                    controller: personalcontroller,
                  ),
                ),
              ),
              IconButton(
                onPressed: () async {
                  if (personalcontroller.text.isNotEmpty) {
                    // final uniquetime = await Uuid().v1();
                    // _roomid =
                    //     uniquetime + FirebaseAuth.instance.currentUser!.uid;
                    DatabaseService().savingpersonalchat(
                        FirebaseAuth.instance.currentUser!.uid,
                        personalcontroller.text,
                        _roomid);
                    personalcontroller.clear();
                  }
                },
                icon: Icon(Icons.send),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
