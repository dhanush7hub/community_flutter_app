import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

class MyWidget extends StatefulWidget {
  final String content;

  MyWidget({required this.content});

  @override
  _MyWidgetState createState() => _MyWidgetState();
}

class _MyWidgetState extends State<MyWidget> {
  bool showMore = false;

  void toggleText() {
    setState(() {
      showMore = !showMore;
    });
  }

  @override
  Widget build(BuildContext context) {
    List<String> lines = widget.content.split('\n');
    bool showTruncatedText = lines.length > 2 && !showMore;
    List<String> displayLines = showTruncatedText ? lines.sublist(0, 2) : lines;

    List<InlineSpan> textSpans = [];
    for (int i = 0; i < displayLines.length; i++) {
      textSpans.add(TextSpan(text: displayLines[i]));
      if (i < displayLines.length - 1) {
        textSpans.add(TextSpan(text: '\n'));
      }
    }

    if (showTruncatedText) {
      textSpans.add(
        TextSpan(
          text: '... Show More',
          style: TextStyle(
            color: Colors.blue,
            decoration: TextDecoration.underline,
          ),
          recognizer: TapGestureRecognizer()..onTap = toggleText,
        ),
      );
    } else if (showMore && lines.length > 2) {
      textSpans.add(
        TextSpan(
          text: ' Show Less',
          style: TextStyle(
            color: Colors.blue,
            decoration: TextDecoration.underline,
          ),
          recognizer: TapGestureRecognizer()..onTap = toggleText,
        ),
      );
    }

    return Scaffold(
      backgroundColor: Colors.amber,
      body: Container(
        width: double.infinity,
        child: RichText(
          text: TextSpan(children: textSpans),
        ),
      ),
    );
  }
}
