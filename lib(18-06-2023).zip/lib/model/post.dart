import 'package:cloud_firestore/cloud_firestore.dart';

class Post {
  final String description;
  final String uid;
  final String username;
  final String postId;
  final DatePublished;
  final String postUrl;
  final String profImage;
  final rockets;
  final bool isvideo;

  const Post(
      {required this.description,
      required this.uid,
      required this.username,
      required this.postId,
      required this.DatePublished,
      required this.postUrl,
      required this.profImage,
      required this.rockets,
      required this.isvideo});

  Map<String, dynamic> toJson() => {
        "description": description,
        "uid": uid,
        "username": username,
        "postId": postId,
        "DatePublished": DatePublished,
        "postUrl": postUrl,
        "profImage": profImage,
        "rockets": rockets,
        "isvideo": isvideo,
      };

  static Post fromSnap(DocumentSnapshot snap) {
    var snapshot = snap.data() as Map<String, dynamic>;

    return Post(
        description: snapshot["description"],
        uid: snapshot["uid"],
        username: snapshot["username"],
        postId: snapshot["postId"],
        DatePublished: snapshot["DatePublished"],
        postUrl: snapshot["postUrl"],
        profImage: snapshot["profImage"],
        rockets: snapshot["rockets"],
        isvideo: snapshot["isvideo"]);
  }
}
