import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:specialchat/authentication/confirmagepage.dart';
import 'package:specialchat/authentication/email_validatepage.dart';
import 'package:specialchat/authentication/setprofilepage.dart';
import 'package:specialchat/authentication/verifyemailpage.dart';
import 'package:specialchat/model/post.dart';
import 'package:specialchat/screens/homepage.dart';
import 'package:specialchat/screens/mainpage.dart';
import 'package:specialchat/widgets/widgets.dart';
import 'package:uuid/uuid.dart';
import 'dart:typed_data';

import 'dynamiclink_service.dart';

class DatabaseService {
  final String? uid;
  DatabaseService({this.uid});

  //reference for our collections
  final CollectionReference usercollection =
      FirebaseFirestore.instance.collection("users");

  // final CollectionReference groupcollection = FirebaseFirestore.instance
  //     .collection("group"); // this is for adding group details

  //Saving the user data
  Future savingUserData(String email) async {
    print("dataaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
    print("going in");
    return await usercollection
        .doc(FirebaseAuth.instance.currentUser!.uid)
        .set({
      "uid": FirebaseAuth.instance.currentUser!.uid,
      "email": email,
      "profilepic": "",
      "verificateduser": false,
      // "groups": [],
    });
  }

  Future<bool> checkingverified() async {
    final snap = FirebaseFirestore.instance
        .collection("users")
        .doc(FirebaseAuth.instance.currentUser!.uid);
    final snapdoc = await snap.get();
    if (snapdoc.exists && snapdoc.data() != null) {
      return snapdoc.data()!['verificateduser'];
    } else {
      return false;
    }
  }

  Future modifiyingverified(verified) async {
    return await usercollection.doc(FirebaseAuth.instance.currentUser!.uid).set(
        {
          "verificateduser": verified,
        },
        SetOptions(
          merge: true,
        ));
  }

  Future savingbirthdate(String dob) async {
    return await usercollection.doc(FirebaseAuth.instance.currentUser!.uid).set(
        {
          "date of birth": dob,
        },
        SetOptions(
          merge: true,
        ));
  }

  Future savingUserDetails(
      String name, String about, String gender, image) async {
    print("objecooooooooooooooooooooooooooooooooooooooooooooooooooooooo");
    return await usercollection.doc(FirebaseAuth.instance.currentUser!.uid).set(
        {"name": name, "about": about, "Gender": gender, "profilepic": image},
        SetOptions(
          merge: true,
        ));
  }

  // Future<DocumentSnapshot<Map<String, dynamic>>> getDocument() async {
  //   DocumentSnapshot<Map<String, dynamic>> snapshot =
  //       await FirebaseFirestore.instance.collection("user").doc(uid).get();
  //   return snapshot;
  // }

  savingpersonalchat(uid, text, roomid) {
    print(roomid);
    final snap =
        FirebaseFirestore.instance.collection("messages/$roomid/message");
    final snapdocs = snap.add({
      "uid": uid,
      "text": text,
      "timestamp": DateTime.now(),
    });
    // .add({
    //   "notme": notme,
    //   "text": text,
    // });
  }

  savinggroupchat(uid, text, groupid, _myprofile_url, private) {
    if (private) {
      final snap = FirebaseFirestore.instance
          .collection("privategroups/$groupid/message");
      final snapdocs = snap.add({
        "uid": uid,
        "text": text,
        "timestamp": DateTime.now(),
        "myprofile_url": _myprofile_url
      });
    } else {
      final snap = FirebaseFirestore.instance
          .collection("publicgroups/$groupid/message");
      final snapdocs = snap.add({
        "uid": uid,
        "text": text,
        "timestamp": DateTime.now(),
        "myprofile_url": _myprofile_url
      });
    }
    // .add({
    //   "notme": notme,
    //   "text": text,
    // });
  }

  savinginteractionchat(uid, text, groupid) async {
    final snap =
        FirebaseFirestore.instance.collection("interaction/$groupid/message");
    final snaps = FirebaseFirestore.instance
        .collection("users")
        .doc(FirebaseAuth.instance.currentUser!.uid);
    final snapdoc = await snaps.get();
    final snapdocs = snap.add({
      "uid": uid,
      "text": text,
      "timestamp": DateTime.now(),
      "myprofile_url": snapdoc.data()!['profilepic']
    });

    // .add({
    //   "notme": notme,
    //   "text": text,
    // });
  }

  addgroup(gname, gdescription, imgurl, istoggle) async {
    final url = await uploadImageToFirebase(imgurl);
    final name = await FirebaseFirestore.instance
        .collection("users")
        .doc(FirebaseAuth.instance.currentUser!.uid)
        .get();

    final username = name.data()!['name'];

    final uniquetime = Uuid().v1();
    final unique = uniquetime + FirebaseAuth.instance.currentUser!.uid;
    final grouplink =
        await FirebaseDynamicLinkService.createDynamicLinkforgroup(
            true, unique, istoggle);
    if (istoggle) {
      FirebaseFirestore.instance.collection("privategroups").doc(unique).set({
        "groupname": gname,
        "group_des": gdescription,
        "profile_url": url,
        "roomid": unique,
        "created_at": Timestamp.fromMillisecondsSinceEpoch(1620676800000),
        "created_by": username,
        "group_link": grouplink,
        "myprofile_url": name.data()!["profilepic"],
        "created_byuid": FirebaseAuth.instance.currentUser!.uid,
        "lastmessage": "hi"
      });
      FirebaseFirestore.instance
          .collection("privategroups/$unique/users")
          .doc(FirebaseAuth.instance.currentUser!.uid)
          .set({
        "bio": name.data()!["about"],
        "isadmin": true,
        "profile_url": name.data()!["profilepic"],
        "username": name.data()!["name"]
      });
    } else {
      FirebaseFirestore.instance.collection("publicgroups").doc(unique).set({
        "groupname": gname,
        "group_des": gdescription,
        "profile_url": url,
        "roomid": unique,
        "created_at": Timestamp.fromMillisecondsSinceEpoch(1620676800000),
        "created_by": username,
        "group_link": grouplink,
        "myprofile_url": name.data()!["profilepic"],
        "created_byuid": FirebaseAuth.instance.currentUser!.uid,
        "lastmessage": "hi"
      });
      FirebaseFirestore.instance
          .collection("publicgroups/$unique/users")
          .doc(FirebaseAuth.instance.currentUser!.uid)
          .set({
        "bio": name.data()!["about"],
        "isadmin": true,
        "profile_url": name.data()!["profilepic"],
        "username": name.data()!["name"]
      });
    }

    final snap = FirebaseFirestore.instance
        .collection(
            "multipleconversationlist/${FirebaseAuth.instance.currentUser!.uid}/conversationwith")
        .doc(unique);
    final snapdocs = snap.set({
      "groupid": unique,
      "groupname": gname,
      "group_des": gdescription,
      "lastmessage": "Say hi",
      "profile_url": url,
      "myprofile_url": name.data()!["profilepic"],
      "privategroup": istoggle,
      "created_at": Timestamp.fromMillisecondsSinceEpoch(1620676800000),
      "created_by": username,
      "group_link": "http://mylink.com"
    });
    // .add({
    //   "notme": notme,
    //   "text": text,
    // });
  }

  void joingroup(String roomid) async {
    // Reference to the source collection

    // Reference to the destination collection
    final name = await FirebaseFirestore.instance
        .collection("users")
        .doc(FirebaseAuth.instance.currentUser!.uid)
        .get();

    // Query the documents in the source collection
    final doc = await FirebaseFirestore.instance
        .collection('publicgroups')
        .doc(roomid)
        .get();

    final data = doc.data() as Map<String, dynamic>;

    final snap = FirebaseFirestore.instance.collection(
        "multipleconversationlist/${FirebaseAuth.instance.currentUser!.uid}/conversationwith");
    final snapdocs = snap.add({
      "groupid": data["roomid"],
      "groupname": data["groupname"],
      "group_des": data["group_des"],
      "lastmessage": "Say hi",
      "profile_url": data["profile_url"],
      "myprofile_url": name.data()!["profilepic"],
      "privategroup": false,
      "created_at": Timestamp.fromMillisecondsSinceEpoch(1620676800000),
      "created_by": data["created_by"],
      "group_link": "http://mylink.com"
    });

    // Iterate through the documents and copy fields to the destination collection
    // querySnapshot.docs.forEach((DocumentSnapshot doc) async {
    //   // Get the data from the document
    //   Map<String, dynamic> data = doc.data() as Map<String, dynamic>;

    //   // Copy the fields you want to paste into the destination collection
    //   String field1 = data['field1'];
    //   int field2 = data['field2'];

    //   // Create a new document in the destination collection with the copied fields
    //   await destinationCollection.add({
    //     'field1': field1,
    //     'field2': field2,
    //   });
    // }

    print('Copying and pasting fields completed!');
  }

  Future<String?> uploadImageToFirebase(File? image) async {
    final FirebaseAuth auth = FirebaseAuth.instance;
    final User? user = auth.currentUser;
    if (user != null) {
      final String uid = user.uid;
      String fileName = DateTime.now().millisecondsSinceEpoch.toString();
      FirebaseStorage storage = FirebaseStorage.instance;
      Reference reference = storage.ref().child("images/$uid/$fileName");
      UploadTask uploadTask = reference.putFile(image!);
      TaskSnapshot storageTaskSnapshot = await uploadTask;
      String downloadUrl = await storageTaskSnapshot.ref.getDownloadURL();
      return downloadUrl;
    }
    return null;
  }

  //getting user data

  Future<String?> getUsername() async {
    final snap = FirebaseFirestore.instance
        .collection("users")
        .doc(FirebaseAuth.instance.currentUser!.uid);
    final snapdoc = await snap.get();
    if (snapdoc.exists && snapdoc.data() != null) {
      return snapdoc.data()!['name'];
    } else {
      return null;
    }
  }

  Future<String?> getUserprofile() async {
    final snap = FirebaseFirestore.instance
        .collection("users")
        .doc(FirebaseAuth.instance.currentUser!.uid);
    final snapdoc = await snap.get();
    if (snapdoc.exists && snapdoc.data() != null) {
      return snapdoc.data()!['profilepic'];
    } else {
      return null;
    }
  }

  Future<void> redirect(context) async {
    print("ttttttttttttttttttttttttttttttttt");
    // CircularProgressIndicator();
    final snap = FirebaseFirestore.instance
        .collection("users")
        .doc(FirebaseAuth.instance.currentUser!.uid);
    final snapdoc = await snap.get();
    try {
      if (snapdoc.exists && snapdoc.data() != null) {
        if (snapdoc.data()!['verificateduser'] == true) {
          if (snapdoc.data()!['date of birth'] != null &&
              snapdoc.data()!['date of birth'] != "") {
            if (snapdoc.data()!['profilepic'] != null &&
                snapdoc.data()!['profilepic'] != "") {
              nextpagereplace(context, Mainpage());
            } else {
              nextpage(context, Setprofilepage(false));
            }
          } else {
            nextpage(context, Confirmagepage());
          }
        } else {
          nextpage(context, Email_validatepage());
        }
      }
    } catch (error) {
      print(error);
    }
  }

  // Future<void> redirect(context) async {
  //   CircularProgressIndicator();
  //   final snap = FirebaseFirestore.instance
  //       .collection("users")
  //       .doc(FirebaseAuth.instance.currentUser!.uid);
  //   final snapdoc = await snap.get();
  //   if (snapdoc.exists && snapdoc.data() != null) {
  //     if (snapdoc.data()!['verificateduser'] == true) {
  //       if (snapdoc.data()!['date of birth'] != null &&
  //           snapdoc.data()!['date of birth'] != "") {
  //         if (snapdoc.data()!['profilepic'] != null &&
  //             snapdoc.data()!['profilepic'] != "") {
  //           nextpage(context, Mainpage());
  //         } else {
  //           nextpage(context, Setprofilepage());
  //         }
  //       } else {
  //         nextpage(context, Confirmagepage());
  //       }
  //     } else {
  //       nextpage(context, Email_validatepage());
  //     }
  //   } else {
  //     return;
  //   }
  // }

  groupinfodata(DocumentReference groupdoc) async {
    final snapdoc = await groupdoc.get();
  }
}

class StorageMethods {
  final FirebaseStorage _storage = FirebaseStorage.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  Future<String> uploadImageToStorage(
      String childname, Uint8List file, bool isPost) async {
    Reference ref =
        _storage.ref().child(childname).child("ADF7mxcf7GSBcwopn7R94iVra713");
    //_auth.currentUser!.uid
    if (isPost) {
      String id = const Uuid().v1();
      ref = ref.child(id);
    }
    UploadTask uploadTask = ref.putData(file);

    TaskSnapshot snap = await uploadTask;
    String downloadUrl = await snap.ref.getDownloadURL();
    return downloadUrl;
  }

  Future<String> uploadImageToStorages(
      String childname, File file, bool isPost) async {
    Reference ref =
        _storage.ref().child(childname).child("ADF7mxcf7GSBcwopn7R94iVra713");
    //_auth.currentUser!.uid
    if (isPost) {
      String id = const Uuid().v1();
      ref = ref.child(id);
    }
    UploadTask uploadTask = ref.putFile(file);

    TaskSnapshot snap = await uploadTask;
    String downloadUrl = await snap.ref.getDownloadURL();
    return downloadUrl;
  }
}

class FirestoreMethods {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  //upload post

  Future<String> uploadPost(String description, Uint8List file, String uid,
      String? username, String? profImage, bool isvideo) async {
    String res = "Some Error Occured";
    try {
      String photoUrl =
          await StorageMethods().uploadImageToStorage("posts", file, true);
      final uniquetime = Uuid().v1();
      final unique = uniquetime + FirebaseAuth.instance.currentUser!.uid;
      Post post = Post(
          description: description,
          uid: uid,
          username: username.toString(),
          postId: unique,
          DatePublished: DateTime.now(),
          postUrl: photoUrl,
          profImage: profImage.toString(),
          rockets: "",
          isvideo: isvideo);

      _firestore.collection("currentposts").doc(unique).set(post.toJson());
      res = "success";
    } catch (e) {
      res = e.toString();
    }
    return res;
  }

  Future<String> uploadPosts(String description, File file, String uid,
      String? username, String? profImage, bool isvideo) async {
    String res = "Some Error Occured";
    try {
      // String photoUrl =
      //     await StorageMethods().uploadImageToStorages("posts", file, true);
      final uniquetime = Uuid().v1();
      final unique = uniquetime + FirebaseAuth.instance.currentUser!.uid;
      Post post = Post(
          description: description,
          uid: uid,
          username: username.toString(),
          postId: unique,
          DatePublished: DateTime.now(),
          postUrl:
              "https://static.videezy.com/system/resources/previews/000/042/042/original/Ramdom_Lines_x264.mp4",
          profImage: profImage.toString(),
          rockets: "",
          isvideo: isvideo);

      _firestore.collection("currentposts").doc(unique).set(post.toJson());
      res = "success";
    } catch (e) {
      res = e.toString();
    }
    return res;
  }
}
