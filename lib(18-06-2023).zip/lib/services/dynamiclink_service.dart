import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_dynamic_links/firebase_dynamic_links.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:specialchat/screens/chatpage.dart';
import 'package:specialchat/screens/groupchatpage.dart';
import 'package:specialchat/screens/intractionpage.dart';
import 'package:specialchat/widgets/groups.dart';
import 'package:specialchat/widgets/widgets.dart';

class FirebaseDynamicLinkService {
  static Future<String?> createDynamicLinkforgroup(
      bool short, String groupid, bool isprivate) async {
    String linkmessage;

    final dynamicLinkParams = isprivate
        ? DynamicLinkParameters(
            // link: Uri.parse("https://www.sundayyychat.com/storyData?id=$storyData"),
            uriPrefix: "https://droupout.page.link",
            link: Uri.parse(
                "https://droupout.page.link/privategroup?id=$groupid"),
            androidParameters: const AndroidParameters(
              // fallbackUrl: ,
              packageName: "com.example.specialchat",
              minimumVersion: 30,
            ),
          )
        : DynamicLinkParameters(
            // link: Uri.parse("https://www.sundayyychat.com/storyData?id=$storyData"),
            uriPrefix: "https://droupout.page.link",
            link:
                Uri.parse("https://droupout.page.link/publicgroup?id=$groupid"),
            androidParameters: const AndroidParameters(
              // fallbackUrl: ,
              packageName: "com.example.specialchat",
              minimumVersion: 30,
            ),
          );

    Uri url;
    if (short) {
      final ShortDynamicLink shortLink =
          await FirebaseDynamicLinks.instance.buildShortLink(dynamicLinkParams);
      ;
      url = shortLink.shortUrl;
    } else {
      url = await FirebaseDynamicLinks.instance.buildLink(dynamicLinkParams);
      ;
    }

    linkmessage = url.toString();
    return linkmessage;

    //   final dynamicLink =
    //       await FirebaseDynamicLinks.instance.buildShortLink(dynamicLinkParams);
  }

  static void initDynamicLink(BuildContext context) async {
    final links = await FirebaseDynamicLinks.instance.getInitialLink();
    final Uri? deepLink = links?.link;

    var isprivategroup = deepLink!.pathSegments.contains("privategroup");
    var ispublicgroup = deepLink.pathSegments.contains("publicgroup");

    if (ispublicgroup) {
      String groupid = deepLink.queryParameters['id']!;
      if (deepLink != null) {
        try {
          DocumentSnapshot snapshot = await FirebaseFirestore.instance
              .collection("publicgroups")
              .doc(groupid)
              .get();

          if (snapshot.exists) {
            Map<String, dynamic> data = snapshot.data() as Map<String, dynamic>;
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => groupchatpage(
                    data["profile_url"],
                    data["groupname"],
                    data["roomid"],
                    data["myprofile_url"],
                    false,
                    data["created_at"].toDate(),
                    data["created_by"],
                    deepLink.toString(),
                    data["group_des"]),
              ),
            );

            // ...
          } else {
            print("Document does not exist");
          }
        } catch (e) {
          print("Error retrieving document: $e");
        }
      }
    }
    if (isprivategroup) {
      String groupid = deepLink.queryParameters['id']!;
      if (deepLink != null) {
        try {
          DocumentSnapshot snapshot = await FirebaseFirestore.instance
              .collection("privategroups")
              .doc(groupid)
              .get();

          if (snapshot.exists) {
            Map<String, dynamic> data = snapshot.data() as Map<String, dynamic>;
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => groupchatpage(
                    data["profile_url"],
                    data["groupname"],
                    data["roomid"],
                    data["myprofile_url"],
                    true,
                    data["created_at"].toDate(),
                    data["created_by"],
                    deepLink.toString(),
                    data["group_des"]),
              ),
            );

            // ...
          } else {
            print("Document does not exist");
          }
        } catch (e) {
          print("Error retrieving document: $e");
        }
      }
    }
  }

  // if (deepLink == null) {
  //   print("No deepLink found");
  //   return;
  // }
  // if (deepLink.pathSegments.contains('publicgroup')) {
  //   try {
  //     Navigator.push(
  //       context,
  //       MaterialPageRoute(
  //         builder: (context) => InteractionPage("asd", "zxc", "ewq"),
  //       ),
  //     );
  //   } catch (e) {
  //     print('Error navigating to InteractionPage: $e');
  //   }
  // }
}

// FirebaseDynamicLinks.instance.onLink.listen(
//     (PendingDynamicLinkData? dynamicLink) {
//   print("No deepLink found................");

//   final Uri? deepLink = dynamicLink?.link;

//   if (deepLink == null) {
//     print("No deepLink found");
//     return;
//   }

//   if (deepLink.pathSegments.contains('group1link')) {
//     try {
//       Navigator.push(
//         context,
//         MaterialPageRoute(
//           builder: (context) => InteractionPage("asd", "zxc", "ewq"),
//         ),
//       );
//     } catch (e) {
//       print('Error navigating to InteractionPage: $e');
//     }
//   }
// }, onError: (e) {
//   print('Dynamic link error: $e');
// });

// final PendingDynamicLinkData? data =
//     await FirebaseDynamicLinks.instance.getInitialLink();
// try {
//   final Uri deepLink = data!.link;
//   var isStory = deepLink.pathSegments.contains('ezHe');
//   if (isStory) {
//     // TODO :Modify Accordingly
//     String id = deepLink.queryParameters['id']!; // TODO :Modify Accordingly

//     // TODO : Navigate to your pages accordingly here

//     try {
//       Navigator.push(
//           context,
//           MaterialPageRoute(
//               builder: (context) => InteractionPage(
//                     "asd",
//                     "zxc",
//                     "ewq",
//                   )));
//       // nextpage(context, InteractionPage("asd", "zxc", "ewq", "qwe"));
//       // Navigator.push(
//       //     context,
//       //     MaterialPageRoute(
//       //         builder: (context) =>
//       //             InteractionPage("asd", "zxc", "ewq", "qwe")));
//       // await firebaseFirestore.collection('Stories').doc(id).get()
//       //     .then((snapshot) {
//       //       StoryData storyData = StoryData.fromSnapshot(snapshot);

//       //       return Navigator.push(context, MaterialPageRoute(builder: (context) =>
//       //         StoryPage(story: storyData,)
//       //       ));
//       // });
//     } catch (e) {
//       print(e);
//     }
//   }
// } catch (e) {
//   print('No deepLink found');
// }

class OnLinkErrorException extends PlatformException {
  OnLinkErrorException._(String code, String message, dynamic details)
      : super(code: code, message: message, details: details);
}
