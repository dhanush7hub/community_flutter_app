import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:specialchat/helper/helper_function.dart';
import 'package:specialchat/services/database_service.dart';
import 'package:specialchat/widgets/widgets.dart';

class Authservice {
  final FirebaseAuth firebaseauth = FirebaseAuth.instance;

  //login
  Future loginUserWithEmailandPassword(String email, String Password) async {
    try {
      User user = (await firebaseauth.signInWithEmailAndPassword(
              email: email, password: Password))
          .user!;
      if (user != null) {
        return true;
      }
    } on FirebaseAuthException catch (e) {
      return e.message;
    }
  }

  //register

  Future<bool> registerUserWithEmailandPassword(
      String email, String password) async {
    try {
      UserCredential userCredential = await firebaseauth
          .createUserWithEmailAndPassword(email: email, password: password);
      User? user = userCredential.user;
      if (user != null) {
        return true;
      } else {
        return false;
      }
    } catch (e) {
      print('Error creating user: $e');
      return false;
    }
  }

  //signout
  Future signout() async {
    try {
      await Helperfunctions.saveuserloggedinkey(false);
      // await Helperfunctions.saveuseremailkey("");
      // await Helperfunctions.saveusernamekey("");
      await firebaseauth.signOut();
    } catch (e) {
      print(e);
    }
  }
}
